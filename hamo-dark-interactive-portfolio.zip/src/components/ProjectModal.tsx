import React, { useEffect } from "react";
import { Project } from "../data/projects";
import { X, ExternalLink, Github, Layers, CheckCircle2, Activity } from "lucide-react";

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    if (project) {
      window.addEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "hidden";
    }
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "unset";
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Dialog */}
      <div 
        className="relative w-full max-w-3xl rounded-2xl bg-[#0a0d14] border border-white/[0.12] shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden z-10 my-8 animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="project-modal-title"
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 left-4 z-20 p-2 rounded-xl bg-black/60 hover:bg-black/90 text-zinc-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
          aria-label="إغلاق النافذة"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Project Image Banner */}
        <div className="relative aspect-video w-full overflow-hidden bg-zinc-950">
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover object-top"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0d14] via-[#0a0d14]/40 to-transparent" />
          
          <div className="absolute bottom-4 right-4 left-4 flex items-center justify-between">
            <span className="text-xs font-mono text-cyan-300 px-3 py-1 rounded-md bg-black/70 backdrop-blur-md border border-cyan-500/30">
              {project.category}
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6">
          <div>
            <h3 id="project-modal-title" className="text-2xl sm:text-3xl font-bold text-white mb-3">
              {project.title}
            </h3>
            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed">
              {project.detailedDescription || project.description}
            </p>
          </div>

          {/* Metrics */}
          {project.metrics && project.metrics.length > 0 && (
            <div className="grid grid-cols-2 gap-3 p-4 rounded-xl bg-white/[0.02] border border-white/[0.06]">
              {project.metrics.map((metric, i) => (
                <div key={i} className="flex items-center gap-3">
                  <Activity className="w-5 h-5 text-cyan-400 shrink-0" />
                  <div>
                    <div className="text-xs text-zinc-400">{metric.label}</div>
                    <div className="text-sm font-semibold font-mono text-white mt-0.5">{metric.value}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Technologies Used */}
          <div>
            <h4 className="text-xs font-mono text-zinc-400 uppercase tracking-wider mb-3 flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>التقنيات المستخدمة في التطوير:</span>
            </h4>
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech) => (
                <span
                  key={tech}
                  className="px-3 py-1 text-xs font-mono text-cyan-300 bg-cyan-950/40 border border-cyan-500/20 rounded-md"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Action Links */}
          <div className="pt-4 border-t border-white/[0.08] flex flex-wrap items-center justify-end gap-3">
            <a
              href={project.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium text-zinc-200 hover:text-white bg-white/[0.05] hover:bg-white/[0.1] border border-white/[0.1] transition-colors"
            >
              <Github className="w-4 h-4" />
              <span>مستودع GitHub</span>
            </a>

            <a
              href={project.liveUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all"
            >
              <ExternalLink className="w-4 h-4" />
              <span>زيارة المشروع المباشر</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
