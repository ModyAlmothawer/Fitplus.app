import React, { useEffect, useRef } from "react";

interface BackgroundSceneProps {
  activeSection: string;
}

export const BackgroundScene: React.FC<BackgroundSceneProps> = ({ activeSection }) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Highly optimized mouse parallax for desktop ONLY (Zero React re-renders)
  useEffect(() => {
    const isTouch = "ontouchstart" in window || navigator.maxTouchPoints > 0;
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (isTouch || prefersReducedMotion) return;

    let targetX = 0;
    let targetY = 0;
    let currentX = 0;
    let currentY = 0;
    let ticking = false;
    let animId: number;

    const onMouseMove = (e: MouseEvent) => {
      // Normalize to -1 ... 1
      targetX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetY = (e.clientY / window.innerHeight - 0.5) * 2;

      if (!ticking) {
        ticking = true;
        animId = requestAnimationFrame(updateParallax);
      }
    };

    const updateParallax = () => {
      // Smooth lerp
      currentX += (targetX - currentX) * 0.08;
      currentY += (targetY - currentY) * 0.08;

      if (containerRef.current) {
        containerRef.current.style.setProperty("--mx", `${currentX * 12}px`);
        containerRef.current.style.setProperty("--my", `${currentY * 12}px`);
      }

      // Stop loop when close to target to save CPU
      if (Math.abs(targetX - currentX) > 0.001 || Math.abs(targetY - currentY) > 0.001) {
        animId = requestAnimationFrame(updateParallax);
      } else {
        ticking = false;
      }
    };

    window.addEventListener("mousemove", onMouseMove, { passive: true });

    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      cancelAnimationFrame(animId);
    };
  }, []);

  // Lightweight particles canvas (Ultra-low CPU budget, 120 FPS capable)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion) return;

    const isMobile = window.innerWidth < 768;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const onResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", onResize, { passive: true });

    // 14 particles on desktop, 5 on mobile
    const count = isMobile ? 5 : 14;
    const particles = Array.from({ length: count }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 1.4 + 0.6,
      vx: (Math.random() - 0.5) * 0.2,
      vy: -Math.random() * 0.25 - 0.05,
      alpha: Math.random() * 0.25 + 0.08,
    }));

    let animId: number;
    let isVisible = true;

    // Pause when tab not visible
    const onVisibilityChange = () => {
      isVisible = !document.hidden;
      if (isVisible) {
        animId = requestAnimationFrame(render);
      } else {
        cancelAnimationFrame(animId);
      }
    };
    document.addEventListener("visibilitychange", onVisibilityChange);

    const render = () => {
      if (!isVisible) return;
      ctx.clearRect(0, 0, width, height);

      ctx.fillStyle = "rgba(103, 232, 249, 0.35)";
      for (let i = 0; i < count; i++) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;

        if (p.y < 0) {
          p.y = height;
          p.x = Math.random() * width;
        }
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none -z-10 overflow-hidden bg-[#050609]"
      style={
        {
          "--mx": "0px",
          "--my": "0px",
        } as React.CSSProperties
      }
    >
      {/* 1. Base Subtle Developer Grid (Parallax-ready via CSS variables) */}
      <div
        className="absolute inset-0 cyber-grid opacity-30 transform-gpu"
        style={{
          transform: "translate3d(calc(var(--mx) * 0.25), calc(var(--my) * 0.25), 0)",
          maskImage: "radial-gradient(ellipse at 50% 50%, black 45%, transparent 85%)",
          WebkitMaskImage: "radial-gradient(ellipse at 50% 50%, black 45%, transparent 85%)",
        }}
      />

      {/* 2. Scroll-Linked Ambient Layers (Compositor-only opacity transitions) */}
      {/* Hero Ambient Glow */}
      <div
        className={`absolute inset-0 transition-opacity duration-1000 ease-out transform-gpu ${
          activeSection === "hero" ? "opacity-100" : "opacity-0"
        }`}
        style={{
          transform: "translate3d(calc(var(--mx) * 0.8), calc(var(--my) * 0.8), 0)",
        }}
      >
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[520px] h-[520px] rounded-full bg-cyan-500/12 blur-[100px]" />
        <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] rounded-full bg-blue-600/10 blur-[110px]" />
      </div>

      {/* About Ambient Glow */}
      <div
        className={`absolute inset-0 transition-opacity duration-1000 ease-out transform-gpu ${
          activeSection === "about" ? "opacity-100" : "opacity-0"
        }`}
        style={{
          transform: "translate3d(calc(var(--mx) * -0.6), calc(var(--my) * -0.6), 0)",
        }}
      >
        <div className="absolute top-1/3 right-1/4 w-[480px] h-[480px] rounded-full bg-indigo-600/12 blur-[100px]" />
        <div className="absolute top-1/2 left-1/3 w-[420px] h-[420px] rounded-full bg-purple-600/10 blur-[110px]" />
      </div>

      {/* Skills Ambient Glow */}
      <div
        className={`absolute inset-0 transition-opacity duration-1000 ease-out transform-gpu ${
          activeSection === "skills" ? "opacity-100" : "opacity-0"
        }`}
        style={{
          transform: "translate3d(calc(var(--mx) * 0.7), calc(var(--my) * 0.7), 0)",
        }}
      >
        <div className="absolute top-1/4 right-1/3 w-[500px] h-[500px] rounded-full bg-cyan-500/12 blur-[100px]" />
        <div className="absolute top-1/2 left-1/4 w-[440px] h-[440px] rounded-full bg-teal-500/10 blur-[110px]" />
      </div>

      {/* Projects Ambient Glow */}
      <div
        className={`absolute inset-0 transition-opacity duration-1000 ease-out transform-gpu ${
          activeSection === "projects" ? "opacity-100" : "opacity-0"
        }`}
        style={{
          transform: "translate3d(calc(var(--mx) * -0.7), calc(var(--my) * -0.7), 0)",
        }}
      >
        <div className="absolute top-1/3 left-1/3 w-[540px] h-[540px] rounded-full bg-sky-500/12 blur-[110px]" />
        <div className="absolute top-2/3 right-1/4 w-[480px] h-[480px] rounded-full bg-indigo-500/10 blur-[110px]" />
      </div>

      {/* Contact Ambient Glow */}
      <div
        className={`absolute inset-0 transition-opacity duration-1000 ease-out transform-gpu ${
          activeSection === "contact" ? "opacity-100" : "opacity-0"
        }`}
        style={{
          transform: "translate3d(calc(var(--mx) * 0.5), calc(var(--my) * 0.5), 0)",
        }}
      >
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[580px] h-[580px] rounded-full bg-cyan-500/10 blur-[120px]" />
        <div className="absolute top-1/3 right-1/3 w-[380px] h-[380px] rounded-full bg-blue-600/08 blur-[100px]" />
      </div>

      {/* 3. Subtle Geometric Cyber Accents */}
      <div
        className="absolute top-1/4 right-[12%] w-64 h-64 border border-cyan-500/[0.08] rounded-full transform-gpu pointer-events-none"
        style={{
          transform: "translate3d(calc(var(--mx) * 0.4), calc(var(--my) * 0.4), 0)",
        }}
      />
      <div
        className="absolute top-2/3 left-[10%] w-44 h-44 border border-indigo-500/[0.08] rounded-xl transform-gpu pointer-events-none"
        style={{
          transform: "translate3d(calc(var(--mx) * -0.4), calc(var(--my) * -0.4), 0)",
        }}
      />

      {/* 4. Canvas Floating Particles */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-60" />

      {/* 5. Minimal Vignette */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050609]/50 via-transparent to-[#050609]/90 pointer-events-none" />
    </div>
  );
};
