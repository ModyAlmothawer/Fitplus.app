import React, { useEffect, useState, useRef } from "react";

interface BackgroundSceneProps {
  activeSection: string;
}

export const BackgroundScene: React.FC<BackgroundSceneProps> = ({ activeSection }) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Detect touch device & listen to mouse on desktop
  useEffect(() => {
    const checkTouch = () => {
      setIsTouchDevice("ontouchstart" in window || navigator.maxTouchPoints > 0);
    };
    checkTouch();

    let targetX = 0;
    let targetY = 0;
    let currentX = 0;
    let currentY = 0;
    let animFrame: number;

    const handleMouseMove = (e: MouseEvent) => {
      // Normalize mouse between -1 and 1
      targetX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetY = (e.clientY / window.innerHeight - 0.5) * 2;
    };

    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    // Smooth lerp for desktop mouse parallax
    const smoothUpdate = () => {
      currentX += (targetX - currentX) * 0.05;
      currentY += (targetY - currentY) * 0.05;
      setMousePos({ x: currentX, y: currentY });
      animFrame = requestAnimationFrame(smoothUpdate);
    };

    if (!isTouchDevice) {
      window.addEventListener("mousemove", handleMouseMove, { passive: true });
      animFrame = requestAnimationFrame(smoothUpdate);
    }

    window.addEventListener("scroll", handleScroll, { passive: true });

    return () => {
      if (!isTouchDevice) {
        window.removeEventListener("mousemove", handleMouseMove);
        cancelAnimationFrame(animFrame);
      }
      window.removeEventListener("scroll", handleScroll);
    };
  }, [isTouchDevice]);

  // Canvas floating particles effect (subtle, high performance)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener("resize", handleResize);

    // Minimal elegant particles
    const particleCount = window.innerWidth < 768 ? 20 : 45;
    const particles = Array.from({ length: particleCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 1.5 + 0.5,
      speedX: (Math.random() - 0.5) * 0.25,
      speedY: -Math.random() * 0.35 - 0.05,
      opacity: Math.random() * 0.4 + 0.1,
    }));

    let animationId: number;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;

        // Wrap around
        if (p.y < 0) {
          p.y = height;
          p.x = Math.random() * width;
        }
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(103, 232, 249, ${p.opacity * 0.4})`;
        ctx.fill();
      });

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  // Compute section-based ambient lighting accents
  const getSectionGlowStyles = () => {
    switch (activeSection) {
      case "hero":
        return {
          orb1: "bg-cyan-500/15 top-1/4 left-1/2 -translate-x-1/2 w-[550px] h-[550px]",
          orb2: "bg-blue-600/10 top-1/3 left-1/4 w-[450px] h-[450px]",
          orb3: "bg-indigo-500/10 bottom-1/4 right-1/4 w-[500px] h-[500px]",
        };
      case "about":
        return {
          orb1: "bg-indigo-600/15 top-1/3 right-1/4 w-[500px] h-[500px]",
          orb2: "bg-purple-600/12 top-1/2 left-1/3 w-[450px] h-[450px]",
          orb3: "bg-cyan-600/08 bottom-1/3 left-1/4 w-[400px] h-[400px]",
        };
      case "skills":
        return {
          orb1: "bg-cyan-500/12 top-1/4 right-1/3 w-[520px] h-[520px]",
          orb2: "bg-teal-500/10 top-1/2 left-1/4 w-[480px] h-[480px]",
          orb3: "bg-blue-500/10 bottom-1/4 right-1/4 w-[420px] h-[420px]",
        };
      case "projects":
        return {
          orb1: "bg-sky-500/14 top-1/3 left-1/3 w-[600px] h-[600px]",
          orb2: "bg-indigo-500/12 top-2/3 right-1/4 w-[550px] h-[550px]",
          orb3: "bg-cyan-400/10 bottom-1/4 left-1/4 w-[450px] h-[450px]",
        };
      case "contact":
        return {
          orb1: "bg-cyan-500/12 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px]",
          orb2: "bg-blue-600/10 top-1/3 left-1/3 w-[400px] h-[400px]",
          orb3: "bg-indigo-700/08 bottom-1/3 right-1/3 w-[450px] h-[450px]",
        };
      default:
        return {
          orb1: "bg-cyan-500/15 top-1/4 left-1/2 -translate-x-1/2 w-[550px] h-[550px]",
          orb2: "bg-blue-600/10 top-1/3 left-1/4 w-[450px] h-[450px]",
          orb3: "bg-indigo-500/10 bottom-1/4 right-1/4 w-[500px] h-[500px]",
        };
    }
  };

  const glows = getSectionGlowStyles();

  // Subtle parallax offsets
  const mouseOffsetX = isTouchDevice ? 0 : mousePos.x * 15;
  const mouseOffsetY = isTouchDevice ? 0 : mousePos.y * 15;
  const scrollParallax1 = scrollY * 0.08;
  const scrollParallax2 = scrollY * 0.14;

  return (
    <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden bg-[#050609]">
      {/* Layer 1: Subtle moving ambient gradient background */}
      <div 
        className="absolute inset-0 transition-opacity duration-1000 ease-out"
        style={{
          background: "radial-gradient(ellipse 80% 50% at 50% -20%, rgba(14, 165, 233, 0.12), rgba(5, 6, 9, 0) 100%)",
        }}
      />

      {/* Layer 2: Parallax Subtle Developer Grid */}
      <div
        className="absolute inset-0 cyber-grid opacity-35"
        style={{
          transform: `translate3d(${mouseOffsetX * 0.4}px, ${-scrollParallax1 + mouseOffsetY * 0.4}px, 0)`,
          maskImage: "radial-gradient(ellipse at 50% 50%, black 40%, transparent 90%)",
          WebkitMaskImage: "radial-gradient(ellipse at 50% 50%, black 40%, transparent 90%)",
        }}
      />

      {/* Layer 3: Dynamic Ambient Glow Orbs */}
      <div
        className={`absolute rounded-full blur-[130px] transition-all duration-1000 ease-out ${glows.orb1}`}
        style={{
          transform: `translate3d(${mouseOffsetX * 1.2}px, ${-scrollParallax2 * 0.5 + mouseOffsetY * 1.2}px, 0)`,
        }}
      />
      <div
        className={`absolute rounded-full blur-[140px] transition-all duration-1000 ease-out ${glows.orb2}`}
        style={{
          transform: `translate3d(${-mouseOffsetX * 0.8}px, ${-scrollParallax1 * 0.7 - mouseOffsetY * 0.8}px, 0)`,
        }}
      />
      <div
        className={`absolute rounded-full blur-[120px] transition-all duration-1000 ease-out ${glows.orb3}`}
        style={{
          transform: `translate3d(${mouseOffsetX * 0.6}px, ${-scrollParallax2 * 0.3 + mouseOffsetY * 0.6}px, 0)`,
        }}
      />

      {/* Layer 4: Minimal Geometric Accent Lines / Shapes */}
      <div 
        className="absolute top-1/4 right-[10%] w-72 h-72 border border-cyan-500/10 rounded-full opacity-20 transition-transform duration-700"
        style={{
          transform: `translate3d(${mouseOffsetX * 0.5}px, ${-scrollParallax1 * 0.4}px, 0) rotate(${scrollY * 0.02}deg)`,
        }}
      />
      <div 
        className="absolute top-2/3 left-[8%] w-48 h-48 border border-indigo-500/10 rounded-xl opacity-20 transition-transform duration-700"
        style={{
          transform: `translate3d(${-mouseOffsetX * 0.5}px, ${-scrollParallax2 * 0.3}px, 0) rotate(${-scrollY * 0.03}deg)`,
        }}
      />

      {/* Layer 5: Canvas Floating Particle Sparkles */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-65" />

      {/* Subtle vignette boundary mask to keep dark luxury contrast */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#050609]/40 via-transparent to-[#050609]/90" />
    </div>
  );
};
