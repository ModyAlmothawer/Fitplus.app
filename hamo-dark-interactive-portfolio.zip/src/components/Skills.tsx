import React, { useState } from "react";
import { skillsData, Skill } from "../data/skills";
import { 
  Code2, 
  Palette, 
  FileCode, 
  FileCode2, 
  Atom, 
  Server, 
  Terminal, 
  Cpu, 
  Flame, 
  GitBranch, 
  Sparkles,
  Layers
} from "lucide-react";

export const Skills: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const categories = [
    { id: "all", label: "جميع التقنيات" },
    { id: "Frontend", label: "الواجهات (Frontend)" },
    { id: "Backend", label: "الخلفية (Backend)" },
    { id: "Core & Tools", label: "اللغات والأدوات (Core & Tools)" },
    { id: "Database & Cloud", label: "السحابة وقواعد البيانات (Cloud)" },
  ];

  const filteredSkills = selectedCategory === "all"
    ? skillsData
    : skillsData.filter((s) => s.category === selectedCategory);

  // Helper to render icon
  const getSkillIcon = (iconName: string) => {
    const props = { className: "w-6 h-6 transition-transform group-hover:scale-110 duration-300" };
    switch (iconName) {
      case "Code2": return <Code2 {...props} className="w-6 h-6 text-orange-400 group-hover:scale-110 duration-300" />;
      case "Palette": return <Palette {...props} className="w-6 h-6 text-sky-400 group-hover:scale-110 duration-300" />;
      case "FileCode": return <FileCode {...props} className="w-6 h-6 text-yellow-400 group-hover:scale-110 duration-300" />;
      case "FileCode2": return <FileCode2 {...props} className="w-6 h-6 text-blue-400 group-hover:scale-110 duration-300" />;
      case "Atom": return <Atom {...props} className="w-6 h-6 text-cyan-400 group-hover:scale-110 duration-300" />;
      case "Server": return <Server {...props} className="w-6 h-6 text-emerald-400 group-hover:scale-110 duration-300" />;
      case "Terminal": return <Terminal {...props} className="w-6 h-6 text-blue-300 group-hover:scale-110 duration-300" />;
      case "Cpu": return <Cpu {...props} className="w-6 h-6 text-orange-500 group-hover:scale-110 duration-300" />;
      case "Flame": return <Flame {...props} className="w-6 h-6 text-amber-500 group-hover:scale-110 duration-300" />;
      case "GitBranch": return <GitBranch {...props} className="w-6 h-6 text-red-400 group-hover:scale-110 duration-300" />;
      default: return <Sparkles {...props} className="w-6 h-6 text-cyan-400 group-hover:scale-110 duration-300" />;
    }
  };

  return (
    <section id="skills" className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-xs font-mono text-cyan-400 mb-4">
            <span>// المهارات والتقنيات</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white mb-6">
            ترسانة الأدوات والتقنيات البرمجية
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg leading-relaxed">
            مجموعة متكاملة من أحدث لغات البرمجة، أطر العمل والمنصات السحابية المستخدمة لبناء منتجات سريعة وقوية.
          </p>
        </div>

        {/* Interactive Filter Tabs (Clean segmented control) */}
        <div className="flex items-center justify-center flex-wrap gap-2 mb-12">
          <div className="p-1 rounded-xl bg-white/[0.03] border border-white/[0.06] flex flex-wrap justify-center gap-1">
            {categories.map((cat) => {
              const active = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                    active
                      ? "bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                      : "text-zinc-400 hover:text-white hover:bg-white/[0.04] border border-transparent"
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Skills Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-5">
          {filteredSkills.map((skill, index) => {
            return (
              <div
                key={skill.id}
                className="group relative p-5 rounded-2xl bg-[#090c12]/70 hover:bg-[#0d121c]/90 border border-white/[0.07] hover:border-cyan-500/40 transition-all duration-300 shadow-sm hover:shadow-[0_8px_30px_rgba(6,182,212,0.1)] hover:-translate-y-1.5 flex flex-col justify-between"
                style={{
                  animationDelay: `${index * 60}ms`,
                }}
              >
                {/* Subtle top ambient glow inside the card */}
                <div
                  className="absolute inset-x-0 top-0 h-1 rounded-t-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{ backgroundColor: skill.accentColor }}
                />

                <div>
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-white/[0.04] border border-white/[0.08] group-hover:border-white/[0.15] flex items-center justify-center transition-colors">
                      {getSkillIcon(skill.iconName)}
                    </div>
                    <span className="text-[11px] font-mono text-zinc-500 group-hover:text-cyan-400 transition-colors">
                      {skill.level}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white mb-1.5 group-hover:text-cyan-300 transition-colors">
                    {skill.name}
                  </h3>

                  <p className="text-xs text-zinc-400 leading-relaxed font-light mb-4">
                    {skill.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-white/[0.04] flex items-center justify-between text-[11px] text-zinc-500 font-mono">
                  <span>{skill.category}</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-500/40 group-hover:bg-cyan-400 transition-colors" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
