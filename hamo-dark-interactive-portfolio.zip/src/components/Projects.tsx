import React, { useState } from "react";
import { projectsData, Project } from "../data/projects";
import { ProjectModal } from "./ProjectModal";
import { ExternalLink, Github, Eye, ArrowLeft, Layers } from "lucide-react";

export const Projects: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <section id="projects" className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-xs font-mono text-cyan-400 mb-4">
            <span>// الأعمال المميزة</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white mb-6">
            مشاريع برمجية بنيت بأعلى درجات الإتقان
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg leading-relaxed">
            نماذج مختارة تجسّد القدرة على بناء حلول برمجية متكاملة من الواجهات الأمامية وصولاً إلى البنى التحتية السحابية.
          </p>
        </div>

        {/* 3 Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {projectsData.map((project, index) => {
            return (
              <div
                key={project.id}
                className="group relative flex flex-col justify-between rounded-2xl bg-[#0a0d14]/75 hover:bg-[#0e121c]/90 border border-white/[0.08] hover:border-cyan-500/40 shadow-[0_4px_24px_rgba(0,0,0,0.4)] hover:shadow-[0_12px_40px_rgba(6,182,212,0.15)] transition-all duration-300 hover:-translate-y-2 overflow-hidden backdrop-blur-md"
                style={{
                  animationDelay: `${index * 120}ms`,
                }}
              >
                {/* Image Showcase Container */}
                <div className="relative aspect-video w-full overflow-hidden bg-zinc-950">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover object-top transition-transform duration-500 ease-out group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  {/* Subtle dark gradient scrim overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a0d14] via-transparent to-transparent opacity-80" />

                  {/* Category Pill Tag */}
                  <div className="absolute top-3 right-3">
                    <span className="text-[11px] font-mono font-medium text-cyan-300 px-3 py-1 rounded-md bg-black/70 border border-cyan-500/25 backdrop-blur-md">
                      {project.category}
                    </span>
                  </div>

                  {/* Hover Quick View Trigger Overlay */}
                  <button
                    type="button"
                    onClick={() => setSelectedProject(project)}
                    className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/40 backdrop-blur-[2px] transition-opacity duration-300 cursor-pointer"
                    aria-label={`معاينة سريعة لمشروع ${project.title}`}
                  >
                    <span className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-500/90 text-white font-medium text-xs shadow-lg transform -translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                      <Eye className="w-4 h-4" />
                      <span>تفاصيل ومعاينة المشروع</span>
                    </span>
                  </button>
                </div>

                {/* Card Content */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-lg sm:text-xl font-bold text-white mb-2 group-hover:text-cyan-300 transition-colors line-clamp-2">
                      {project.title}
                    </h3>

                    <p className="text-sm text-zinc-400 leading-relaxed font-light mb-6 line-clamp-3">
                      {project.description}
                    </p>
                  </div>

                  <div>
                    {/* Technologies Tag List */}
                    <div className="flex flex-wrap gap-1.5 mb-6">
                      {project.technologies.slice(0, 4).map((tech) => (
                        <span
                          key={tech}
                          className="px-2.5 py-0.5 text-[11px] font-mono text-zinc-300 bg-white/[0.04] border border-white/[0.06] rounded-md"
                        >
                          {tech}
                        </span>
                      ))}
                      {project.technologies.length > 4 && (
                        <span className="px-2 py-0.5 text-[10px] font-mono text-cyan-400 bg-cyan-950/30 rounded-md">
                          +{project.technologies.length - 4}
                        </span>
                      )}
                    </div>

                    {/* Action Buttons: View Project & GitHub */}
                    <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => setSelectedProject(project)}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer group/btn"
                      >
                        <span>معاينة المشروع</span>
                        <ArrowLeft className="w-3.5 h-3.5 group-hover/btn:-translate-x-1 transition-transform" />
                      </button>

                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-zinc-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] hover:border-white/20 rounded-lg transition-colors"
                        aria-label={`كود مشروع ${project.title} على GitHub`}
                      >
                        <Github className="w-3.5 h-3.5 text-zinc-400" />
                        <span>GitHub</span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Editable note notice (helpful for client/developer) */}
        <div className="mt-12 text-center">
          <p className="text-xs text-zinc-500 font-mono">
            * يمكنك تحديث جميع بيانات ومشاريع هذا القسم عبر ملف <code className="text-cyan-400">src/data/projects.ts</code>
          </p>
        </div>
      </div>

      {/* Interactive Project Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
};
