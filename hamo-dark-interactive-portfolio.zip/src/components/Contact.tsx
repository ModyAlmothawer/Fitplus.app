import React, { useState } from "react";
import { siteConfig } from "../config/siteConfig";
import { useScrollReveal } from "../hooks/useScrollReveal";
import { 
  Mail, 
  MessageCircle, 
  Github, 
  Send, 
  Copy, 
  Check, 
  ExternalLink,
  SendHorizontal
} from "lucide-react";

export const Contact: React.FC = () => {
  const containerRef = useScrollReveal<HTMLElement>();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const body = `الاسم: ${formData.name}\nالبريد: ${formData.email}\n\nالرسالة:\n${formData.message}`;
    const mailtoUrl = `mailto:${siteConfig.email}?subject=${encodeURIComponent(
      formData.subject || "طلب تواصل لمشروع جديد — HAMO DARK"
    )}&body=${encodeURIComponent(body)}`;
    
    window.location.href = mailtoUrl;
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  const contactChannels = [
    {
      id: "email",
      label: "EMAIL",
      title: "البريد الإلكتروني",
      value: siteConfig.email,
      href: `mailto:${siteConfig.email}`,
      icon: Mail,
      accent: "text-cyan-400 group-hover:text-cyan-300",
      iconBg: "bg-cyan-500/10 border-cyan-500/20",
      hoverBorder: "hover:border-cyan-500/40",
      actionText: "إرسال بريد",
      copyable: true,
      ariaLabel: "إرسال بريد إلكتروني إلى algmalm044@gmail.com",
    },
    {
      id: "whatsapp",
      label: "WHATSAPP",
      title: "محادثة واتساب",
      value: `+${siteConfig.whatsappNumber}`,
      href: siteConfig.whatsappUrl,
      icon: MessageCircle,
      accent: "text-emerald-400 group-hover:text-emerald-300",
      iconBg: "bg-emerald-500/10 border-emerald-500/20",
      hoverBorder: "hover:border-emerald-500/40",
      actionText: "فتح المحادثة",
      copyable: false,
      ariaLabel: "محادثة فورية عبر واتساب على الرقم 201107311972",
    },
    {
      id: "github",
      label: "GITHUB",
      title: "مستودع الأكواد",
      value: `@${siteConfig.githubUsername}`,
      href: siteConfig.githubUrl,
      icon: Github,
      accent: "text-sky-300 group-hover:text-white",
      iconBg: "bg-white/[0.05] border-white/[0.1]",
      hoverBorder: "hover:border-sky-500/40",
      actionText: "زيارة الحساب",
      copyable: false,
      ariaLabel: "زيارة حساب GitHub الخاص بالمطور ModyAlmothawer",
    },
    {
      id: "telegram",
      label: "TELEGRAM",
      title: "قناة تليجرام",
      value: siteConfig.telegramUsername,
      href: siteConfig.telegramUrl,
      icon: SendHorizontal,
      accent: "text-blue-400 group-hover:text-blue-300",
      iconBg: "bg-blue-500/10 border-blue-500/20",
      hoverBorder: "hover:border-blue-500/40",
      actionText: "مراسلة Telegram",
      copyable: true,
      ariaLabel: "التواصل عبر تليجرام مع modark16",
    },
  ];

  return (
    <section id="contact" ref={containerRef} className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header with Stylized Typography */}
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-16">
          <div className="reveal-item delay-1 inline-flex items-center gap-2 px-3.5 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-xs font-mono text-cyan-400 mb-4 tracking-widest uppercase">
            <span>CONTACT · تواصل معي</span>
          </div>
          <h2 className="reveal-item delay-2 text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white mb-6">
            عندك فكرة مشروع؟ خلينا نحولها لحاجة حقيقية.
          </h2>
          <p className="reveal-item delay-3 text-zinc-400 text-base sm:text-lg leading-relaxed">
            سواء كنت ترغب في بدء مشروع جديد، بناء تطبيق موبايل، أو استشارة برمجية، يمكنك التواصل معي مباشرة عبر القنوات المعتمدة أدناه.
          </p>
        </div>

        {/* 4 Polished Contact Options Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-12">
          {contactChannels.map((channel, index) => {
            const Icon = channel.icon;
            const delayClass = `delay-${index + 1}`;
            return (
              <div
                key={channel.id}
                className={`reveal-item ${delayClass} group relative p-6 rounded-2xl bg-[#090c12]/80 hover:bg-[#0e121c]/95 border border-white/[0.08] ${channel.hoverBorder} transition-all duration-300 hover:-translate-y-1.5 shadow-[0_4px_20px_rgba(0,0,0,0.4)] flex flex-col justify-between`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${channel.iconBg}`}>
                      <Icon className={`w-6 h-6 ${channel.accent} transition-transform duration-300 group-hover:scale-110`} />
                    </div>
                    <span className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase">
                      {channel.label}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white mb-1 group-hover:text-cyan-300 transition-colors">
                    {channel.title}
                  </h3>

                  <p className="text-xs sm:text-sm font-mono text-zinc-400 break-all mb-4">
                    {channel.value}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/[0.06] flex items-center gap-2">
                  <a
                    href={channel.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={channel.ariaLabel}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-mono font-medium text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] rounded-lg transition-colors"
                  >
                    <span>{channel.actionText}</span>
                    <ExternalLink className="w-3.5 h-3.5 text-zinc-400 group-hover:text-cyan-300 transition-colors" />
                  </a>

                  {channel.copyable && (
                    <button
                      type="button"
                      onClick={() => handleCopy(channel.value, channel.id)}
                      className="p-2 rounded-lg bg-white/[0.02] hover:bg-white/[0.06] border border-white/[0.06] text-zinc-400 hover:text-white transition-colors cursor-pointer"
                      aria-label={`نسخ ${channel.title}`}
                      title={`نسخ ${channel.title}`}
                    >
                      {copiedKey === channel.id ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Message Form */}
        <div className="reveal-item delay-3 max-w-3xl mx-auto p-6 sm:p-8 rounded-2xl bg-[#090c12]/85 border border-white/[0.08] shadow-[0_8px_32px_rgba(0,0,0,0.5)] backdrop-blur-md">
          <div className="text-center mb-6">
            <h3 className="text-xl font-bold text-white mb-1">إرسال تفاصيل الفكرة أو المشروع</h3>
            <p className="text-xs text-zinc-400">
              سيتم تجهيز رسالتك وتوجيهها مباشرة إلى بريدي الإلكتروني.
            </p>
          </div>

          {submitted && (
            <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-sm mb-6 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>تم تحضير الرسالة وفتح تطبيق البريد لمتابعة الإرسال بنجاح.</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5 uppercase">
                  الاسم الكريم
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="أدخل اسمك"
                  className="w-full px-4 py-2.5 rounded-xl bg-black/50 border border-white/[0.1] focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-zinc-600 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5 uppercase">
                  بريدك الإلكتروني
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="name@example.com"
                  className="w-full px-4 py-2.5 rounded-xl bg-black/50 border border-white/[0.1] focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-zinc-600 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1.5 uppercase">
                موضوع المشروع
              </label>
              <input
                type="text"
                required
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                placeholder="مثال: تطبيق موبايل، منصة ويب، استشارة برمجية"
                className="w-full px-4 py-2.5 rounded-xl bg-black/50 border border-white/[0.1] focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-zinc-600 transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-zinc-400 mb-1.5 uppercase">
                تفاصيل الفكرة
              </label>
              <textarea
                rows={4}
                required
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="صف فكرة المشروع، الخصائص الأساسية، وأي تفاصيل تقنية ترغب بها..."
                className="w-full px-4 py-2.5 rounded-xl bg-black/50 border border-white/[0.1] focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-zinc-600 transition-colors resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 py-3 px-6 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 shadow-[0_0_20px_rgba(6,182,212,0.25)] hover:shadow-[0_0_30px_rgba(6,182,212,0.35)] transition-all duration-300 active:scale-98 cursor-pointer"
            >
              <Send className="w-4 h-4 text-cyan-200" />
              <span>إرسال تفاصيل الفكرة</span>
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};
