import React, { useState } from "react";
import { siteConfig } from "../config/siteConfig";
import { 
  Mail, 
  MessageCircle, 
  Github, 
  Send, 
  Copy, 
  Check, 
  ExternalLink,
  Sparkles 
} from "lucide-react";

export const Contact: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(siteConfig.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Create mailto link with encoded subject and body
    const body = `الاسم: ${formData.name}\nالبريد: ${formData.email}\n\nالرسالة:\n${formData.message}`;
    const mailtoUrl = `mailto:${siteConfig.email}?subject=${encodeURIComponent(
      formData.subject || "طلب تواصل لمشروع برمجيات جديد"
    )}&body=${encodeURIComponent(body)}`;
    
    window.location.href = mailtoUrl;
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-xs font-mono text-cyan-400 mb-4">
            <span>// تواصل معي</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white mb-6">
            عندك فكرة مشروع؟ خلينا نحولها لحاجة حقيقية.
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg leading-relaxed">
            سواء كنت ترغب في بدء مشروع جديد، تطوير تطبيق، أو استشارة تقنية، أنا جاهز للمساعدة في تحويل رؤيتك إلى واقع برمجي ملموس.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start max-w-5xl mx-auto">
          {/* Quick Contact Cards (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            {/* WhatsApp Card */}
            <a
              href={siteConfig.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="group p-5 rounded-2xl bg-[#0a0d14]/80 hover:bg-[#0f1420] border border-white/[0.08] hover:border-emerald-500/40 shadow-sm hover:shadow-[0_4px_24px_rgba(16,185,129,0.15)] transition-all duration-300 flex items-center justify-between"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
                  <MessageCircle className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs text-zinc-400 font-mono">دردشة سريعة ومباشرة</div>
                  <div className="text-base font-bold text-white group-hover:text-emerald-300 transition-colors">
                    WhatsApp
                  </div>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-zinc-500 group-hover:text-emerald-400 transition-colors" />
            </a>

            {/* Email Card with Copy Affordance */}
            <div className="group p-5 rounded-2xl bg-[#0a0d14]/80 border border-white/[0.08] hover:border-cyan-500/40 shadow-sm transition-all duration-300">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs text-zinc-400 font-mono">البريد الإلكتروني الرسمي</div>
                    <div className="text-base font-bold text-white font-mono break-all text-sm sm:text-base">
                      {siteConfig.email}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-white/[0.06]">
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="flex-1 inline-flex items-center justify-center gap-2 py-2 px-3 text-xs font-medium text-cyan-300 bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/20 rounded-lg transition-colors cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-300">تم نسخ البريد!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ البريد الإلكتروني</span>
                    </>
                  )}
                </button>

                <a
                  href={`mailto:${siteConfig.email}`}
                  className="py-2 px-3 text-xs font-medium text-zinc-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] rounded-lg transition-colors"
                >
                  إرسال مباشر
                </a>
              </div>
            </div>

            {/* GitHub Profile Card */}
            <a
              href={siteConfig.github}
              target="_blank"
              rel="noopener noreferrer"
              className="group p-5 rounded-2xl bg-[#0a0d14]/80 hover:bg-[#0f1420] border border-white/[0.08] hover:border-white/20 shadow-sm transition-all duration-300 flex items-center justify-between"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-white/[0.05] border border-white/[0.1] flex items-center justify-center text-zinc-200 group-hover:scale-105 transition-transform">
                  <Github className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs text-zinc-400 font-mono">مستودعات الأكواد والمساهمات</div>
                  <div className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                    GitHub Profile
                  </div>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-zinc-500 group-hover:text-white transition-colors" />
            </a>

            {/* Config tip */}
            <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-500/15 text-xs text-zinc-400 font-mono">
              <span className="text-cyan-300 font-semibold block mb-1">💡 إعدادات الروابط:</span>
              جميع قنوات التواصل والروابط مُدارة مركزياً عبر <code className="text-cyan-200">src/config/siteConfig.ts</code>.
            </div>
          </div>

          {/* Interactive Message Form (7 cols) */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-[#0a0d14]/90 border border-white/[0.08] shadow-[0_8px_32px_rgba(0,0,0,0.5)] backdrop-blur-md">
            <h3 className="text-xl font-bold text-white mb-2">أرسل رسالة سريعة</h3>
            <p className="text-xs sm:text-sm text-zinc-400 mb-6">
              املأ النموذج وسيتم توجيه رسالتك مباشرة لبدء المحادثة.
            </p>

            {submitted && (
              <div className="p-4 rounded-xl bg-emerald-950/50 border border-emerald-500/30 text-emerald-300 text-sm mb-6 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>تم تجهيز رسالتك وفتح تطبيق البريد لمتابعة الإرسال بنجاح.</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono text-zinc-400 mb-1.5">
                    الاسم الكامل
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="مثال: أحمد محمد"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/[0.1] focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-zinc-600 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-zinc-400 mb-1.5">
                    البريد الإلكتروني
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="name@example.com"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/[0.1] focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-zinc-600 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">
                  نوع المشروع / الموضوع
                </label>
                <input
                  type="text"
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="مثال: بناء منصة ويب تجارية / تطبيق موبايل"
                  className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/[0.1] focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-zinc-600 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1.5">
                  تفاصيل المشروع أو الاستفسار
                </label>
                <textarea
                  rows={4}
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="اكتب نبذة مختصرة عن فكرة مشروعك والجدول الزمني المتوقع..."
                  className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/[0.1] focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-zinc-600 transition-colors resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 py-3 px-6 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 shadow-[0_0_20px_rgba(6,182,212,0.25)] hover:shadow-[0_0_30px_rgba(6,182,212,0.35)] transition-all duration-300 active:scale-98 cursor-pointer"
              >
                <Send className="w-4 h-4 text-cyan-200" />
                <span>إرسال تفاصيل الفكرة</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
