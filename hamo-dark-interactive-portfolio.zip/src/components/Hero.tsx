import React from "react";
import { siteConfig } from "../config/siteConfig";
import { useScrollReveal } from "../hooks/useScrollReveal";
import { ArrowLeft, MessageSquare, Code2, Sparkles, Layers, ShieldCheck } from "lucide-react";

interface HeroProps {
  onNavigate: (sectionId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  const containerRef = useScrollReveal<HTMLElement>();

  return (
    <section
      id="hero"
      ref={containerRef}
      className="relative min-h-[95vh] flex items-center justify-center pt-28 pb-20 overflow-hidden"
    >
      {/* Luxury Ambient Section Backdrop */}
      <div className="absolute inset-0 pointer-events-none -z-10 overflow-hidden">
        {/* Soft glowing beacon rings */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] sm:w-[750px] h-[550px] sm:h-[750px] rounded-full border border-cyan-500/[0.08] animate-pulse-ambient" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[380px] sm:w-[500px] h-[380px] sm:h-[500px] rounded-full border border-sky-400/[0.07] animate-float-slow" />
        {/* Soft ambient center glow */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[420px] h-[420px] rounded-full bg-cyan-500/[0.09] blur-[110px] animate-float-slow" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-8 relative z-10">
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
          {/* Availability Status Badge */}
          <div className="reveal-item delay-1 inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-cyan-950/40 border border-cyan-500/25 text-xs text-cyan-300 mb-8 backdrop-blur-md shadow-[0_0_15px_rgba(6,182,212,0.15)]">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400" />
            </span>
            <span className="font-mono tracking-widest text-[11px] font-semibold">{siteConfig.status}</span>
          </div>

          {/* Main Title / Brand Display (Strongest visual identity) */}
          <div className="reveal-item delay-2 space-y-4 mb-8">
            <div className="inline-block relative">
              <h1 className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-display font-extrabold tracking-[0.14em] sm:tracking-[0.18em] select-none text-white cyber-glow-title leading-[1.15] sm:leading-[1.12]">
                <span className="text-transparent bg-clip-text bg-gradient-to-b from-white via-zinc-200 to-zinc-400">
                  HAMO
                </span>{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
                  DARK
                </span>
              </h1>
            </div>

            {/* Stylized Developer Subtitle */}
            <div className="flex items-center justify-center gap-2 sm:gap-3 flex-wrap pt-2 font-mono">
              <span className="px-3.5 py-1.5 rounded-md bg-white/[0.04] border border-white/[0.08] text-xs sm:text-sm font-semibold tracking-[0.18em] text-cyan-300 uppercase">
                FULL-STACK DEVELOPER
              </span>
              <span className="text-zinc-600 font-mono">/</span>
              <span className="px-3.5 py-1.5 rounded-md bg-white/[0.04] border border-white/[0.08] text-xs sm:text-sm font-semibold tracking-[0.18em] text-sky-300 uppercase">
                APP DEVELOPER
              </span>
            </div>
          </div>

          {/* Short Bio with Generous Breathing Room */}
          <p className="reveal-item delay-3 text-base sm:text-lg md:text-xl text-zinc-300/90 max-w-2xl leading-[1.8] sm:leading-[1.9] mb-12 text-balance font-light">
            {siteConfig.shortBio}
          </p>

          {/* Action CTA Buttons */}
          <div className="reveal-item delay-4 flex flex-wrap items-center justify-center gap-4 sm:gap-5 w-full sm:w-auto mb-16">
            <button
              type="button"
              onClick={() => onNavigate("projects")}
              className="group relative inline-flex items-center justify-center gap-2.5 px-8 py-3.5 text-base font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 rounded-xl shadow-[0_0_25px_rgba(6,182,212,0.25)] hover:shadow-[0_0_35px_rgba(6,182,212,0.4)] transition-all duration-300 active:scale-98 cursor-pointer transform-gpu"
            >
              <span>شوف شغلي</span>
              <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate("contact")}
              className="inline-flex items-center justify-center gap-2.5 px-8 py-3.5 text-base font-semibold text-zinc-200 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.12] hover:border-cyan-500/40 rounded-xl transition-all duration-300 active:scale-98 cursor-pointer backdrop-blur-sm transform-gpu"
            >
              <MessageSquare className="w-5 h-5 text-cyan-400" />
              <span>كلمني</span>
            </button>
          </div>

          {/* Developer Pillars Dock */}
          <div className="reveal-item delay-5 grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 w-full max-w-3xl pt-8 border-t border-white/[0.06]">
            <div className="flex flex-col items-center p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-cyan-500/20 transition-colors">
              <Code2 className="w-5 h-5 text-cyan-400 mb-2" />
              <span className="text-xs text-zinc-400">كود نظيف وقابل للتوسع</span>
              <span className="text-xs font-mono font-semibold tracking-wider text-white mt-1 uppercase">Clean Code</span>
            </div>

            <div className="flex flex-col items-center p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-cyan-500/20 transition-colors">
              <Sparkles className="w-5 h-5 text-sky-400 mb-2" />
              <span className="text-xs text-zinc-400">واجهات مستخدم سريعة</span>
              <span className="text-xs font-mono font-semibold tracking-wider text-white mt-1 uppercase">Modern UI/UX</span>
            </div>

            <div className="flex flex-col items-center p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-cyan-500/20 transition-colors">
              <Layers className="w-5 h-5 text-indigo-400 mb-2" />
              <span className="text-xs text-zinc-400">أنظمة خلفية وقواعد</span>
              <span className="text-xs font-mono font-semibold tracking-wider text-white mt-1 uppercase">Full-Stack</span>
            </div>

            <div className="flex flex-col items-center p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-cyan-500/20 transition-colors">
              <ShieldCheck className="w-5 h-5 text-teal-400 mb-2" />
              <span className="text-xs text-zinc-400">أمان وأداء فائق</span>
              <span className="text-xs font-mono font-semibold tracking-wider text-white mt-1 uppercase">Optimized</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
