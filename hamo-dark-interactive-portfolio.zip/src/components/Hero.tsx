import React from "react";
import { siteConfig } from "../config/siteConfig";
import { ArrowLeft, MessageSquare, Code2, Sparkles, Terminal, Layers, ShieldCheck } from "lucide-react";

interface HeroProps {
  onNavigate: (sectionId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <section
      id="hero"
      className="relative min-h-[92vh] flex items-center justify-center pt-24 pb-16 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-12">
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
          {/* Availability Status Badge (Clean, elegant) */}
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-cyan-950/40 border border-cyan-500/25 text-xs text-cyan-300 mb-8 backdrop-blur-md shadow-[0_0_15px_rgba(6,182,212,0.15)] animate-in fade-in duration-500">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400" />
            </span>
            <span className="font-medium">{siteConfig.status}</span>
          </div>

          {/* Main Title / Brand Display */}
          <div className="space-y-4 mb-6">
            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight text-white select-none">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-100 to-zinc-400">
                HAMO
              </span>{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
                DARK
              </span>
            </h1>

            <p className="text-lg sm:text-xl md:text-2xl font-semibold text-zinc-300 tracking-wide font-mono">
              Full-Stack Developer & App Developer
            </p>
          </div>

          {/* Short Bio */}
          <p className="text-base sm:text-lg md:text-xl text-zinc-400 max-w-2xl leading-relaxed mb-10 text-balance font-light">
            {siteConfig.shortBio}
          </p>

          {/* Action CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-5 w-full sm:w-auto mb-16">
            <button
              type="button"
              onClick={() => onNavigate("projects")}
              className="group relative inline-flex items-center justify-center gap-2.5 px-8 py-3.5 text-base font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 rounded-xl shadow-[0_0_25px_rgba(6,182,212,0.25)] hover:shadow-[0_0_35px_rgba(6,182,212,0.4)] transition-all duration-300 active:scale-98 cursor-pointer"
            >
              <span>شوف شغلي</span>
              <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            </button>

            <button
              type="button"
              onClick={() => onNavigate("contact")}
              className="inline-flex items-center justify-center gap-2.5 px-8 py-3.5 text-base font-semibold text-zinc-200 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.12] hover:border-cyan-500/40 rounded-xl transition-all duration-300 active:scale-98 cursor-pointer backdrop-blur-sm"
            >
              <MessageSquare className="w-5 h-5 text-cyan-400" />
              <span>كلمني</span>
            </button>
          </div>

          {/* Subtle Developer Highlights Dock */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 w-full max-w-3xl pt-8 border-t border-white/[0.06]">
            <div className="flex flex-col items-center p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-cyan-500/20 transition-colors">
              <Code2 className="w-5 h-5 text-cyan-400 mb-1.5" />
              <span className="text-xs text-zinc-400">كود نظيف وقابل للتوسع</span>
              <span className="text-sm font-semibold text-white mt-0.5">Clean Architecture</span>
            </div>

            <div className="flex flex-col items-center p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-cyan-500/20 transition-colors">
              <Sparkles className="w-5 h-5 text-sky-400 mb-1.5" />
              <span className="text-xs text-zinc-400">واجهات مستخدم سريعة</span>
              <span className="text-sm font-semibold text-white mt-0.5">Modern UI/UX</span>
            </div>

            <div className="flex flex-col items-center p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-cyan-500/20 transition-colors">
              <Layers className="w-5 h-5 text-indigo-400 mb-1.5" />
              <span className="text-xs text-zinc-400">أنظمة خلفية وقواعد</span>
              <span className="text-sm font-semibold text-white mt-0.5">Full-Stack Core</span>
            </div>

            <div className="flex flex-col items-center p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-cyan-500/20 transition-colors">
              <ShieldCheck className="w-5 h-5 text-teal-400 mb-1.5" />
              <span className="text-xs text-zinc-400">أمان وأداء فائق</span>
              <span className="text-sm font-semibold text-white mt-0.5">High Performance</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
