import React from "react";
import { siteConfig } from "../config/siteConfig";
import { 
  Globe, 
  Smartphone, 
  Server, 
  Flame, 
  Workflow, 
  Layout, 
  Terminal, 
  CheckCircle2, 
  Cpu
} from "lucide-react";

export const About: React.FC = () => {
  const specializations = [
    {
      title: "تطبيقات الويب (Web Applications)",
      desc: "بناء مواقع وتطبيقات Single Page متطورة، فائقة السرعة، متوافقة مع محركات البحث وتعمل بكفاءة على كافة الشاشات.",
      icon: Globe,
      accent: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20",
    },
    {
      title: "تطبيقات الموبايل (Mobile Applications)",
      desc: "تطوير تطبيقات متعددة المنصات لنظامي iOS وAndroid بأداء استثنائي وتجربة استخدام ناعمة وسريعة.",
      icon: Smartphone,
      accent: "text-sky-400 bg-sky-500/10 border-sky-500/20",
    },
    {
      title: "الأنظمة الخلفية (Backend Systems)",
      desc: "هندسة معمارية قوية ومستقرة، معالجة غير متزامنة، وتحسين استعلامات قواعد البيانات لتتحمل أعباء العمل العالية.",
      icon: Server,
      accent: "text-indigo-400 bg-indigo-500/10 border-indigo-500/20",
    },
    {
      title: "الحلول السحابية و Firebase",
      desc: "دمج المزامنة في الوقت الفعلي Realtime Data، والمصادقة الآمنة Authentication، والبنية التحتية السحابية السريعة.",
      icon: Flame,
      accent: "text-amber-400 bg-amber-500/10 border-amber-500/20",
    },
    {
      title: "واجهات البرمجة (APIs)",
      desc: "تصميم وبناء واجهات RESTful APIs محمية، موثقة ومعيارية للتواصل السلس بين مختلف الأنظمة والأجهزة.",
      icon: Workflow,
      accent: "text-teal-400 bg-teal-500/10 border-teal-500/20",
    },
    {
      title: "واجهات حديثة (Modern UI/UX)",
      desc: "تحويل الأفكار إلى واجهات فنية مريحة للعين، تفاعلية وسريعة مع انتقالات بصرية وميكرو-انيميشن مدروس بعناية.",
      icon: Layout,
      accent: "text-purple-400 bg-purple-500/10 border-purple-500/20",
    },
  ];

  return (
    <section id="about" className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-xs font-mono text-cyan-400 mb-4">
            <span>// نبذة عني</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white mb-6">
            شغف برمجي يجمع بين دقة الأداء وجمال التجربة
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg leading-relaxed">
            أنا مطوّر برمجيات متكامل أركز على تحويل التحديات البرمجية المعقدة إلى منتجات رقمية أنيقة، سريعة ومجدية تقنياً وتجارياً، مستنداً إلى أحدث المعايير البرمجية.
          </p>
        </div>

        {/* Bento Grid: Developer Card + Capability Highlights */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-stretch">
          {/* Main Developer Profile Card (4 Columns on Desktop) */}
          <div className="lg:col-span-4 flex flex-col justify-between p-6 sm:p-8 rounded-2xl bg-[#0b0e14]/70 border border-white/[0.08] shadow-[0_8px_32px_rgba(0,0,0,0.4)] backdrop-blur-xl relative overflow-hidden group hover:border-cyan-500/30 transition-all duration-300">
            {/* Top decorative gradient glow */}
            <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-cyan-500 via-sky-400 to-indigo-500" />
            
            <div>
              {/* Developer identity badge */}
              <div className="flex items-center justify-between mb-6">
                <div>
                  <span className="text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider">
                    Full-Stack Engineer
                  </span>
                  <h3 className="text-2xl font-bold text-white mt-0.5">{siteConfig.name}</h3>
                </div>
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/30 flex items-center justify-center text-cyan-300 font-mono font-bold text-lg">
                  HD
                </div>
              </div>

              {/* Developer Terminal Snippet */}
              <div className="p-4 rounded-xl bg-black/50 border border-white/[0.06] font-mono text-xs text-zinc-300 space-y-2 mb-6">
                <div className="flex items-center gap-1.5 pb-2 border-b border-white/[0.08]">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                  <span className="text-[10px] text-zinc-400 mr-auto">hamo-dark.config.ts</span>
                </div>
                <div className="text-zinc-400">
                  <span className="text-cyan-400">const</span> developer = &#123;
                </div>
                <div className="pr-4 text-zinc-300">
                  name: <span className="text-emerald-300">"{siteConfig.name}"</span>,
                </div>
                <div className="pr-4 text-zinc-300">
                  focus: <span className="text-emerald-300">"Modern Web & Mobile"</span>,
                </div>
                <div className="pr-4 text-zinc-300">
                  mindset: <span className="text-sky-300">"Fast · Clean · Scalable"</span>,
                </div>
                <div className="pr-4 text-zinc-300">
                  status: <span className="text-amber-300">"Building Real Value"</span>
                </div>
                <div className="text-zinc-400">&#125;;</div>
              </div>

              {/* Value propositions */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3 text-sm text-zinc-300">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>حلول برمجية مخصصة بدون قوالب جاهزة</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-zinc-300">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>معايير برمجية عالمية واختبارات دقيقة</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-zinc-300">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>التزام بالمواعيد ودعم فني مستمر</span>
                </div>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="pt-6 border-t border-white/[0.06] grid grid-cols-3 gap-2 text-center">
              <div>
                <div className="text-xl font-bold font-mono text-cyan-400">{siteConfig.experienceYears}</div>
                <div className="text-[11px] text-zinc-400 mt-0.5">سنوات خبرة</div>
              </div>
              <div>
                <div className="text-xl font-bold font-mono text-white">{siteConfig.completedProjectsCount}</div>
                <div className="text-[11px] text-zinc-400 mt-0.5">مشروع منجز</div>
              </div>
              <div>
                <div className="text-xl font-bold font-mono text-sky-400">{siteConfig.satisfactionRate}</div>
                <div className="text-[11px] text-zinc-400 mt-0.5">رضا العملاء</div>
              </div>
            </div>
          </div>

          {/* 6 Specialization Cards (8 Columns on Desktop) */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            {specializations.map((spec, index) => {
              const Icon = spec.icon;
              return (
                <div
                  key={index}
                  className="p-6 rounded-2xl bg-[#0b0e14]/50 hover:bg-[#0f131a]/80 border border-white/[0.06] hover:border-cyan-500/25 transition-all duration-300 shadow-sm hover:shadow-[0_8px_24px_rgba(0,0,0,0.3)] hover:-translate-y-1 group"
                >
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center border mb-4 ${spec.accent}`}>
                    <Icon className="w-5 h-5 transition-transform duration-300 group-hover:scale-110" />
                  </div>
                  <h4 className="text-lg font-semibold text-white mb-2 group-hover:text-cyan-300 transition-colors">
                    {spec.title}
                  </h4>
                  <p className="text-sm text-zinc-400 leading-relaxed font-light">
                    {spec.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
