import React from "react";
import { siteConfig } from "../config/siteConfig";
import { useScrollReveal } from "../hooks/useScrollReveal";
import { 
  Globe, 
  Smartphone, 
  Server, 
  Flame, 
  Workflow, 
  Layout, 
  CheckCircle2
} from "lucide-react";

export const About: React.FC = () => {
  const containerRef = useScrollReveal<HTMLElement>();

  const specializations = [
    {
      title: "تطبيقات الويب (Web Applications)",
      enTitle: "MODERN WEB APPS",
      desc: "بناء مواقع وتطبيقات Single Page متطورة، فائقة السرعة، متوافقة مع محركات البحث وتعمل بكفاءة على كافة الشاشات.",
      icon: Globe,
      accent: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20",
    },
    {
      title: "تطبيقات الموبايل (Mobile Applications)",
      enTitle: "CROSS-PLATFORM MOBILE",
      desc: "تطوير تطبيقات متعددة المنصات لنظامي iOS وAndroid بأداء استثنائي وتجربة استخدام ناعمة وسريعة.",
      icon: Smartphone,
      accent: "text-sky-400 bg-sky-500/10 border-sky-500/20",
    },
    {
      title: "الأنظمة الخلفية (Backend Systems)",
      enTitle: "SCALABLE BACKEND",
      desc: "هندسة معمارية قوية ومستقرة، معالجة غير متزامنة، وتحسين استعلامات قواعد البيانات لتتحمل أعباء العمل العالية.",
      icon: Server,
      accent: "text-indigo-400 bg-indigo-500/10 border-indigo-500/20",
    },
    {
      title: "الحلول السحابية و Firebase",
      enTitle: "CLOUD & REALTIME",
      desc: "دمج المزامنة في الوقت الفعلي Realtime Data، والمصادقة الآمنة Authentication، والبنية التحتية السحابية السريعة.",
      icon: Flame,
      accent: "text-amber-400 bg-amber-500/10 border-amber-500/20",
    },
    {
      title: "واجهات البرمجة (APIs)",
      enTitle: "REST & WEBSOCKET APIS",
      desc: "تصميم وبناء واجهات RESTful APIs محمية، موثقة ومعيارية للتواصل السلس بين مختلف الأنظمة والأجهزة.",
      icon: Workflow,
      accent: "text-teal-400 bg-teal-500/10 border-teal-500/20",
    },
    {
      title: "واجهات حديثة (Modern UI/UX)",
      enTitle: "ENGINEERED INTERACTION",
      desc: "تحويل الأفكار إلى واجهات فنية مريحة للعين، تفاعلية وسريعة مع انتقالات بصرية وميكرو-انيميشن مدروس بعناية.",
      icon: Layout,
      accent: "text-purple-400 bg-purple-500/10 border-purple-500/20",
    },
  ];

  return (
    <section id="about" ref={containerRef} className="relative py-28 sm:py-36 overflow-hidden">
      {/* Luxury Ambient Section Backdrop */}
      <div className="absolute inset-0 pointer-events-none -z-10 overflow-hidden">
        <div className="absolute top-1/4 right-1/4 w-[450px] h-[450px] rounded-full bg-indigo-600/[0.08] blur-[110px] animate-float-slow" />
        <div className="absolute bottom-1/3 left-1/4 w-[420px] h-[420px] rounded-full bg-purple-600/[0.07] blur-[120px] animate-float-reverse" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] border border-indigo-500/[0.04] rounded-full animate-pulse-ambient" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header with Spacious Line-Heights */}
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="reveal-item delay-1 inline-flex items-center gap-2 px-3.5 py-1 rounded-md bg-white/[0.04] border border-white/[0.08] text-xs font-mono text-cyan-400 mb-5 tracking-widest uppercase">
            <span>ABOUT ME · نبذة عني</span>
          </div>
          <h2 className="reveal-item delay-2 text-3xl sm:text-4xl md:text-5xl font-bold tracking-normal leading-[1.4] sm:leading-[1.45] text-white mb-6 text-balance">
            شغف برمجي يجمع بين دقة الأداء وجمال التجربة
          </h2>
          <p className="reveal-item delay-3 text-zinc-400 text-base sm:text-lg leading-[1.8] sm:leading-[1.9] max-w-2xl">
            أنا مطوّر برمجيات متكامل أركز على تحويل التحديات البرمجية المعقدة إلى منتجات رقمية أنيقة، سريعة ومجدية تقنياً، مستنداً إلى أحدث المعايير البرمجية.
          </p>
        </div>

        {/* Bento Grid: Developer Card + Capability Highlights */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-stretch">
          {/* Main Developer Profile Card (4 Columns on Desktop) */}
          <div className="reveal-item delay-2 lg:col-span-4 flex flex-col justify-between p-6 sm:p-8 rounded-2xl bg-[#0a0d14]/75 border border-white/[0.08] shadow-[0_8px_32px_rgba(0,0,0,0.4)] backdrop-blur-xl relative overflow-hidden group hover:border-cyan-500/30 transition-all duration-300">
            {/* Top decorative gradient line */}
            <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-cyan-500 via-sky-400 to-indigo-500" />
            
            <div>
              {/* Developer identity badge */}
              <div className="flex items-center justify-between mb-6">
                <div>
                  <span className="text-[11px] font-mono text-cyan-400 font-bold uppercase tracking-[0.2em] block">
                    ENGINEER PROFILE
                  </span>
                  <h3 className="text-2xl font-display font-extrabold text-white mt-1 tracking-wider leading-[1.3]">{siteConfig.name}</h3>
                </div>
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/30 flex items-center justify-center text-cyan-300 font-mono font-bold text-lg">
                  HD
                </div>
              </div>

              {/* Developer Terminal Snippet */}
              <div className="p-4 rounded-xl bg-black/60 border border-white/[0.06] font-mono text-xs text-zinc-300 space-y-2 mb-6">
                <div className="flex items-center gap-1.5 pb-2 border-b border-white/[0.08]">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                  <span className="text-[10px] text-zinc-500 mr-auto">developer.ts</span>
                </div>
                <div className="text-zinc-400">
                  <span className="text-cyan-400">const</span> developer = &#123;
                </div>
                <div className="pr-4 text-zinc-300">
                  name: <span className="text-emerald-300">"{siteConfig.name}"</span>,
                </div>
                <div className="pr-4 text-zinc-300">
                  specialty: <span className="text-emerald-300">"Full-Stack & Mobile"</span>,
                </div>
                <div className="pr-4 text-zinc-300">
                  mindset: <span className="text-sky-300">"Speed · Reliability · Scalability"</span>,
                </div>
                <div className="pr-4 text-zinc-300">
                  delivery: <span className="text-amber-300">"Production-Grade Software"</span>
                </div>
                <div className="text-zinc-400">&#125;;</div>
              </div>

              {/* Genuine Value propositions */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3 text-sm text-zinc-300 leading-relaxed">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>حلول برمجية مخصصة ومصممة من الصفر</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-zinc-300 leading-relaxed">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>معايير أمان عالية واختبارات دقيقة للمكونات</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-zinc-300 leading-relaxed">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>بنية تحتية قابلة للتوسع والصيانة بسهولة</span>
                </div>
              </div>
            </div>

            {/* Quick Competency Badges */}
            <div className="pt-6 border-t border-white/[0.06] grid grid-cols-3 gap-2 text-center font-mono">
              <div className="p-2 rounded-lg bg-white/[0.02] border border-white/[0.04]">
                <div className="text-xs font-bold text-cyan-400 tracking-wider">FULL-STACK</div>
                <div className="text-[10px] text-zinc-400 mt-1">ويب وموبايل</div>
              </div>
              <div className="p-2 rounded-lg bg-white/[0.02] border border-white/[0.04]">
                <div className="text-xs font-bold text-white tracking-wider">TYPESAFE</div>
                <div className="text-[10px] text-zinc-400 mt-1">موثوقية الكود</div>
              </div>
              <div className="p-2 rounded-lg bg-white/[0.02] border border-white/[0.04]">
                <div className="text-xs font-bold text-sky-400 tracking-wider">SCALABLE</div>
                <div className="text-[10px] text-zinc-400 mt-1">بنية سحابية</div>
              </div>
            </div>
          </div>

          {/* 6 Specialization Cards (8 Columns on Desktop) */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            {specializations.map((spec, index) => {
              const Icon = spec.icon;
              const delayClass = `delay-${(index % 6) + 1}`;
              return (
                <div
                  key={index}
                  className={`reveal-item ${delayClass} p-6 sm:p-7 rounded-2xl bg-[#0a0d14]/55 hover:bg-[#0e121a]/90 border border-white/[0.06] hover:border-cyan-500/25 transition-all duration-300 shadow-sm hover:shadow-[0_8px_24px_rgba(0,0,0,0.3)] hover:-translate-y-1 group backdrop-blur-sm`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center border ${spec.accent}`}>
                      <Icon className="w-5 h-5 transition-transform duration-300 group-hover:scale-110" />
                    </div>
                    <span className="text-[10px] font-mono tracking-widest text-zinc-500 group-hover:text-cyan-400 transition-colors uppercase">
                      {spec.enTitle}
                    </span>
                  </div>
                  <h4 className="text-base sm:text-lg font-semibold text-white mb-2 leading-[1.4] group-hover:text-cyan-300 transition-colors">
                    {spec.title}
                  </h4>
                  <p className="text-sm text-zinc-400 leading-[1.75] font-light">
                    {spec.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
