import React from "react";
import { siteConfig } from "../config/siteConfig";
import { Github, MessageCircle, Mail, ArrowUp } from "lucide-react";

interface FooterProps {
  onScrollToTop: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onScrollToTop }) => {
  return (
    <footer className="relative border-t border-white/[0.08] bg-[#040508]/90 py-12 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-white/[0.06]">
          {/* Brand & Role */}
          <div className="text-center md:text-right space-y-1">
            <div className="text-xl font-bold tracking-tight text-white flex items-center justify-center md:justify-start gap-2">
              <span className="font-mono text-cyan-400">HAMO</span>
              <span>DARK</span>
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            </div>
            <p className="text-xs sm:text-sm text-zinc-400 font-mono">
              Full-Stack Developer & App Developer
            </p>
          </div>

          {/* Social Channels */}
          <div className="flex items-center gap-4">
            <a
              href={siteConfig.github}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-zinc-300 hover:text-white transition-all hover:scale-105"
              aria-label="حساب GitHub"
            >
              <Github className="w-4 h-4" />
            </a>

            <a
              href={siteConfig.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-zinc-300 hover:text-emerald-400 transition-all hover:scale-105"
              aria-label="محادثة WhatsApp"
            >
              <MessageCircle className="w-4 h-4" />
            </a>

            <a
              href={`mailto:${siteConfig.email}`}
              className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-zinc-300 hover:text-cyan-400 transition-all hover:scale-105"
              aria-label="البريد الإلكتروني"
            >
              <Mail className="w-4 h-4" />
            </a>

            {/* Back to top button */}
            <button
              type="button"
              onClick={onScrollToTop}
              className="p-2.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/20 text-cyan-300 transition-all hover:scale-105 cursor-pointer"
              aria-label="العودة لأعلى الصفحة"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Copyright notice */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500 font-mono">
          <p>© 2026 HAMO DARK — All Rights Reserved</p>
          <p className="flex items-center gap-2">
            <span>Built with Modern React & Tailwind CSS</span>
            <span>•</span>
            <span className="text-zinc-400">RTL Native Experience</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
