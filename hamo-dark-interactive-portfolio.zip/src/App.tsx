/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Skills } from "./components/Skills";
import { Projects } from "./components/Projects";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { BackgroundScene } from "./components/BackgroundScene";

export default function App() {
  const [activeSection, setActiveSection] = useState<string>("hero");
  const [scrollProgress, setScrollProgress] = useState<number>(0);

  // Smooth scroll to section
  const handleNavigate = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      const topOffset = sectionId === "hero" ? 0 : el.offsetTop - 70;
      window.scrollTo({
        top: topOffset,
        behavior: "smooth",
      });
    }
  };

  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  // Track active section and scroll progress
  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        setScrollProgress((window.scrollY / totalScroll) * 100);
      }

      // Check section visibility
      const sectionIds = ["hero", "about", "skills", "projects", "contact"];
      const scrollPos = window.scrollY + window.innerHeight * 0.35;

      for (let i = sectionIds.length - 1; i >= 0; i--) {
        const id = sectionIds[i];
        const el = document.getElementById(id);
        if (el && el.offsetTop <= scrollPos) {
          setActiveSection(id);
          break;
        }
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="relative min-h-screen bg-[#050609] text-[#E2E8F0] selection:bg-cyan-500/20 selection:text-cyan-200">
      {/* Delicate Scroll Progress Bar */}
      <div className="fixed top-0 left-0 right-0 h-[2px] z-50 pointer-events-none">
        <div
          className="h-full bg-gradient-to-r from-cyan-500 via-sky-400 to-indigo-500 shadow-[0_0_10px_rgba(6,182,212,0.8)] transition-all duration-100 ease-out"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Interactive Unified Background Scene */}
      <BackgroundScene activeSection={activeSection} />

      {/* Fixed Navbar */}
      <Navbar activeSection={activeSection} onNavigate={handleNavigate} />

      {/* Main Content Container with smooth section transitions */}
      <main className="relative z-10">
        {/* Section 1: Hero */}
        <Hero onNavigate={handleNavigate} />

        {/* Section Divider 1 */}
        <div className="relative h-24 sm:h-32 flex items-center justify-center pointer-events-none overflow-hidden">
          <div className="w-full max-w-4xl h-[1px] bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent" />
          <div className="absolute w-48 h-12 bg-cyan-500/5 blur-2xl rounded-full" />
        </div>

        {/* Section 2: About */}
        <About />

        {/* Section Divider 2 */}
        <div className="relative h-24 sm:h-32 flex items-center justify-center pointer-events-none overflow-hidden">
          <div className="w-full max-w-4xl h-[1px] bg-gradient-to-r from-transparent via-indigo-500/20 to-transparent" />
          <div className="absolute w-48 h-12 bg-indigo-500/5 blur-2xl rounded-full" />
        </div>

        {/* Section 3: Skills */}
        <Skills />

        {/* Section Divider 3 */}
        <div className="relative h-24 sm:h-32 flex items-center justify-center pointer-events-none overflow-hidden">
          <div className="w-full max-w-4xl h-[1px] bg-gradient-to-r from-transparent via-sky-500/20 to-transparent" />
          <div className="absolute w-48 h-12 bg-sky-500/5 blur-2xl rounded-full" />
        </div>

        {/* Section 4: Projects */}
        <Projects />

        {/* Section Divider 4 */}
        <div className="relative h-24 sm:h-32 flex items-center justify-center pointer-events-none overflow-hidden">
          <div className="w-full max-w-4xl h-[1px] bg-gradient-to-r from-transparent via-cyan-500/15 to-transparent" />
          <div className="absolute w-64 h-16 bg-cyan-500/5 blur-3xl rounded-full" />
        </div>

        {/* Section 5: Contact */}
        <Contact />
      </main>

      {/* Footer */}
      <Footer onScrollToTop={handleScrollToTop} />
    </div>
  );
}
