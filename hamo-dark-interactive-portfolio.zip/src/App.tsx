/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Skills } from "./components/Skills";
import { Projects } from "./components/Projects";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { BackgroundScene } from "./components/BackgroundScene";

export default function App() {
  const [activeSection, setActiveSection] = useState<string>("hero");
  const progressBarRef = useRef<HTMLDivElement | null>(null);

  // Smooth scroll to section
  const handleNavigate = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      const topOffset = sectionId === "hero" ? 0 : el.offsetTop - 64;
      window.scrollTo({
        top: topOffset,
        behavior: "smooth",
      });
    }
  };

  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  // 1. High-Performance IntersectionObserver for Active Section (Zero re-renders during scroll)
  useEffect(() => {
    const sectionIds = ["hero", "about", "skills", "projects", "contact"];
    const elements = sectionIds
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => el !== null);

    if (elements.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      {
        rootMargin: "-25% 0px -40% 0px",
        threshold: 0.1,
      }
    );

    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  // 2. High-Performance Scroll Progress Bar (Pure DOM Ref via rAF, zero React re-renders)
  useEffect(() => {
    let ticking = false;

    const updateProgressBar = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0 && progressBarRef.current) {
        const progress = Math.min(100, Math.max(0, (window.scrollY / totalScroll) * 100));
        progressBarRef.current.style.transform = `scaleX(${progress / 100})`;
      }
      ticking = false;
    };

    const onScroll = () => {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(updateProgressBar);
      }
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    updateProgressBar();

    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="relative min-h-screen bg-[#050609] text-[#E2E8F0] selection:bg-cyan-500/20 selection:text-cyan-200">
      {/* 120 FPS GPU-Accelerated Scroll Progress Indicator */}
      <div className="fixed top-0 left-0 right-0 h-[2px] z-50 pointer-events-none bg-white/[0.04]">
        <div
          ref={progressBarRef}
          className="h-full origin-left bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 transform-gpu"
          style={{
            transform: "scaleX(0)",
            willChange: "transform",
            boxShadow: "0 0 12px rgba(6, 182, 212, 0.7)",
          }}
        />
      </div>

      {/* Interactive Unified Background Scene */}
      <BackgroundScene activeSection={activeSection} />

      {/* Fixed Header Navbar */}
      <Navbar activeSection={activeSection} onNavigate={handleNavigate} />

      {/* Main Content Flow with Smooth Section Transitions */}
      <main className="relative z-10">
        {/* Section 1: Hero */}
        <Hero onNavigate={handleNavigate} />

        {/* Cinematic Section Divider 1 */}
        <div className="relative h-20 sm:h-28 flex items-center justify-center pointer-events-none overflow-hidden">
          <div className="w-full max-w-4xl h-[1px] bg-gradient-to-r from-transparent via-cyan-500/25 to-transparent" />
          <div className="absolute w-48 h-10 bg-cyan-500/5 blur-2xl rounded-full" />
        </div>

        {/* Section 2: About */}
        <About />

        {/* Cinematic Section Divider 2 */}
        <div className="relative h-20 sm:h-28 flex items-center justify-center pointer-events-none overflow-hidden">
          <div className="w-full max-w-4xl h-[1px] bg-gradient-to-r from-transparent via-indigo-500/25 to-transparent" />
          <div className="absolute w-48 h-10 bg-indigo-500/5 blur-2xl rounded-full" />
        </div>

        {/* Section 3: Skills */}
        <Skills />

        {/* Cinematic Section Divider 3 */}
        <div className="relative h-20 sm:h-28 flex items-center justify-center pointer-events-none overflow-hidden">
          <div className="w-full max-w-4xl h-[1px] bg-gradient-to-r from-transparent via-sky-500/25 to-transparent" />
          <div className="absolute w-48 h-10 bg-sky-500/5 blur-2xl rounded-full" />
        </div>

        {/* Section 4: Projects */}
        <Projects />

        {/* Cinematic Section Divider 4 */}
        <div className="relative h-20 sm:h-28 flex items-center justify-center pointer-events-none overflow-hidden">
          <div className="w-full max-w-4xl h-[1px] bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent" />
          <div className="absolute w-56 h-12 bg-cyan-500/5 blur-3xl rounded-full" />
        </div>

        {/* Section 5: Contact */}
        <Contact />
      </main>

      {/* Footer */}
      <Footer onScrollToTop={handleScrollToTop} />
    </div>
  );
}
