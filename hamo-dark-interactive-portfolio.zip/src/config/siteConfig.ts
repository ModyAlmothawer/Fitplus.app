export interface SiteConfig {
  name: string;
  role: string;
  heroTagline: string;
  shortBio: string;
  email: string;
  whatsapp: string;
  github: string;
  status: string;
  experienceYears: string;
  completedProjectsCount: string;
  satisfactionRate: string;
  navItems: { id: string; label: string }[];
}

export const siteConfig: SiteConfig = {
  name: "HAMO DARK",
  role: "Full-Stack Developer & App Developer",
  heroTagline: "نحو حلول برمجية حديثة، فائقة السرعة وعالية الأداء",
  shortBio: "مطوّر برمجيات شغوف ببناء تطبيقات ومواقع حديثة، سريعة، وعملية مع تجربة مستخدم احترافية.",
  email: "contact@hamodark.dev",
  whatsapp: "https://wa.me/201000000000",
  github: "https://github.com/hamodark",
  status: "متاح للمشاريع الجديدة والتعاقدات البرمجية",
  experienceYears: "+4",
  completedProjectsCount: "+28",
  satisfactionRate: "100%",
  navItems: [
    { id: "hero", label: "الرئيسية" },
    { id: "about", label: "عني" },
    { id: "skills", label: "المهارات" },
    { id: "projects", label: "المشاريع" },
    { id: "contact", label: "تواصل" },
  ],
};
