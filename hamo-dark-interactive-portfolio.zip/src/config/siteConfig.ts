export interface SiteConfig {
  name: string;
  role: string;
  roleSubtitle: string;
  heroTagline: string;
  shortBio: string;
  email: string;
  whatsappNumber: string;
  whatsappUrl: string;
  githubUsername: string;
  githubUrl: string;
  telegramUsername: string;
  telegramUrl: string;
  status: string;
  navItems: { id: string; label: string; enLabel: string }[];
}

export const siteConfig: SiteConfig = {
  name: "HAMO DARK",
  role: "Full-Stack Developer",
  roleSubtitle: "App Developer",
  heroTagline: "ENGINEERED FOR SPEED & SCALABILITY",
  shortBio: "مطوّر برمجيات شغوف ببناء تطبيقات ومواقع حديثة، سريعة، وعملية مع تجربة مستخدم احترافية.",
  email: "algmalm044@gmail.com",
  whatsappNumber: "201107311972",
  whatsappUrl: "https://wa.me/201107311972",
  githubUsername: "ModyAlmothawer",
  githubUrl: "https://github.com/ModyAlmothawer",
  telegramUsername: "@modark16",
  telegramUrl: "https://t.me/modark16",
  status: "AVAILABLE FOR CONTRACTS & PROJECTS",
  navItems: [
    { id: "hero", label: "الرئيسية", enLabel: "INDEX" },
    { id: "about", label: "عني", enLabel: "ABOUT" },
    { id: "skills", label: "المهارات", enLabel: "SKILLS" },
    { id: "projects", label: "المشاريع", enLabel: "PROJECTS" },
    { id: "contact", label: "تواصل", enLabel: "CONTACT" },
  ],
};

