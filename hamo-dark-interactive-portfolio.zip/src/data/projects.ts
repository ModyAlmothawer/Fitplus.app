export interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
  detailedDescription?: string;
  image: string;
  technologies: string[];
  metrics?: { label: string; value: string }[];
  liveUrl: string;
  githubUrl: string;
  featured: boolean;
}

/**
 * ملف بيانات المشاريع القابل للتعديل بالكامل
 * يمكنك تعديل اسم المشروع، الوصف، رابط المعاينة، رابط GitHub والصور هنا بكل سهولة.
 */
export const projectsData: Project[] = [
  {
    id: "nexus-analytics-platform",
    title: "منصة تحليلات الويب وإدارة البيانات (Nexus Analytics)",
    category: "Full-Stack Web App",
    description: "منصة ويب متكاملة لمعالجة وتحليل تدفق البيانات الحية في الوقت الفعلي مع لوحات تحكم تفاعلية وتقارير مفصلة.",
    detailedDescription: "نظام مصمم لمعالجة البيانات الضخمة مع واجهات رسومية فائقة السلاسة، يدعم المصادقة الآمنة، وتصدير التقارير، والاتصال المباشر عبر WebSockets وRESTful APIs بتجربة مستخدم عصرية وسريعة.",
    image: "/src/assets/images/project_web_platform_1790973168592.jpg",
    technologies: ["React", "TypeScript", "Tailwind CSS", "Node.js", "Express", "PostgreSQL"],
    metrics: [
      { label: "زمن الاستجابة", value: "< 45ms" },
      { label: "معدل الرضا", value: "99.8%" },
    ],
    liveUrl: "https://demo.hamodark.dev/nexus",
    githubUrl: "https://github.com/hamodark/nexus-analytics",
    featured: true,
  },
  {
    id: "pulse-cross-platform-app",
    title: "تطبيق النبض الذكي للموبايل (Pulse Mobile App)",
    category: "Mobile Application",
    description: "تطبيق هاتف متعدد المنصات (iOS & Android) لإدارة المهام الحيوية مع مزامنة لحظية ودعم العمل في وضع عدم الاتصال.",
    detailedDescription: "تطبيق موبايل هجين عالي الكفاءة يجمع بين السرعة وسهولة التفاعل، مدعوم بقاعدة بيانات سحابية وتنبيهات فورية Push Notifications مع أداء قريب من الـ Native.",
    image: "/src/assets/images/project_mobile_app_1790973180549.jpg",
    technologies: ["React Native", "TypeScript", "Firebase", "Redux Toolkit", "REST API"],
    metrics: [
      { label: "تقييم المتجر", value: "4.9 / 5" },
      { label: "دعم المنصات", value: "iOS / Android" },
    ],
    liveUrl: "https://demo.hamodark.dev/pulse-app",
    githubUrl: "https://github.com/hamodark/pulse-mobile",
    featured: true,
  },
  {
    id: "hyper-cloud-backend",
    title: "بوابة الخدمات السحابية و Microservices Gateway",
    category: "Cloud & Backend Architecture",
    description: "بنية تحتية برمجية ونظام بوابة واجهات برمجية (API Gateway) مخصص للربط بين الأنظمة الموزعة وإدارة المصادقة.",
    detailedDescription: "محرك خلفي متطور يرتكز على الأداء العالي والأمان المشدد، مع ميزات Rate Limiting، والتخزين المؤقت المتقدم بـ Redis، وتوثيق تفاعلي فوري لجميع نقاط النهاية.",
    image: "/src/assets/images/project_cloud_backend_1790973192428.jpg",
    technologies: ["Node.js", "Python", "Docker", "Firebase Auth", "Redis", "REST APIs"],
    metrics: [
      { label: "القدرة الاستيعابية", value: "10K req/s" },
      { label: "وقت التشغيل", value: "99.99%" },
    ],
    liveUrl: "https://demo.hamodark.dev/hyper-cloud",
    githubUrl: "https://github.com/hamodark/hyper-cloud-gateway",
    featured: true,
  },
];
