import projectWebPlatformImg from "../assets/images/project_web_platform_1790973168592.jpg";
import projectMobileAppImg from "../assets/images/project_mobile_app_1790973180549.jpg";
import projectCloudBackendImg from "../assets/images/project_cloud_backend_1790973192428.jpg";

export interface Project {
  id: string;
  title: string;
  enTitle: string;
  category: string;
  description: string;
  detailedDescription?: string;
  image: string;
  technologies: string[];
  metrics?: { label: string; value: string }[];
  liveUrl: string;
  githubUrl: string;
  featured: boolean;
}

/**
 * ملف بيانات المشاريع القابل للتعديل بالكامل
 * يمكنك تعديل اسم المشروع، الوصف، رابط المعاينة، رابط GitHub والصور هنا بكل سهولة.
 */
export const projectsData: Project[] = [
  {
    id: "nexus-analytics-platform",
    title: "منصة تحليلات الويب وإدارة البيانات المتقدمة",
    enTitle: "NEXUS ANALYTICS PLATFORM",
    category: "Full-Stack Web App",
    description: "منصة ويب متكاملة لمعالجة وتحليل تدفق البيانات الحية في الوقت الفعلي مع لوحات تحكم تفاعلية وتقارير مفصلة.",
    detailedDescription: "نظام مصمم لمعالجة البيانات الضخمة مع واجهات رسومية فائقة السلاسة، يدعم المصادقة الآمنة، وتصدير التقارير، والاتصال المباشر عبر WebSockets وRESTful APIs بتجربة مستخدم عصرية وسريعة.",
    image: projectWebPlatformImg,
    technologies: ["React", "TypeScript", "Tailwind CSS", "Node.js", "Express", "PostgreSQL"],
    metrics: [
      { label: "نوع البنية", value: "Realtime WebSocket" },
      { label: "الأداء", value: "Lighthouse 98+" },
    ],
    liveUrl: "https://github.com/ModyAlmothawer",
    githubUrl: "https://github.com/ModyAlmothawer",
    featured: true,
  },
  {
    id: "pulse-cross-platform-app",
    title: "تطبيق النبض الذكي للأجهزة المحمولة",
    enTitle: "PULSE HYBRID MOBILE APP",
    category: "Mobile Application",
    description: "تطبيق هاتف متعدد المنصات (iOS & Android) لإدارة المهام الحيوية مع مزامنة لحظية ودعم العمل في وضع عدم الاتصال.",
    detailedDescription: "تطبيق موبايل هجين عالي الكفاءة يجمع بين السرعة وسهولة التفاعل، مدعوم بقاعدة بيانات سحابية وتنبيهات فورية Push Notifications مع أداء قريب من الـ Native.",
    image: projectMobileAppImg,
    technologies: ["React Native", "TypeScript", "Firebase", "Redux Toolkit", "REST API"],
    metrics: [
      { label: "دعم المنصات", value: "iOS & Android" },
      { label: "المزامنة", value: "Offline & Realtime" },
    ],
    liveUrl: "https://github.com/ModyAlmothawer",
    githubUrl: "https://github.com/ModyAlmothawer",
    featured: true,
  },
  {
    id: "hyper-cloud-backend",
    title: "بوابة الخدمات السحابية و Microservices Gateway",
    enTitle: "HYPER CLOUD API GATEWAY",
    category: "Cloud & Backend Architecture",
    description: "بنية تحتية برمجية ونظام بوابة واجهات برمجية (API Gateway) مخصص للربط بين الأنظمة الموزعة وإدارة المصادقة.",
    detailedDescription: "محرك خلفي متطور يرتكز على الأداء العالي والأمان المشدد، مع ميزات Rate Limiting، والتخزين المؤقت المتقدم بـ Redis، وتوثيق تفاعلي فوري لجميع نقاط النهاية.",
    image: projectCloudBackendImg,
    technologies: ["Node.js", "Python", "Docker", "Firebase Auth", "Redis", "REST APIs"],
    metrics: [
      { label: "هندسة النظام", value: "Distributed Gateway" },
      { label: "الحماية", value: "Rate Limiting & Auth" },
    ],
    liveUrl: "https://github.com/ModyAlmothawer",
    githubUrl: "https://github.com/ModyAlmothawer",
    featured: true,
  },
];

