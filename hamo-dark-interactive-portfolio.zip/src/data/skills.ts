export interface Skill {
  id: string;
  name: string;
  category: "Frontend" | "Backend" | "Core & Tools" | "Database & Cloud";
  level: string;
  description: string;
  accentColor: string; // Subtle brand accent
  iconName: string;
}

export const skillsData: Skill[] = [
  {
    id: "html",
    name: "HTML5",
    category: "Frontend",
    level: "متقدم",
    description: "هيكلة دلالية، معايير SEO، وإمكانية وصول فائقة الجودة.",
    accentColor: "rgba(227, 76, 38, 0.7)",
    iconName: "Code2",
  },
  {
    id: "css",
    name: "CSS3 / Tailwind",
    category: "Frontend",
    level: "متقدم",
    description: "تصميم متجاوب، أنظمة تصميم، وحركات CSS ثلاثية وميكرو-تفاعلية.",
    accentColor: "rgba(38, 77, 228, 0.7)",
    iconName: "Palette",
  },
  {
    id: "javascript",
    name: "JavaScript (ES6+)",
    category: "Core & Tools",
    level: "خبير",
    description: "برمجة متقدمة غير متزامنة، معالجة DOM، وتطوير أداء المحركات.",
    accentColor: "rgba(247, 223, 30, 0.7)",
    iconName: "FileCode",
  },
  {
    id: "typescript",
    name: "TypeScript",
    category: "Core & Tools",
    level: "متقدم",
    description: "Type Safety، بنيات معقدة وموثوقية في المشاريع الضخمة.",
    accentColor: "rgba(49, 120, 198, 0.7)",
    iconName: "FileCode2",
  },
  {
    id: "react",
    name: "React / Next.js",
    category: "Frontend",
    level: "خبير",
    description: "Single Page Apps، State Management، ومكونات تفاعلية فائقة السلاسة.",
    accentColor: "rgba(97, 218, 251, 0.7)",
    iconName: "Atom",
  },
  {
    id: "nodejs",
    name: "Node.js",
    category: "Backend",
    level: "متقدم",
    description: "بناء REST APIs، خوادم معالجة خلفية سريعة وهندسة Microservices.",
    accentColor: "rgba(104, 160, 99, 0.7)",
    iconName: "Server",
  },
  {
    id: "python",
    name: "Python",
    category: "Backend",
    level: "متقدم",
    description: "أتمتة المهام، معالجة البيانات، وتطوير خوادم سريعة بـ FastAPI.",
    accentColor: "rgba(55, 118, 171, 0.7)",
    iconName: "Terminal",
  },
  {
    id: "java",
    name: "Java",
    category: "Backend",
    level: "متقن",
    description: "برمجة كائنية موجهة (OOP)، أنظمة مستقرة، وتطبيقات أندرويد متينة.",
    accentColor: "rgba(231, 111, 0, 0.7)",
    iconName: "Cpu",
  },
  {
    id: "firebase",
    name: "Firebase",
    category: "Database & Cloud",
    level: "متقدم",
    description: "قواعد بيانات Firestore في الوقت الحقيقي، Auth، وتوزيع سحابي موثوق.",
    accentColor: "rgba(255, 150, 0, 0.7)",
    iconName: "Flame",
  },
  {
    id: "git",
    name: "Git / GitHub",
    category: "Core & Tools",
    level: "خبير",
    description: "إدارة الإصدارات، سير عمل الفرق، CI/CD وأتمتة النشر والتوزيع.",
    accentColor: "rgba(240, 80, 50, 0.7)",
    iconName: "GitBranch",
  },
];
