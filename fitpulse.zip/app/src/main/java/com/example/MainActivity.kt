package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        Scaffold(
          modifier = Modifier.fillMaxSize(),
          containerColor = Color(0xFF07090E)
        ) { innerPadding ->
          FitPulseAppContent(modifier = Modifier.padding(innerPadding))
        }
      }
    }
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun FitPulseAppContent(modifier: Modifier = Modifier) {
  val context = LocalContext.current
  var hasCameraPermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    )
  }

  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestMultiplePermissions()
  ) { permissions ->
    hasCameraPermission = permissions[Manifest.permission.CAMERA] == true
  }

  LaunchedEffect(Unit) {
    if (!hasCameraPermission) {
      permissionLauncher.launch(
        arrayOf(
          Manifest.permission.CAMERA,
          Manifest.permission.RECORD_AUDIO
        )
      )
    }
  }

  var webViewInstance by remember { mutableStateOf<WebView?>(null) }

  BackHandler(enabled = webViewInstance?.canGoBack() == true) {
    webViewInstance?.goBack()
  }

  if (hasCameraPermission) {
    Box(modifier = modifier.fillMaxSize().background(Color(0xFF07090E))) {
      AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
          WebView(ctx).apply {
            settings.apply {
              javaScriptEnabled = true
              domStorageEnabled = true
              mediaPlaybackRequiresUserGesture = false
              allowFileAccess = true
              allowContentAccess = true
              databaseEnabled = true
              cacheMode = WebSettings.LOAD_DEFAULT
              useWideViewPort = true
              loadWithOverviewMode = true
            }

            setBackgroundColor(android.graphics.Color.parseColor("#07090E"))

            webChromeClient = object : WebChromeClient() {
              override fun onPermissionRequest(request: PermissionRequest) {
                // Grant camera & audio permissions automatically inside the WebView
                request.grant(request.resources)
              }
            }

            webViewClient = object : WebViewClient() {
              override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
              }
            }

            loadUrl("file:///android_asset/dist/index.html")
            webViewInstance = this
          }
        },
        update = { webViewInstance = it }
      )
    }
  } else {
    // Permission Request Screen in Arabic
    Box(
      modifier = modifier
        .fillMaxSize()
        .background(Color(0xFF07090E))
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFF101622), RoundedCornerShape(28.dp))
          .padding(32.dp)
      ) {
        Text(
          text = "🔥 FitPulse",
          fontSize = 32.sp,
          fontWeight = FontWeight.Black,
          color = Color.White
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "إذن الكاميرا مطلوب",
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF22C55E)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "يعتمد التطبيق على الكاميرا الأمامية لرصد حركات التمرين وعدّ التكرارات تلقائياً بالذكاء الاصطناعي على جهازك بدون إرسال أي صور.",
          fontSize = 14.sp,
          fontWeight = FontWeight.Medium,
          color = Color(0xFFCBD5E1),
          textAlign = TextAlign.Center,
          lineHeight = 22.sp
        )

        Spacer(modifier = Modifier.height(28.dp))

        Button(
          onClick = {
            permissionLauncher.launch(
              arrayOf(
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
              )
            )
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF22C55E),
            contentColor = Color(0xFF07090E)
          ),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
        ) {
          Text(
            text = "منح إذن الكاميرا",
            fontSize = 16.sp,
            fontWeight = FontWeight.Black
          )
        }
      }
    }
  }
}
