// Central Exercise Configuration & Landmark Metadata
// Implements full biomechanical tracking for FitPulse Coach

export const EXERCISES = {
  squat: {
    id: "squat",
    name: "Squat",
    nameAr: "سكوات (القرفصاء)",
    type: "repetition",
    instructionsAr: "قف مستقيماً وافتح رجليك بعرض كتافك، انزل بوسطك لورا كأنك قاعد على كرسي، واطلع تاني.",
    defaultSets: 3,
    defaultReps: 12,
    thresholds: {
      down: 100,
      up: 160
    },
    activeLandmarks: [23, 24, 25, 26, 27, 28], // hips, knees, ankles
    primaryJoints: ["hip", "knee", "ankle"]
  },

  pushup: {
    id: "pushup",
    name: "Push-up",
    nameAr: "تمرين الضغط",
    type: "repetition",
    instructionsAr: "جسمك مفرود ومشدود زي المسطرة، انزل بصدرك لحد قرب الأرض وادفع لفوق بقوة كوعك.",
    defaultSets: 3,
    defaultReps: 10,
    thresholds: {
      down: 90,
      up: 155
    },
    activeLandmarks: [11, 12, 13, 14, 15, 16, 23, 24],
    primaryJoints: ["shoulder", "elbow", "wrist"]
  },

  curl: {
    id: "curl",
    name: "Bicep Curl",
    nameAr: "بايسبس كيرل (عضلة الذراع)",
    type: "repetition",
    instructionsAr: "كوعك ثابت في جنبك، ارفع إيدك لفوق واعصر البايسبس، وانزل براحة لحد ما تفرده.",
    defaultSets: 3,
    defaultReps: 12,
    thresholds: {
      up: 48,
      down: 150
    },
    activeLandmarks: [11, 12, 13, 14, 15, 16],
    primaryJoints: ["shoulder", "elbow", "wrist"]
  },

  shoulderPress: {
    id: "shoulderPress",
    name: "Shoulder Press",
    nameAr: "ضغط أكتاف (Overhead Press)",
    type: "repetition",
    instructionsAr: "ابدأ بإيدك عند مستوى كتفك، زق لفوق خالص فوق راسك وافرد دراعاتك، وانزل بهدوء.",
    defaultSets: 3,
    defaultReps: 10,
    thresholds: {
      down: 85,
      up: 155
    },
    activeLandmarks: [11, 12, 13, 14, 15, 16, 23, 24],
    primaryJoints: ["elbow", "shoulder", "hip"]
  },

  lunge: {
    id: "lunge",
    name: "Lunge",
    nameAr: "طعنات الساقين (لانجز)",
    type: "repetition",
    instructionsAr: "خد خطوة واسعة لقدام، انزل بركبتك اللي ورا لحد ما تقرب من الأرض، وارجع مكانك.",
    defaultSets: 3,
    defaultReps: 10,
    thresholds: {
      down: 100,
      up: 160
    },
    activeLandmarks: [23, 24, 25, 26, 27, 28],
    primaryJoints: ["hip", "knee", "ankle"]
  },

  jumpingJack: {
    id: "jumpingJack",
    name: "Jumping Jack",
    nameAr: "قفز جاك (كارديو حارق)",
    type: "repetition",
    instructionsAr: "نط وافتح رجليك مع رفع دراعاتك فوق راسك، وبعدين نط وضمهم تاني.",
    defaultSets: 3,
    defaultReps: 25,
    thresholds: {
      open: 1,
      closed: 0
    },
    activeLandmarks: [11, 12, 15, 16, 23, 24, 27, 28],
    primaryJoints: ["wrists", "ankles"]
  },

  gluteBridge: {
    id: "gluteBridge",
    name: "Glute Bridge",
    nameAr: "جلوت بريدج (جسر الأرداف)",
    type: "repetition",
    instructionsAr: "نام على ضهرك واثنِ ركبك وكعبك ثابت، ارفع وسطك لفوق خالص واعصر الأرداف وانزل براحة.",
    defaultSets: 3,
    defaultReps: 12,
    thresholds: {
      down: 125,
      up: 165
    },
    activeLandmarks: [11, 12, 23, 24, 25, 26], // shoulders, hips, knees
    primaryJoints: ["shoulder", "hip", "knee"]
  },

  plank: {
    id: "plank",
    name: "Plank",
    nameAr: "تمرين البلانك (ثبات وحرق دهون)",
    type: "isometric",
    instructionsAr: "اثبت على ساعديك وأطراف صوابعك، بطنك مشدودة وضهرك خط مستقيم واحد.",
    defaultSets: 3,
    defaultReps: 30, // seconds
    thresholds: {
      minAngle: 155
    },
    activeLandmarks: [11, 12, 13, 14, 23, 24, 27, 28],
    primaryJoints: ["shoulder", "hip", "ankle"]
  }
};

export const EXERCISE_LIST = Object.values(EXERCISES);
