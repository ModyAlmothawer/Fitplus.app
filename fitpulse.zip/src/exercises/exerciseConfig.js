// Central Exercise Configuration & Landmark Metadata
// Complies with Sections 24, 25, 26, 27, 28, 29, 30

export const EXERCISES = {
  squat: {
    id: "squat",
    name: "Squat",
    nameAr: "سكوات (القرفصاء)",
    type: "repetition",
    instructionsAr: "قف مستقيماً، انزل بمؤخرتك وركبتيك حتى زاوية 90 درجة، ثم اصعد مجدداً.",
    defaultSets: 3,
    defaultReps: 12,
    thresholds: {
      down: 100,
      up: 160
    },
    activeLandmarks: [23, 24, 25, 26, 27, 28], // hips, knees, ankles
    primaryJoints: ["hip", "knee", "ankle"]
  },

  pushup: {
    id: "pushup",
    name: "Push-up",
    nameAr: "تمرين الضغط",
    type: "repetition",
    instructionsAr: "حافظ على استقامة جسمك، انزل بصدرك قرب الأرض ثم ادفع للأعلى.",
    defaultSets: 3,
    defaultReps: 10,
    thresholds: {
      down: 90,
      up: 155
    },
    activeLandmarks: [11, 12, 13, 14, 15, 16, 23, 24],
    primaryJoints: ["shoulder", "elbow", "wrist"]
  },

  curl: {
    id: "curl",
    name: "Bicep Curl",
    nameAr: "بايسبس كيرل",
    type: "repetition",
    instructionsAr: "اثنِ ذراعك للأعلى نحو الكتف مع ثبات الكوع، ثم انزل ببطء للوضع المفرود.",
    defaultSets: 3,
    defaultReps: 12,
    thresholds: {
      up: 48,
      down: 150
    },
    activeLandmarks: [11, 12, 13, 14, 15, 16],
    primaryJoints: ["shoulder", "elbow", "wrist"]
  },

  shoulderPress: {
    id: "shoulderPress",
    name: "Shoulder Press",
    nameAr: "ضغط الأكتاف للأعلى",
    type: "repetition",
    instructionsAr: "ابدأ بيدين عند مستوى الكتف، ادفع للأعلى بالكامل فوق الرأس ثم انزل بهدوء.",
    defaultSets: 3,
    defaultReps: 10,
    thresholds: {
      down: 85,
      up: 155
    },
    activeLandmarks: [11, 12, 13, 14, 15, 16, 23, 24],
    primaryJoints: ["elbow", "shoulder", "hip"]
  },

  lunge: {
    id: "lunge",
    name: "Lunge",
    nameAr: "طعنات الساقين (لانجز)",
    type: "repetition",
    instructionsAr: "اخترق للأمام بخطوة واسعة، اهبط بالركبة الخلفية قرب الأرض ثم ارجع للبداية.",
    defaultSets: 3,
    defaultReps: 10,
    thresholds: {
      down: 100,
      up: 160
    },
    activeLandmarks: [23, 24, 25, 26, 27, 28],
    primaryJoints: ["hip", "knee", "ankle"]
  },

  jumpingJack: {
    id: "jumpingJack",
    name: "Jumping Jack",
    nameAr: "قفز جاك (Jumping Jacks)",
    type: "repetition",
    instructionsAr: "اقفز مع فتح القدمين ورفع اليدين فوق الرأس، ثم اقفز للعودة لوضع الضم.",
    defaultSets: 3,
    defaultReps: 25,
    thresholds: {
      open: 1,
      closed: 0
    },
    activeLandmarks: [11, 12, 15, 16, 23, 24, 27, 28],
    primaryJoints: ["wrists", "ankles"]
  },

  plank: {
    id: "plank",
    name: "Plank",
    nameAr: "تمرين البلانك (ثبات)",
    type: "isometric", // Timer-based as required in Section 30
    instructionsAr: "اثبت على الساعدين وأصابع القدمين مع استقامة الظهر، لا ترخِ الحوض.",
    defaultSets: 3,
    defaultReps: 30, // seconds
    thresholds: {
      minAngle: 155
    },
    activeLandmarks: [11, 12, 13, 14, 23, 24, 27, 28],
    primaryJoints: ["shoulder", "hip", "ankle"]
  }
};

export const EXERCISE_LIST = Object.values(EXERCISES);
