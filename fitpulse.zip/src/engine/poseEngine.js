// Core AI Pose Engine using MediaPipe Tasks Vision
// Implements robust landmark smoothing, Glute Bridge, rep cooldowns, and hysteresis

import { FilesetResolver, PoseLandmarker } from '@mediapipe/tasks-vision';
import { calculateAngle, calculateDistance } from './angleUtils';
import { AngleSmoother, LandmarkSmoother } from './smoothing';
import { checkBodyVisibility, LANDMARK_INDEX, getBestSide } from './visibility';
import {
  analyzeSquatForm,
  analyzePushupForm,
  analyzePlankForm,
  analyzeGluteBridgeForm
} from './formAnalysis';

export class PoseEngine {
  constructor(options = {}) {
    this.videoElement = null;
    this.poseLandmarker = null;
    this.isModelLoading = false;
    this.isCameraRunning = false;
    this.stream = null;
    this.animFrameId = null;
    this.lastVideoTime = -1;
    this.lastFrameTime = 0;
    this.fpsInterval = 1000 / 30; // Target ~30 FPS

    this.currentExercise = options.exerciseId || 'squat';
    this.angleSmoother = new AngleSmoother(5);
    this.landmarkSmoother = new LandmarkSmoother(33);

    // Rep State Machine & Temporal Stability
    this.repState = 'IDLE'; // 'UP', 'DOWN', 'OPEN', 'CLOSED'
    this.reps = 0;
    this.isometricSeconds = 0;
    this.lastIsometricTime = 0;

    // Minimum duration & cooldown to prevent flutter/double-counting
    this.lastRepTimestamp = 0;
    this.minRepCooldownMs = 800; // 800ms cooldown between reps
    this.stateEntryTimestamp = 0;
    this.minStateDurationMs = 250; // must hold state for at least 250ms

    // Quality & Statistics
    this.validFramesCount = 0;
    this.totalFramesCount = 0;
    this.formViolationsCount = 0;

    // Callbacks
    this.callbacks = {
      onLandmarks: options.onLandmarks || (() => {}),
      onRep: options.onRep || (() => {}),
      onFeedback: options.onFeedback || (() => {}),
      onVisibility: options.onVisibility || (() => {}),
      onError: options.onError || (() => {}),
      onAngleUpdate: options.onAngleUpdate || (() => {})
    };
  }

  setExercise(exerciseId) {
    this.currentExercise = exerciseId;
    this.angleSmoother.reset();
    this.landmarkSmoother.reset();
    this.repState = (exerciseId === 'curl') ? 'DOWN' : 'UP';
    this.isometricSeconds = 0;
    this.lastRepTimestamp = 0;
    this.stateEntryTimestamp = performance.now();
  }

  async initModel() {
    if (this.poseLandmarker) return this.poseLandmarker;
    if (this.isModelLoading) return null;

    this.isModelLoading = true;
    try {
      const wasmPath = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm";
      const modelPath = "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task";

      const vision = await FilesetResolver.forVisionTasks(wasmPath);

      // Attempt GPU delegate first, fallback to CPU
      try {
        this.poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: modelPath,
            delegate: "GPU"
          },
          runningMode: "VIDEO",
          numPoses: 1,
          minPoseDetectionConfidence: 0.5,
          minPosePresenceConfidence: 0.5,
          minTrackingConfidence: 0.5
        });
      } catch (gpuErr) {
        console.warn("GPU delegate failed, falling back to CPU delegate:", gpuErr);
        this.poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: modelPath,
            delegate: "CPU"
          },
          runningMode: "VIDEO",
          numPoses: 1,
          minPoseDetectionConfidence: 0.5,
          minPosePresenceConfidence: 0.5,
          minTrackingConfidence: 0.5
        });
      }

      this.isModelLoading = false;
      return this.poseLandmarker;
    } catch (err) {
      this.isModelLoading = false;
      console.error("Failed to initialize MediaPipe Pose Landmarker:", err);
      this.callbacks.onError({ type: 'model', error: err });
      throw err;
    }
  }

  async startCamera(videoElement, facingMode = 'user') {
    this.videoElement = videoElement;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      const err = new Error("getUserMedia is not supported by your browser");
      this.callbacks.onError({ type: 'unsupported', error: err });
      throw err;
    }

    try {
      if (this.stream) {
        this.stream.getTracks().forEach(track => track.stop());
      }

      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facingMode,
          width: { ideal: 640 },
          height: { ideal: 480 }
        },
        audio: false
      });

      this.videoElement.srcObject = this.stream;
      await new Promise(resolve => {
        this.videoElement.onloadedmetadata = () => {
          this.videoElement.play();
          resolve();
        };
      });

      this.isCameraRunning = true;
      this.startDetectionLoop();
    } catch (err) {
      console.error("Camera access error:", err);
      const isDenied = err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError';
      const isNotFound = err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError';
      this.callbacks.onError({
        type: isDenied ? 'denied' : (isNotFound ? 'not_found' : 'general'),
        error: err
      });
      throw err;
    }
  }

  startDetectionLoop() {
    const processFrame = (now) => {
      if (!this.isCameraRunning) return;

      const elapsed = now - this.lastFrameTime;
      if (elapsed > this.fpsInterval) {
        this.lastFrameTime = now - (elapsed % this.fpsInterval);

        if (this.poseLandmarker && this.videoElement && this.videoElement.readyState >= 2) {
          if (this.videoElement.currentTime !== this.lastVideoTime) {
            this.lastVideoTime = this.videoElement.currentTime;
            try {
              const detectionResult = this.poseLandmarker.detectForVideo(this.videoElement, now);
              this.processPose(detectionResult, now);
            } catch (procErr) {
              console.warn("Pose detection frame error:", procErr);
            }
          }
        }
      }

      this.animFrameId = requestAnimationFrame(processFrame);
    };

    this.animFrameId = requestAnimationFrame(processFrame);
  }

  processPose(result, timestamp) {
    this.totalFramesCount++;
    if (!result || !result.landmarks || result.landmarks.length === 0) {
      this.callbacks.onLandmarks(null);
      this.callbacks.onVisibility({ isReady: false, messageAr: "ابعد الموبايل شوية وخلي جسمك كامل ظاهر" });
      return;
    }

    const rawLandmarks = result.landmarks[0];

    // Smooth all 33 landmarks through low-latency adaptive filter
    const smoothedLandmarks = this.landmarkSmoother.process(rawLandmarks, timestamp);
    this.callbacks.onLandmarks(smoothedLandmarks || rawLandmarks);

    // 1. Visibility Check
    const vis = checkBodyVisibility(smoothedLandmarks || rawLandmarks, this.currentExercise);
    this.callbacks.onVisibility(vis);

    if (!vis.isReady) {
      // Do not count reps when visibility is insufficient
      return;
    }

    this.validFramesCount++;
    const activeLandmarks = smoothedLandmarks || rawLandmarks;

    // 2. Exercise-specific calculation
    switch (this.currentExercise) {
      case 'squat':
        this.processSquat(activeLandmarks, timestamp);
        break;
      case 'pushup':
        this.processPushup(activeLandmarks, timestamp);
        break;
      case 'curl':
        this.processCurl(activeLandmarks, timestamp);
        break;
      case 'shoulderPress':
        this.processShoulderPress(activeLandmarks, timestamp);
        break;
      case 'lunge':
        this.processLunge(activeLandmarks, timestamp);
        break;
      case 'jumpingJack':
        this.processJumpingJack(activeLandmarks, timestamp);
        break;
      case 'gluteBridge':
        this.processGluteBridge(activeLandmarks, timestamp);
        break;
      case 'plank':
        this.processPlank(activeLandmarks, timestamp);
        break;
      default:
        this.processSquat(activeLandmarks, timestamp);
    }
  }

  // --- SQUAT DETECTION ---
  processSquat(landmarks, now) {
    const leftHip = landmarks[LANDMARK_INDEX.LEFT_HIP];
    const leftKnee = landmarks[LANDMARK_INDEX.LEFT_KNEE];
    const leftAnkle = landmarks[LANDMARK_INDEX.LEFT_ANKLE];
    const rightHip = landmarks[LANDMARK_INDEX.RIGHT_HIP];
    const rightKnee = landmarks[LANDMARK_INDEX.RIGHT_KNEE];
    const rightAnkle = landmarks[LANDMARK_INDEX.RIGHT_ANKLE];

    const leftAngle = calculateAngle(leftHip, leftKnee, leftAnkle);
    const rightAngle = calculateAngle(rightHip, rightKnee, rightAnkle);

    const side = getBestSide(
      landmarks,
      [LANDMARK_INDEX.LEFT_HIP, LANDMARK_INDEX.LEFT_KNEE, LANDMARK_INDEX.LEFT_ANKLE],
      [LANDMARK_INDEX.RIGHT_HIP, LANDMARK_INDEX.RIGHT_KNEE, LANDMARK_INDEX.RIGHT_ANKLE]
    );

    let rawAngle = (side === 'left') ? leftAngle : (side === 'right' ? rightAngle : (leftAngle + rightAngle) / 2);
    const smoothedAngle = this.angleSmoother.add(rawAngle);
    this.callbacks.onAngleUpdate(smoothedAngle);

    // Form feedback
    const feedback = analyzeSquatForm(landmarks, smoothedAngle, this.repState);
    if (feedback) {
      if (feedback.status === 'warning') this.formViolationsCount++;
      this.callbacks.onFeedback(feedback);
    }

    // State Machine with cooldown & duration
    if (this.repState === 'IDLE' || this.repState === 'UP') {
      if (smoothedAngle < 100) {
        this.repState = 'DOWN';
        this.stateEntryTimestamp = now;
      }
    } else if (this.repState === 'DOWN') {
      if (smoothedAngle > 158) {
        const timeInDown = now - this.stateEntryTimestamp;
        const timeSinceLastRep = now - this.lastRepTimestamp;

        if (timeInDown >= this.minStateDurationMs && timeSinceLastRep >= this.minRepCooldownMs) {
          this.repState = 'UP';
          this.reps++;
          this.lastRepTimestamp = now;
          this.callbacks.onRep(this.reps, 'squat', feedback?.status === 'warning' ? 'warning' : 'good');
        } else if (smoothedAngle > 165) {
          this.repState = 'UP';
        }
      }
    }
  }

  // --- PUSH-UP DETECTION ---
  processPushup(landmarks, now) {
    const leftShoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
    const leftElbow = landmarks[LANDMARK_INDEX.LEFT_ELBOW];
    const leftWrist = landmarks[LANDMARK_INDEX.LEFT_WRIST];
    const rightShoulder = landmarks[LANDMARK_INDEX.RIGHT_SHOULDER];
    const rightElbow = landmarks[LANDMARK_INDEX.RIGHT_ELBOW];
    const rightWrist = landmarks[LANDMARK_INDEX.RIGHT_WRIST];

    const leftAngle = calculateAngle(leftShoulder, leftElbow, leftWrist);
    const rightAngle = calculateAngle(rightShoulder, rightElbow, rightWrist);
    const side = getBestSide(landmarks, [11, 13, 15], [12, 14, 16]);
    let rawAngle = side === 'left' ? leftAngle : (side === 'right' ? rightAngle : (leftAngle + rightAngle) / 2);

    const smoothedAngle = this.angleSmoother.add(rawAngle);
    this.callbacks.onAngleUpdate(smoothedAngle);

    const feedback = analyzePushupForm(landmarks, smoothedAngle, this.repState);
    if (feedback) {
      if (feedback.status === 'warning') this.formViolationsCount++;
      this.callbacks.onFeedback(feedback);
    }

    if (this.repState === 'IDLE' || this.repState === 'UP') {
      if (smoothedAngle < 90) {
        this.repState = 'DOWN';
        this.stateEntryTimestamp = now;
      }
    } else if (this.repState === 'DOWN') {
      if (smoothedAngle > 152) {
        const timeInDown = now - this.stateEntryTimestamp;
        const timeSinceLastRep = now - this.lastRepTimestamp;

        if (timeInDown >= this.minStateDurationMs && timeSinceLastRep >= this.minRepCooldownMs) {
          this.repState = 'UP';
          this.reps++;
          this.lastRepTimestamp = now;
          this.callbacks.onRep(this.reps, 'pushup', feedback?.status === 'warning' ? 'warning' : 'good');
        } else if (smoothedAngle > 160) {
          this.repState = 'UP';
        }
      }
    }
  }

  // --- BICEP CURL DETECTION ---
  processCurl(landmarks, now) {
    const leftShoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
    const leftElbow = landmarks[LANDMARK_INDEX.LEFT_ELBOW];
    const leftWrist = landmarks[LANDMARK_INDEX.LEFT_WRIST];
    const rightShoulder = landmarks[LANDMARK_INDEX.RIGHT_SHOULDER];
    const rightElbow = landmarks[LANDMARK_INDEX.RIGHT_ELBOW];
    const rightWrist = landmarks[LANDMARK_INDEX.RIGHT_WRIST];

    const leftAngle = calculateAngle(leftShoulder, leftElbow, leftWrist);
    const rightAngle = calculateAngle(rightShoulder, rightElbow, rightWrist);
    const side = getBestSide(landmarks, [11, 13, 15], [12, 14, 16]);
    let rawAngle = side === 'left' ? leftAngle : (side === 'right' ? rightAngle : (leftAngle + rightAngle) / 2);

    const smoothedAngle = this.angleSmoother.add(rawAngle);
    this.callbacks.onAngleUpdate(smoothedAngle);

    // Starts DOWN (> 150°) -> curls UP (< 48°) -> returns DOWN (> 150°) => +1 REP
    if (this.repState === 'IDLE' || this.repState === 'DOWN') {
      if (smoothedAngle < 48) {
        this.repState = 'UP';
        this.stateEntryTimestamp = now;
      }
    } else if (this.repState === 'UP') {
      if (smoothedAngle > 150) {
        const timeInUp = now - this.stateEntryTimestamp;
        const timeSinceLastRep = now - this.lastRepTimestamp;

        if (timeInUp >= this.minStateDurationMs && timeSinceLastRep >= this.minRepCooldownMs) {
          this.repState = 'DOWN';
          this.reps++;
          this.lastRepTimestamp = now;
          this.callbacks.onRep(this.reps, 'curl', 'good');
        } else if (smoothedAngle > 155) {
          this.repState = 'DOWN';
        }
      }
    }
  }

  // --- SHOULDER PRESS DETECTION ---
  processShoulderPress(landmarks, now) {
    const leftShoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
    const leftElbow = landmarks[LANDMARK_INDEX.LEFT_ELBOW];
    const leftWrist = landmarks[LANDMARK_INDEX.LEFT_WRIST];
    const rightShoulder = landmarks[LANDMARK_INDEX.RIGHT_SHOULDER];
    const rightElbow = landmarks[LANDMARK_INDEX.RIGHT_ELBOW];
    const rightWrist = landmarks[LANDMARK_INDEX.RIGHT_WRIST];

    const leftAngle = calculateAngle(leftShoulder, leftElbow, leftWrist);
    const rightAngle = calculateAngle(rightShoulder, rightElbow, rightWrist);
    const side = getBestSide(landmarks, [11, 13, 15], [12, 14, 16]);
    let rawAngle = side === 'left' ? leftAngle : (side === 'right' ? rightAngle : (leftAngle + rightAngle) / 2);

    const smoothedAngle = this.angleSmoother.add(rawAngle);
    this.callbacks.onAngleUpdate(smoothedAngle);

    const wristAboveShoulder = (leftWrist && leftShoulder && leftWrist.y < leftShoulder.y) ||
                               (rightWrist && rightShoulder && rightWrist.y < rightShoulder.y);

    if (this.repState === 'IDLE' || this.repState === 'DOWN') {
      if (smoothedAngle > 155 && wristAboveShoulder) {
        const timeSinceLastRep = now - this.lastRepTimestamp;
        if (timeSinceLastRep >= this.minRepCooldownMs) {
          this.repState = 'UP';
          this.reps++;
          this.lastRepTimestamp = now;
          this.callbacks.onRep(this.reps, 'shoulderPress', 'good');
        }
      }
    } else if (this.repState === 'UP') {
      if (smoothedAngle < 90) {
        this.repState = 'DOWN';
      }
    }
  }

  // --- LUNGE DETECTION ---
  processLunge(landmarks, now) {
    const leftHip = landmarks[LANDMARK_INDEX.LEFT_HIP];
    const leftKnee = landmarks[LANDMARK_INDEX.LEFT_KNEE];
    const leftAnkle = landmarks[LANDMARK_INDEX.LEFT_ANKLE];
    const rightHip = landmarks[LANDMARK_INDEX.RIGHT_HIP];
    const rightKnee = landmarks[LANDMARK_INDEX.RIGHT_KNEE];
    const rightAnkle = landmarks[LANDMARK_INDEX.RIGHT_ANKLE];

    const leftAngle = calculateAngle(leftHip, leftKnee, leftAnkle);
    const rightAngle = calculateAngle(rightHip, rightKnee, rightAnkle);

    const minAngle = Math.min(leftAngle, rightAngle);
    const smoothedAngle = this.angleSmoother.add(minAngle);
    this.callbacks.onAngleUpdate(smoothedAngle);

    if (this.repState === 'IDLE' || this.repState === 'UP') {
      if (smoothedAngle < 100) {
        this.repState = 'DOWN';
        this.stateEntryTimestamp = now;
      }
    } else if (this.repState === 'DOWN') {
      if (smoothedAngle > 158) {
        const timeInDown = now - this.stateEntryTimestamp;
        const timeSinceLastRep = now - this.lastRepTimestamp;

        if (timeInDown >= this.minStateDurationMs && timeSinceLastRep >= this.minRepCooldownMs) {
          this.repState = 'UP';
          this.reps++;
          this.lastRepTimestamp = now;
          this.callbacks.onRep(this.reps, 'lunge', 'good');
        } else if (smoothedAngle > 165) {
          this.repState = 'UP';
        }
      }
    }
  }

  // --- GLUTE BRIDGE DETECTION ---
  processGluteBridge(landmarks, now) {
    const leftShoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
    const leftHip = landmarks[LANDMARK_INDEX.LEFT_HIP];
    const leftKnee = landmarks[LANDMARK_INDEX.LEFT_KNEE];
    const rightShoulder = landmarks[LANDMARK_INDEX.RIGHT_SHOULDER];
    const rightHip = landmarks[LANDMARK_INDEX.RIGHT_HIP];
    const rightKnee = landmarks[LANDMARK_INDEX.RIGHT_KNEE];

    const leftAngle = calculateAngle(leftShoulder, leftHip, leftKnee);
    const rightAngle = calculateAngle(rightShoulder, rightHip, rightKnee);
    const rawAngle = (leftAngle + rightAngle) / 2;

    const smoothedAngle = this.angleSmoother.add(rawAngle);
    this.callbacks.onAngleUpdate(smoothedAngle);

    const feedback = analyzeGluteBridgeForm(landmarks, smoothedAngle, this.repState);
    if (feedback) {
      if (feedback.status === 'warning') this.formViolationsCount++;
      this.callbacks.onFeedback(feedback);
    }

    // Down: < 130°, Up: > 165°
    if (this.repState === 'IDLE' || this.repState === 'DOWN') {
      if (smoothedAngle > 162) {
        this.repState = 'UP';
        this.stateEntryTimestamp = now;
      }
    } else if (this.repState === 'UP') {
      if (smoothedAngle < 135) {
        const timeInUp = now - this.stateEntryTimestamp;
        const timeSinceLastRep = now - this.lastRepTimestamp;

        if (timeInUp >= this.minStateDurationMs && timeSinceLastRep >= this.minRepCooldownMs) {
          this.repState = 'DOWN';
          this.reps++;
          this.lastRepTimestamp = now;
          this.callbacks.onRep(this.reps, 'gluteBridge', 'good');
        } else if (smoothedAngle < 125) {
          this.repState = 'DOWN';
        }
      }
    }
  }

  // --- JUMPING JACK DETECTION ---
  processJumpingJack(landmarks, now) {
    const leftWrist = landmarks[LANDMARK_INDEX.LEFT_WRIST];
    const rightWrist = landmarks[LANDMARK_INDEX.RIGHT_WRIST];
    const leftShoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
    const rightShoulder = landmarks[LANDMARK_INDEX.RIGHT_SHOULDER];
    const leftAnkle = landmarks[LANDMARK_INDEX.LEFT_ANKLE];
    const rightAnkle = landmarks[LANDMARK_INDEX.RIGHT_ANKLE];
    const nose = landmarks[LANDMARK_INDEX.NOSE];

    if (!leftWrist || !rightWrist || !leftShoulder || !rightShoulder || !leftAnkle || !rightAnkle) return;

    const shoulderDist = calculateDistance(leftShoulder, rightShoulder);
    const ankleDist = calculateDistance(leftAnkle, rightAnkle);

    const handsAboveHead = (nose && leftWrist.y < nose.y && rightWrist.y < nose.y);
    const feetApart = ankleDist > shoulderDist * 1.5;

    const isOpen = handsAboveHead && feetApart;
    const isClosed = (leftWrist.y > leftShoulder.y && rightWrist.y > rightShoulder.y) && (ankleDist < shoulderDist * 1.2);

    if (this.repState === 'IDLE' || this.repState === 'CLOSED') {
      if (isOpen) {
        this.repState = 'OPEN';
        this.stateEntryTimestamp = now;
      }
    } else if (this.repState === 'OPEN') {
      if (isClosed) {
        const timeSinceLastRep = now - this.lastRepTimestamp;
        if (timeSinceLastRep >= 550) { // Jacks can be faster but avoid flutter
          this.repState = 'CLOSED';
          this.reps++;
          this.lastRepTimestamp = now;
          this.callbacks.onRep(this.reps, 'jumpingJack', 'good');
        }
      }
    }
  }

  // --- PLANK TIMER DETECTION ---
  processPlank(landmarks) {
    const analysis = analyzePlankForm(landmarks);
    this.callbacks.onFeedback({
      status: analysis.isFormValid ? 'good' : 'warning',
      messageAr: analysis.feedback
    });

    if (analysis.isFormValid) {
      const now = performance.now();
      if (!this.lastIsometricTime) {
        this.lastIsometricTime = now;
      }
      const delta = (now - this.lastIsometricTime) / 1000;
      if (delta >= 1.0) {
        this.isometricSeconds += Math.floor(delta);
        this.lastIsometricTime = now;
        this.callbacks.onRep(this.isometricSeconds, 'plank', 'good');
      }
    } else {
      this.lastIsometricTime = performance.now();
      this.formViolationsCount++;
    }
  }

  getFormScore() {
    if (this.validFramesCount === 0) return 85;
    const errorRatio = this.formViolationsCount / Math.max(1, this.validFramesCount);
    const score = Math.max(50, Math.min(100, Math.round((1 - errorRatio * 0.8) * 100)));
    return score;
  }

  stop() {
    this.isCameraRunning = false;
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    if (this.videoElement) {
      this.videoElement.srcObject = null;
    }
    this.landmarkSmoother.reset();
    this.angleSmoother.reset();
  }
}
