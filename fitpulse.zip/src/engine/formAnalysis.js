// Form Analysis and Real-Time Biomechanical Feedback

import { calculateAngle, calculateTorsoAngle } from './angleUtils';
import { LANDMARK_INDEX } from './visibility';

/**
 * Check squat form and provide actionable Arabic feedback
 */
export function analyzeSquatForm(landmarks, currentKneeAngle, currentState) {
  if (!landmarks || landmarks.length < 29) return null;

  const leftHip = landmarks[LANDMARK_INDEX.LEFT_HIP];
  const rightHip = landmarks[LANDMARK_INDEX.RIGHT_HIP];
  const leftKnee = landmarks[LANDMARK_INDEX.LEFT_KNEE];
  const rightKnee = landmarks[LANDMARK_INDEX.RIGHT_KNEE];
  const leftAnkle = landmarks[LANDMARK_INDEX.LEFT_ANKLE];
  const rightAnkle = landmarks[LANDMARK_INDEX.RIGHT_ANKLE];
  const leftShoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
  const rightShoulder = landmarks[LANDMARK_INDEX.RIGHT_SHOULDER];

  // 1. Torso Lean Check
  if (leftShoulder && leftHip && rightShoulder && rightHip) {
    const avgShoulder = { x: (leftShoulder.x + rightShoulder.x) / 2, y: (leftShoulder.y + rightShoulder.y) / 2 };
    const avgHip = { x: (leftHip.x + rightHip.x) / 2, y: (leftHip.y + rightHip.y) / 2 };
    const torsoLean = calculateTorsoAngle(avgShoulder, avgHip);
    if (torsoLean > 48) {
      return {
        type: 'posture',
        messageAr: "خلي ضهرك مستقيم",
        status: 'warning'
      };
    }
  }

  // 2. Knee inward collapse check (valgus)
  if (leftHip && rightHip && leftKnee && rightKnee && leftAnkle && rightAnkle) {
    const hipDist = Math.abs(leftHip.x - rightHip.x);
    const kneeDist = Math.abs(leftKnee.x - rightKnee.x);
    // If knees are significantly narrower than hips when descending
    if (currentState === 'DESCENDING' && kneeDist < hipDist * 0.7) {
      return {
        type: 'knees',
        messageAr: "خلي ركبتك في اتجاه رجلك",
        status: 'warning'
      };
    }
  }

  // 3. Depth guidance when in bottom portion
  if (currentState === 'DESCENDING' && currentKneeAngle > 105 && currentKneeAngle < 130) {
    return {
      type: 'depth',
      messageAr: "انزل أكتر",
      status: 'info'
    };
  }

  return {
    type: 'good',
    messageAr: "أداء ممتاز! استمر",
    status: 'good'
  };
}

/**
 * Check push-up form (hip sagging or arching)
 */
export function analyzePushupForm(landmarks) {
  if (!landmarks || landmarks.length < 29) return null;

  const shoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
  const hip = landmarks[LANDMARK_INDEX.LEFT_HIP];
  const ankle = landmarks[LANDMARK_INDEX.LEFT_ANKLE];

  if (shoulder && hip && ankle) {
    const bodyAngle = calculateAngle(shoulder, hip, ankle);
    if (bodyAngle < 145) {
      return {
        type: 'hips',
        messageAr: "خلي جسمك مستقيم",
        status: 'warning'
      };
    }
  }

  return {
    type: 'good',
    messageAr: "استمر، وضعية صحيحة",
    status: 'good'
  };
}

/**
 * Check plank form (isometric straight body line)
 */
export function analyzePlankForm(landmarks) {
  if (!landmarks || landmarks.length < 29) return { isFormValid: false, feedback: "جسمك مش واضح" };

  const shoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
  const hip = landmarks[LANDMARK_INDEX.LEFT_HIP];
  const ankle = landmarks[LANDMARK_INDEX.LEFT_ANKLE];

  if (shoulder && hip && ankle) {
    const bodyAngle = calculateAngle(shoulder, hip, ankle);
    const isFormValid = bodyAngle >= 155;
    return {
      isFormValid,
      feedback: isFormValid ? "ثبات رائع! تنفس بانتظام" : "حافظ على جسمك مستقيم",
      angle: bodyAngle
    };
  }

  return { isFormValid: false, feedback: "قف بحيث يظهر جسمك" };
}
