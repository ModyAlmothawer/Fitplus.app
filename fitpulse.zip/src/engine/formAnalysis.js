// Form Analysis and Real-Time Biomechanical Feedback with FitPulse Coach
// Implements natural Egyptian gym coaching form checks

import { calculateAngle, calculateTorsoAngle } from './angleUtils';
import { LANDMARK_INDEX } from './visibility';

/**
 * Check squat form and provide actionable Egyptian Coach feedback
 */
export function analyzeSquatForm(landmarks, currentKneeAngle, currentState) {
  if (!landmarks || landmarks.length < 29) return null;

  const leftHip = landmarks[LANDMARK_INDEX.LEFT_HIP];
  const rightHip = landmarks[LANDMARK_INDEX.RIGHT_HIP];
  const leftKnee = landmarks[LANDMARK_INDEX.LEFT_KNEE];
  const rightKnee = landmarks[LANDMARK_INDEX.RIGHT_KNEE];
  const leftAnkle = landmarks[LANDMARK_INDEX.LEFT_ANKLE];
  const rightAnkle = landmarks[LANDMARK_INDEX.RIGHT_ANKLE];
  const leftShoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
  const rightShoulder = landmarks[LANDMARK_INDEX.RIGHT_SHOULDER];

  // 1. Torso Lean Check (Back Posture)
  if (leftShoulder && leftHip && rightShoulder && rightHip) {
    const avgShoulder = { x: (leftShoulder.x + rightShoulder.x) / 2, y: (leftShoulder.y + rightShoulder.y) / 2 };
    const avgHip = { x: (leftHip.x + rightHip.x) / 2, y: (leftHip.y + rightHip.y) / 2 };
    const torsoLean = calculateTorsoAngle(avgShoulder, avgHip);
    if (torsoLean > 48) {
      return {
        type: 'posture',
        messageAr: "استنى يا وحش 😂 دي مش هتحسب، ظبط ضهرك الأول",
        shortAr: "افرد ضهرك",
        status: 'warning'
      };
    }
  }

  // 2. Knee inward collapse check (valgus)
  if (leftHip && rightHip && leftKnee && rightKnee && leftAnkle && rightAnkle) {
    const hipDist = Math.abs(leftHip.x - rightHip.x);
    const kneeDist = Math.abs(leftKnee.x - rightKnee.x);
    if (currentState === 'DESCENDING' && kneeDist < hipDist * 0.72) {
      return {
        type: 'knees',
        messageAr: "ركبتك بتضم لجوة! افتح ركبتك في اتجاه صوابع رجلك",
        shortAr: "افتح ركبتك",
        status: 'warning'
      };
    }
  }

  // 3. Depth guidance when in bottom portion
  if (currentState === 'DESCENDING' && currentKneeAngle > 105 && currentKneeAngle < 130) {
    return {
      type: 'depth',
      messageAr: "انزل أكتر متسرقش العدة 😂",
      shortAr: "انزل أكتر",
      status: 'info'
    };
  }

  return {
    type: 'good',
    messageAr: "عاش يا فورمة! النزول عالمي",
    shortAr: "فورم ممتاز",
    status: 'good'
  };
}

/**
 * Check push-up form (hip sagging or arching)
 */
export function analyzePushupForm(landmarks, currentElbowAngle, currentState) {
  if (!landmarks || landmarks.length < 29) return null;

  const shoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
  const hip = landmarks[LANDMARK_INDEX.LEFT_HIP];
  const ankle = landmarks[LANDMARK_INDEX.LEFT_ANKLE];

  if (shoulder && hip && ankle) {
    const bodyAngle = calculateAngle(shoulder, hip, ankle);
    if (bodyAngle < 145) {
      return {
        type: 'hips',
        messageAr: "وسطك واقع لتحت! شد بطنك وخلي جسمك خط مستقيم",
        shortAr: "شد وسطك",
        status: 'warning'
      };
    }
  }

  if (currentState === 'DESCENDING' && currentElbowAngle > 100 && currentElbowAngle < 130) {
    return {
      type: 'depth',
      messageAr: "انزل بصدرك لتحت أكتر متخافش!",
      shortAr: "انزل أكتر",
      status: 'info'
    };
  }

  return {
    type: 'good',
    messageAr: "عاش! جسمك مسطرة واحدة",
    shortAr: "فورم ممتاز",
    status: 'good'
  };
}

/**
 * Check plank form (isometric straight body line)
 */
export function analyzePlankForm(landmarks) {
  if (!landmarks || landmarks.length < 29) return { isFormValid: false, feedback: "جسمك مش واضح بالكاميرا" };

  const shoulder = landmarks[LANDMARK_INDEX.LEFT_SHOULDER];
  const hip = landmarks[LANDMARK_INDEX.LEFT_HIP];
  const ankle = landmarks[LANDMARK_INDEX.LEFT_ANKLE];

  if (shoulder && hip && ankle) {
    const bodyAngle = calculateAngle(shoulder, hip, ankle);
    const isFormValid = bodyAngle >= 155;
    return {
      isFormValid,
      feedback: isFormValid ? "ثبات وحوش 🔥 تنفس بانتظام ومترخيش بطنك" : "ارفع الحوض شوية وخليك خط واحد",
      angle: bodyAngle
    };
  }

  return { isFormValid: false, feedback: "ابعد شوية وخلي جسمك ظاهر" };
}

/**
 * Check Glute Bridge form
 */
export function analyzeGluteBridgeForm(landmarks, currentHipAngle, currentState) {
  if (!landmarks || landmarks.length < 29) return null;

  if (currentState === 'ASCENDING' && currentHipAngle < 150) {
    return {
      type: 'height',
      messageAr: "ارفع وسطك لفوق خالص واعصر الجلوتس كويس!",
      shortAr: "ارفع وسطك أكتر",
      status: 'info'
    };
  }

  return {
    type: 'good',
    messageAr: "أيوة كده! الرفع ممتاز وعضلتك شغالة",
    shortAr: "ممتاز",
    status: 'good'
  };
}
