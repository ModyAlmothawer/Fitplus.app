// Landmark Visibility and Full-Body Positioning Verification

export const LANDMARK_INDEX = {
  NOSE: 0,
  LEFT_SHOULDER: 11,
  RIGHT_SHOULDER: 12,
  LEFT_ELBOW: 13,
  RIGHT_ELBOW: 14,
  LEFT_WRIST: 15,
  RIGHT_WRIST: 16,
  LEFT_HIP: 23,
  RIGHT_HIP: 24,
  LEFT_KNEE: 25,
  RIGHT_KNEE: 26,
  LEFT_ANKLE: 27,
  RIGHT_ANKLE: 28,
};

/**
 * Check if the user is in frame with required visibility (> 0.5)
 */
export function checkBodyVisibility(landmarks, exerciseId = 'squat') {
  if (!landmarks || landmarks.length < 29) {
    return {
      isReady: false,
      messageAr: "جسمك مش ظاهر بالكامل، ارجع للخلف قليلاً",
      quality: 0
    };
  }

  // Required landmarks per exercise
  let requiredIndices = [
    LANDMARK_INDEX.LEFT_SHOULDER,
    LANDMARK_INDEX.RIGHT_SHOULDER,
    LANDMARK_INDEX.LEFT_HIP,
    LANDMARK_INDEX.RIGHT_HIP
  ];

  if (exerciseId === 'squat' || exerciseId === 'lunge') {
    requiredIndices.push(
      LANDMARK_INDEX.LEFT_KNEE,
      LANDMARK_INDEX.RIGHT_KNEE,
      LANDMARK_INDEX.LEFT_ANKLE,
      LANDMARK_INDEX.RIGHT_ANKLE
    );
  } else if (exerciseId === 'pushup' || exerciseId === 'plank') {
    requiredIndices.push(
      LANDMARK_INDEX.LEFT_ELBOW,
      LANDMARK_INDEX.RIGHT_ELBOW,
      LANDMARK_INDEX.LEFT_KNEE,
      LANDMARK_INDEX.RIGHT_KNEE
    );
  } else if (exerciseId === 'curl' || exerciseId === 'shoulderPress') {
    requiredIndices.push(
      LANDMARK_INDEX.LEFT_ELBOW,
      LANDMARK_INDEX.RIGHT_ELBOW,
      LANDMARK_INDEX.LEFT_WRIST,
      LANDMARK_INDEX.RIGHT_WRIST
    );
  } else if (exerciseId === 'jumpingJack') {
    requiredIndices.push(
      LANDMARK_INDEX.LEFT_WRIST,
      LANDMARK_INDEX.RIGHT_WRIST,
      LANDMARK_INDEX.LEFT_ANKLE,
      LANDMARK_INDEX.RIGHT_ANKLE
    );
  }

  let visibleCount = 0;
  for (const idx of requiredIndices) {
    const lm = landmarks[idx];
    if (lm && (lm.visibility === undefined || lm.visibility > 0.5)) {
      visibleCount++;
    }
  }

  const quality = visibleCount / requiredIndices.length;
  const isReady = quality >= 0.75; // Tolerant to partial limb occlusion while ensuring key joints visible

  return {
    isReady,
    messageAr: isReady ? "جاهز" : "قف بحيث يظهر جسمك بالكامل",
    quality: Math.round(quality * 100)
  };
}

export function getBestSide(landmarks, leftTriplet, rightTriplet) {
  if (!landmarks) return 'left';
  
  const getSideVisibility = (indices) => {
    let sum = 0;
    for (const idx of indices) {
      const lm = landmarks[idx];
      sum += (lm && lm.visibility !== undefined) ? lm.visibility : 0.8;
    }
    return sum / indices.length;
  };

  const leftVis = getSideVisibility(leftTriplet);
  const rightVis = getSideVisibility(rightTriplet);

  if (leftVis > 0.6 && rightVis > 0.6) return 'both';
  return leftVis >= rightVis ? 'left' : 'right';
}
