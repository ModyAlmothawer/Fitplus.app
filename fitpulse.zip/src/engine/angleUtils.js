// Mathematical & Geometric angle calculation utilities

/**
 * Calculate the angle (in degrees 0-180) at joint vertex point B
 * formed by rays BA and BC.
 * Uses Math.atan2 as specified in Section 16.
 */
export function calculateAngle(a, b, c) {
  if (!a || !b || !c) return 0;
  
  const radians =
    Math.atan2(c.y - b.y, c.x - b.x) -
    Math.atan2(a.y - b.y, a.x - b.x);

  let angle = Math.abs((radians * 180) / Math.PI);

  if (angle > 180) {
    angle = 360 - angle;
  }

  return angle;
}

/**
 * Euclidean distance between two 2D points
 */
export function calculateDistance(a, b) {
  if (!a || !b) return 0;
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}

/**
 * Angle of vector AB relative to vertical (Y axis), 0 = perfectly upright
 */
export function calculateTorsoAngle(shoulder, hip) {
  if (!shoulder || !hip) return 0;
  const dx = Math.abs(shoulder.x - hip.x);
  const dy = Math.abs(shoulder.y - hip.y);
  if (dy === 0) return 90;
  const rad = Math.atan2(dx, dy);
  return (rad * 180) / Math.PI;
}
