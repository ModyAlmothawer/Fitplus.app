// Low-Latency Biomechanical Landmark Smoother & Angle Smoother
// Implements Adaptive Exponential Filtering with Velocity Adaptation & Ghosting Protection

/**
 * Low-latency adaptive smoother for individual 2D/3D points
 * Based on One-Euro / Velocity-Adaptive filtering principles
 */
class AdaptivePointFilter {
  constructor(minAlpha = 0.22, maxAlpha = 0.88, velocityScale = 15.0) {
    this.minAlpha = minAlpha;
    this.maxAlpha = maxAlpha;
    this.velocityScale = velocityScale;
    this.prevX = null;
    this.prevY = null;
    this.prevZ = null;
    this.lastTime = null;
    this.lostFrames = 0;
    this.opacity = 1.0;
  }

  filter(rawX, rawY, rawZ, visibility, timestamp = performance.now()) {
    const isVisible = visibility !== undefined ? visibility >= 0.45 : true;

    if (!isVisible) {
      this.lostFrames++;
      // Graceful fadeout over 6 frames instead of sudden teleporting
      if (this.lostFrames <= 6 && this.prevX !== null) {
        this.opacity = Math.max(0.1, 1.0 - (this.lostFrames / 6));
        return {
          x: this.prevX,
          y: this.prevY,
          z: this.prevZ || 0,
          visibility: 0.3 * this.opacity,
          opacity: this.opacity,
          isGhosted: true
        };
      }
      this.opacity = 0;
      return null;
    }

    // Landmark is visible
    this.lostFrames = 0;
    this.opacity = 1.0;

    if (this.prevX === null) {
      this.prevX = rawX;
      this.prevY = rawY;
      this.prevZ = rawZ || 0;
      this.lastTime = timestamp;
      return { x: rawX, y: rawY, z: rawZ || 0, visibility: 1.0, opacity: 1.0, isGhosted: false };
    }

    const dt = Math.max(0.001, (timestamp - (this.lastTime || timestamp)) / 1000);
    this.lastTime = timestamp;

    // Calculate motion velocity in normalized space
    const dx = rawX - this.prevX;
    const dy = rawY - this.prevY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const velocity = dist / dt;

    // Dynamic alpha: High smoothing when slow (zero jitter), low smoothing when fast (zero lag)
    const alpha = Math.min(
      this.maxAlpha,
      Math.max(this.minAlpha, this.minAlpha + velocity * this.velocityScale * 0.05)
    );

    const smoothX = this.prevX + alpha * (rawX - this.prevX);
    const smoothY = this.prevY + alpha * (rawY - this.prevY);
    const smoothZ = (this.prevZ || 0) + alpha * ((rawZ || 0) - (this.prevZ || 0));

    this.prevX = smoothX;
    this.prevY = smoothY;
    this.prevZ = smoothZ;

    return {
      x: smoothX,
      y: smoothY,
      z: smoothZ,
      visibility: visibility || 0.9,
      opacity: 1.0,
      isGhosted: false
    };
  }

  reset() {
    this.prevX = null;
    this.prevY = null;
    this.prevZ = null;
    this.lastTime = null;
    this.lostFrames = 0;
    this.opacity = 1.0;
  }
}

/**
 * Filter for all 33 MediaPipe pose landmarks
 */
export class LandmarkSmoother {
  constructor(numLandmarks = 33) {
    this.numLandmarks = numLandmarks;
    this.filters = Array.from({ length: numLandmarks }, () => new AdaptivePointFilter());
  }

  process(rawLandmarks, timestamp = performance.now()) {
    if (!rawLandmarks || rawLandmarks.length === 0) {
      return null;
    }

    const smoothed = [];
    for (let i = 0; i < this.numLandmarks; i++) {
      const raw = rawLandmarks[i];
      if (!raw) {
        smoothed.push(null);
        continue;
      }

      const res = this.filters[i].filter(
        raw.x,
        raw.y,
        raw.z || 0,
        raw.visibility,
        timestamp
      );
      smoothed.push(res);
    }

    return smoothed;
  }

  reset() {
    this.filters.forEach(f => f.reset());
  }
}

/**
 * 5-Frame Moving Average Angle Smoother for Joint Angles
 */
export class AngleSmoother {
  constructor(windowSize = 5) {
    this.windowSize = windowSize;
    this.buffer = [];
  }

  add(angle) {
    if (typeof angle !== 'number' || isNaN(angle) || angle < 0 || angle > 360) {
      return this.getAverage();
    }
    this.buffer.push(angle);
    if (this.buffer.length > this.windowSize) {
      this.buffer.shift();
    }
    return this.getAverage();
  }

  getAverage() {
    if (this.buffer.length === 0) return 0;
    const sum = this.buffer.reduce((acc, val) => acc + val, 0);
    return Math.round((sum / this.buffer.length) * 10) / 10;
  }

  reset() {
    this.buffer = [];
  }

  count() {
    return this.buffer.length;
  }
}
