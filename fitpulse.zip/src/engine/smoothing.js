// 5-Frame Moving Average Angle Smoother for Pose Tracking

export class AngleSmoother {
  constructor(windowSize = 5) {
    this.windowSize = windowSize;
    this.buffer = [];
  }

  add(angle) {
    if (typeof angle !== 'number' || isNaN(angle) || angle < 0 || angle > 360) {
      return this.getAverage();
    }
    this.buffer.push(angle);
    if (this.buffer.length > this.windowSize) {
      this.buffer.shift();
    }
    return this.getAverage();
  }

  getAverage() {
    if (this.buffer.length === 0) return 0;
    const sum = this.buffer.reduce((acc, val) => acc + val, 0);
    return Math.round((sum / this.buffer.length) * 10) / 10;
  }

  reset() {
    this.buffer = [];
  }

  count() {
    return this.buffer.length;
  }
}
