// Dedicated LocalStorage Storage Module for FitPulse
// Single versioned key: fitpulse_data

const STORAGE_KEY = 'fitpulse_data';
const CURRENT_VERSION = 1;

export const DEFAULT_PLAN = {
  saturday: {
    isRest: false,
    completed: false,
    exercises: [
      { id: 'squat', nameAr: 'سكوات', sets: 3, reps: 12 },
      { id: 'pushup', nameAr: 'ضغط', sets: 3, reps: 10 }
    ]
  },
  sunday: {
    isRest: false,
    completed: false,
    exercises: [
      { id: 'curl', nameAr: 'بايسبس كيرل', sets: 3, reps: 12 },
      { id: 'shoulderPress', nameAr: 'ضغط أكتاف', sets: 3, reps: 10 }
    ]
  },
  monday: {
    isRest: true,
    completed: false,
    exercises: []
  },
  tuesday: {
    isRest: false,
    completed: false,
    exercises: [
      { id: 'lunge', nameAr: 'طعنات (لانجز)', sets: 3, reps: 10 },
      { id: 'squat', nameAr: 'سكوات', sets: 3, reps: 15 }
    ]
  },
  wednesday: {
    isRest: false,
    completed: false,
    exercises: [
      { id: 'pushup', nameAr: 'ضغط', sets: 3, reps: 12 },
      { id: 'plank', nameAr: 'بلانك', sets: 3, reps: 30 }
    ]
  },
  thursday: {
    isRest: false,
    completed: false,
    exercises: [
      { id: 'jumpingJack', nameAr: 'جامبنج جاك', sets: 3, reps: 25 },
      { id: 'plank', nameAr: 'بلانك', sets: 3, reps: 30 }
    ]
  },
  friday: {
    isRest: true,
    completed: false,
    exercises: []
  }
};

export const INITIAL_STATE = {
  version: CURRENT_VERSION,
  profile: {
    xp: 0,
    level: 1,
    streak: 0,
    bestStreak: 0,
    totalWorkouts: 0,
    totalReps: 0,
    lastWorkoutDate: null
  },
  weeklyPlan: DEFAULT_PLAN,
  workouts: [],
  badges: [],
  settings: {
    voice: true,
    notifications: false,
    language: 'ar',
    cameraFacing: 'user'
  }
};

export function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveData(INITIAL_STATE);
      return JSON.parse(JSON.stringify(INITIAL_STATE));
    }
    const parsed = JSON.parse(raw);
    if (!parsed || parsed.version !== CURRENT_VERSION) {
      // Merge migration if schema evolved
      const migrated = {
        ...INITIAL_STATE,
        ...parsed,
        profile: { ...INITIAL_STATE.profile, ...(parsed.profile || {}) },
        weeklyPlan: parsed.weeklyPlan || DEFAULT_PLAN,
        settings: { ...INITIAL_STATE.settings, ...(parsed.settings || {}) },
        version: CURRENT_VERSION
      };
      saveData(migrated);
      return migrated;
    }
    return parsed;
  } catch (err) {
    console.error('Failed to load fitpulse_data from localStorage:', err);
    return JSON.parse(JSON.stringify(INITIAL_STATE));
  }
}

export function saveData(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error('Failed to save fitpulse_data to localStorage:', err);
  }
}

export function resetData() {
  try {
    localStorage.removeItem(STORAGE_KEY);
    saveData(INITIAL_STATE);
    return JSON.parse(JSON.stringify(INITIAL_STATE));
  } catch (err) {
    console.error('Failed to reset storage:', err);
    return JSON.parse(JSON.stringify(INITIAL_STATE));
  }
}
