// XP, Levels, Badges, Streak and Calorie Calculation Service

export const XP_CONFIG = {
  PER_REP: 1,
  PER_SET: 10,
  PER_WORKOUT: 50,
  PER_PLANNED_DAY: 25,
};

export const BADGES_DEFINITION = [
  {
    id: 'first_workout',
    title: 'أول تمرين',
    titleEn: 'First Workout',
    description: 'أكملت أول جلسة تدريب بنجاح',
    icon: '🎯',
    condition: (profile, workouts) => workouts.length >= 1
  },
  {
    id: 'reps_50',
    title: 'أول 50 تكرار',
    titleEn: 'First 50 Reps',
    description: 'حققت 50 تكراراً إجمالياً في تمارينك',
    icon: '⚡',
    condition: (profile) => profile.totalReps >= 50
  },
  {
    id: 'reps_100',
    title: '100 تكرار',
    titleEn: '100 Reps',
    description: 'تجاوزت حاجز 100 تكرار بقوة',
    icon: '💪',
    condition: (profile) => profile.totalReps >= 100
  },
  {
    id: 'reps_500',
    title: '500 تكرار',
    titleEn: '500 Reps',
    description: 'نصف ألف تكرار! لياقة حديدية',
    icon: '🏆',
    condition: (profile) => profile.totalReps >= 500
  },
  {
    id: 'streak_7',
    title: '7 أيام متتالية',
    titleEn: '7-Day Streak',
    description: 'التزمت بالتمارين لمدة أسبوع كامل دون انقطاع',
    icon: '🔥',
    condition: (profile) => profile.streak >= 7 || profile.bestStreak >= 7
  },
  {
    id: 'workouts_10',
    title: '10 تمارين',
    titleEn: '10 Workouts',
    description: 'أكملت 10 جلسات تدريبية متكاملة',
    icon: '⭐',
    condition: (profile, workouts) => workouts.length >= 10
  },
  {
    id: 'full_week',
    title: 'أسبوع كامل',
    titleEn: 'Full Week',
    description: 'أتممت كافة التمارين المجدولة في أسبوعك',
    icon: '📅',
    condition: (profile, workouts, weeklyPlan) => {
      if (!weeklyPlan) return false;
      const days = Object.values(weeklyPlan);
      return days.length > 0 && days.every(d => d.completed || d.isRest);
    }
  }
];

// Progressive Level Calculation
// Level 1: 0 - 200 XP
// Level 2: 200 - 500 XP
// Level 3: 500 - 900 XP
// Level 4: 900 - 1400 XP
export function calculateLevel(totalXp) {
  let level = 1;
  let threshold = 200;
  let step = 200;
  let prevThreshold = 0;

  while (totalXp >= threshold) {
    prevThreshold = threshold;
    level++;
    step += 100;
    threshold += step;
  }

  const currentLevelXp = Math.max(0, totalXp - prevThreshold);
  const neededXp = threshold - prevThreshold;

  return {
    level,
    currentLevelXp,
    neededXp,
    progressPercentage: Math.min(100, Math.round((currentLevelXp / neededXp) * 100))
  };
}

// Calculate Streak based on dates
export function updateStreak(currentStreak, lastWorkoutDateStr) {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  if (!lastWorkoutDateStr) {
    return { streak: 1, isNewDay: true, todayStr };
  }

  const lastDate = new Date(lastWorkoutDateStr);
  const today = new Date(todayStr);

  const diffTime = today.getTime() - lastDate.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays === 0) {
    // Already worked out today
    return { streak: currentStreak, isNewDay: false, todayStr };
  } else if (diffDays === 1) {
    // Consecutive day
    return { streak: currentStreak + 1, isNewDay: true, todayStr };
  } else {
    // Missed day -> reset to 1
    return { streak: 1, isNewDay: true, todayStr };
  }
}

// Estimated Calorie Model
// Standard estimate based on exercise type, intensity, and duration
export function estimateCalories(exerciseId, reps, durationSeconds) {
  const caloriesPerMinute = {
    squat: 7.5,
    pushup: 8.0,
    curl: 5.5,
    shoulderPress: 6.5,
    lunge: 7.0,
    jumpingJack: 9.5,
    plank: 5.0
  };

  const rate = caloriesPerMinute[exerciseId] || 7.0;
  const minutes = Math.max(durationSeconds / 60, (reps * 3) / 60);
  const calculated = Math.round(rate * minutes);
  return Math.max(1, calculated);
}

// Check newly unlocked badges
export function checkNewBadges(profile, workouts, currentBadges = [], weeklyPlan = null) {
  const unlocked = [...currentBadges];
  const newlyUnlocked = [];

  for (const badge of BADGES_DEFINITION) {
    if (!unlocked.includes(badge.id)) {
      if (badge.condition(profile, workouts, weeklyPlan)) {
        unlocked.push(badge.id);
        newlyUnlocked.push(badge);
      }
    }
  }

  return { unlocked, newlyUnlocked };
}
