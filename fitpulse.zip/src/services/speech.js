// Web Speech API Voice Counting Service (Arabic Speech Synthesis)

const ARABIC_NUMBERS = [
  "", "واحد", "اتنين", "تلاتة", "أربعة", "خمسة",
  "ستة", "سبعة", "ثمانية", "تسعة", "عشرة",
  "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر",
  "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر", "عشرون",
  "واحد وعشرون", "اثنان وعشرون", "ثلاثة وعشرون", "أربعة وعشرون", "خمسة وعشرون",
  "ستة وعشرون", "سبعة وعشرون", "ثمانية وعشرون", "تسعة وعشرون", "ثلاثون",
  "واحد وثلاثون", "اثنان وثلاثون", "ثلاثة وثلاثون", "أربعة وثلاثون", "خمسة وثلاثون",
  "ستة وثلاثون", "سبعة وثلاثون", "ثمانية وثلاثون", "تسعة وثلاثون", "أربعون",
  "واحد وأربعون", "اثنان وأربعون", "ثلاثة وأربعون", "أربعة وأربعون", "خمسة وأربعون",
  "ستة وأربعون", "سبعة وأربعون", "ثمانية وأربعون", "تسعة وأربعون", "خمسون"
];

class SpeechService {
  constructor() {
    this.synth = typeof window !== 'undefined' ? window.speechSynthesis : null;
    this.arabicVoice = null;
    this.enabled = true;
    this.initVoice();
  }

  initVoice() {
    if (!this.synth) return;

    const findVoice = () => {
      try {
        const voices = this.synth.getVoices();
        // Look for Arabic voice (ar, ar-SA, ar-EG, etc.)
        this.arabicVoice = voices.find(v => v.lang.startsWith('ar')) || null;
      } catch (e) {
        this.arabicVoice = null;
      }
    };

    findVoice();
    if (this.synth.onvoiceschanged !== undefined) {
      this.synth.onvoiceschanged = findVoice;
    }
  }

  setEnabled(val) {
    this.enabled = !!val;
    if (!this.enabled && this.synth) {
      this.synth.cancel();
    }
  }

  speak(text) {
    if (!this.enabled || !this.synth || !text) return;
    try {
      this.synth.cancel(); // Don't queue up a backlog of outdated words
      const utterance = new SpeechSynthesisUtterance(text);
      if (this.arabicVoice) {
        utterance.voice = this.arabicVoice;
        utterance.lang = this.arabicVoice.lang;
      } else {
        utterance.lang = 'ar-SA';
      }
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      this.synth.speak(utterance);
    } catch (e) {
      // Fail silently as required
    }
  }

  speakRep(count) {
    if (count <= 0) return;
    const word = ARABIC_NUMBERS[count] || `${count}`;
    this.speak(word);
  }

  speakSetComplete() {
    this.speak("برافو! خلصت المجموعة.");
  }

  speakWorkoutComplete() {
    this.speak("عاش يا بطل! خلصت التمرين كله بامتياز.");
  }

  speakRestOver() {
    this.speak("يلا استعد، المجموعة القادمة!");
  }
}

export const speechService = new SpeechService();
