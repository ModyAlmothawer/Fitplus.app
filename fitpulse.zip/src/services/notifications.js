// Browser Notifications Service for Daily Motivation & Streak Reminders

class NotificationService {
  isSupported() {
    return typeof window !== 'undefined' && 'Notification' in window;
  }

  getPermission() {
    if (!this.isSupported()) return 'denied';
    return Notification.permission;
  }

  async requestPermission() {
    if (!this.isSupported()) return false;
    try {
      const result = await Notification.requestPermission();
      return result === 'granted';
    } catch (e) {
      console.warn('Error requesting notification permission:', e);
      return false;
    }
  }

  sendReminder(title, body) {
    if (!this.isSupported() || Notification.permission !== 'granted') return;
    try {
      new Notification(title || "FitPulse | وقت التمرين! 🔥", {
        body: body || "لا تكسر سلسلتك اليومية، 15 دقيقة فقط تصنع الفرق.",
        icon: "/favicon.ico",
        dir: "rtl",
        lang: "ar"
      });
    } catch (e) {
      console.warn('Error sending notification:', e);
    }
  }
}

export const notificationService = new NotificationService();
