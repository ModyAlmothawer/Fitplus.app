// Priority-based Speech Queue & Arabic Text-to-Speech Engine
// Implements Section 9: Interruption, Volume Control, Priority Queue, Anti-overlap

class SpeechQueueManager {
  constructor() {
    this.synth = typeof window !== 'undefined' ? window.speechSynthesis : null;
    this.queue = [];
    this.isSpeaking = false;
    this.enabled = true;
    this.volume = 1.0;
    this.rate = 1.05;
    this.pitch = 1.0;
    this.arabicVoice = null;
    this.currentUtterance = null;
    this.currentPriority = 3;

    this.initVoice();
  }

  initVoice() {
    if (!this.synth) return;

    const findVoice = () => {
      try {
        const voices = this.synth.getVoices();
        // Look for Egyptian Arabic (ar-EG) first, then any Arabic
        this.arabicVoice =
          voices.find(v => v.lang === 'ar-EG') ||
          voices.find(v => v.lang.startsWith('ar')) ||
          null;
      } catch (e) {
        this.arabicVoice = null;
      }
    };

    findVoice();
    if (this.synth.onvoiceschanged !== undefined) {
      this.synth.onvoiceschanged = findVoice;
    }
  }

  setSettings({ enabled, volume, rate }) {
    if (enabled !== undefined) this.enabled = !!enabled;
    if (volume !== undefined) this.volume = Math.max(0, Math.min(1, volume));
    if (rate !== undefined) this.rate = Math.max(0.8, Math.min(1.4, rate));

    if (!this.enabled && this.synth) {
      this.stop();
    }
  }

  stop() {
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch (e) {}
    }
    this.queue = [];
    this.isSpeaking = false;
    this.currentUtterance = null;
    this.currentPriority = 3;
  }

  /**
   * Speak a message with priority
   * @param {string} text - The Arabic message
   * @param {number} priority - 1 (High/Interrupt), 2 (Medium), 3 (Low/Banter)
   * @param {Function} onStart - Callback when speech actually begins
   * @param {Function} onEnd - Callback when speech finishes
   */
  speak(text, priority = 3, onStart = null, onEnd = null) {
    if (!this.enabled || !this.synth || !text) {
      if (onEnd) onEnd();
      return;
    }

    // High priority (e.g. form safety or user query reply) interrupts lower priority speech immediately!
    if (priority <= 1 && this.isSpeaking) {
      try {
        this.synth.cancel();
      } catch (e) {}
      this.queue = [];
      this.isSpeaking = false;
    } else if (this.isSpeaking && priority >= 3) {
      // Don't queue up a backlog of outdated rep banters if coach is already speaking!
      return;
    }

    const item = { text, priority, onStart, onEnd };

    if (priority === 1) {
      this.queue.unshift(item);
    } else {
      this.queue.push(item);
    }

    if (!this.isSpeaking) {
      this.processNext();
    }
  }

  processNext() {
    if (this.queue.length === 0) {
      this.isSpeaking = false;
      this.currentUtterance = null;
      this.currentPriority = 3;
      return;
    }

    const item = this.queue.shift();
    this.isSpeaking = true;
    this.currentPriority = item.priority;

    try {
      const utterance = new SpeechSynthesisUtterance(item.text);
      if (this.arabicVoice) {
        utterance.voice = this.arabicVoice;
        utterance.lang = this.arabicVoice.lang;
      } else {
        utterance.lang = 'ar-EG';
      }

      utterance.volume = this.volume;
      utterance.rate = this.rate;
      utterance.pitch = this.pitch;

      utterance.onstart = () => {
        if (item.onStart) item.onStart(item.text);
      };

      utterance.onend = () => {
        if (item.onEnd) item.onEnd();
        this.processNext();
      };

      utterance.onerror = () => {
        if (item.onEnd) item.onEnd();
        this.processNext();
      };

      this.currentUtterance = utterance;
      this.synth.speak(utterance);
    } catch (err) {
      console.warn("TTS speak error:", err);
      this.isSpeaking = false;
      this.processNext();
    }
  }
}

export const speechQueue = new SpeechQueueManager();
