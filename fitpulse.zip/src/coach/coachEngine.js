// FitPulse Coach Central Engine & Real-Time Event State Controller
// Implements Sections 1, 6, 7, 8, 10, 11, 16

import { COACH_DICTIONARY, coachMemory } from './coachPersonality';
import { speechQueue } from './speechQueue';
import { EXERCISES } from '../exercises/exerciseConfig';

export class CoachEngine {
  constructor(options = {}) {
    this.state = {
      currentExercise: options.exerciseId || 'squat',
      exerciseNameAr: options.exerciseNameAr || 'سكوات',
      nextExerciseNameAr: options.nextExerciseNameAr || 'تمرين الضغط',
      currentSet: 1,
      totalSets: options.totalSets || 3,
      currentRep: 0,
      targetReps: options.targetReps || 12,
      formQuality: 100, // 0 - 100
      formErrors: 0,
      restTime: 0,
      workoutTime: 0,
      xp: options.xp || 0,
      streak: options.streak || 0,
      motivationLevel: options.motivationLevel || 'hype' // 'calm' | 'normal' | 'hype'
    };

    // Cooldown trackers to prevent spamming
    this.lastSpokenTimes = {
      encouragement: 0,
      formWarning: 0,
      repNumber: 0,
      any: 0
    };

    this.onCoachMessage = options.onCoachMessage || (() => {});
    this.currentMessage = "";
  }

  updateState(partial) {
    this.state = { ...this.state, ...partial };
  }

  setMotivationLevel(level) {
    this.state.motivationLevel = level;
  }

  triggerEvent(eventType, payload = {}) {
    const now = performance.now();

    switch (eventType) {
      case 'COUNTDOWN': {
        const text = coachMemory.pick(COACH_DICTIONARY.countdown);
        this.speakCoach(text, 2);
        break;
      }

      case 'WORKOUT_STARTED': {
        const text = coachMemory.pick(COACH_DICTIONARY.workoutStarted);
        this.speakCoach(text, 2);
        break;
      }

      case 'REP_COMPLETED': {
        const rep = payload.rep || this.state.currentRep;
        const target = this.state.targetReps;
        const remaining = target - rep;

        // Count number verbally
        const numberWord = this.getNumberWord(rep);

        // Milestone triggers:
        if (remaining === 0) {
          // Set finished will trigger SET_COMPLETED
          this.speakCoach(numberWord, 3);
        } else if (remaining === 1) {
          const phrase = coachMemory.pick(COACH_DICTIONARY.lastRep);
          this.speakCoach(`${numberWord}.. ${phrase}`, 2);
        } else if (remaining <= 3 && (now - this.lastSpokenTimes.encouragement > 3000)) {
          const phrase = coachMemory.pick(COACH_DICTIONARY.lastFewReps).replace('{remaining}', `${remaining}`);
          this.speakCoach(`${numberWord}.. ${phrase}`, 2);
          this.lastSpokenTimes.encouragement = now;
        } else {
          // Standard rep announcement with motivation flavoring
          if (this.state.motivationLevel === 'hype' && rep % 3 === 0 && (now - this.lastSpokenTimes.encouragement > 4000)) {
            const hypeList = COACH_DICTIONARY.repEncouragement.hype;
            const extra = coachMemory.pick(hypeList);
            this.speakCoach(`${numberWord}.. ${extra}`, 3);
            this.lastSpokenTimes.encouragement = now;
          } else {
            this.speakCoach(numberWord, 3);
          }
        }
        break;
      }

      case 'BAD_FORM': {
        // Enforce cooldown so coach doesn't yell bad form on every micro-frame
        if (now - this.lastSpokenTimes.formWarning < 4500) return;
        this.lastSpokenTimes.formWarning = now;
        this.state.formErrors++;

        // Safety check: If form is critically degrading
        if (this.state.formErrors >= 4) {
          const safetyText = coachMemory.pick(COACH_DICTIONARY.safetyRest);
          this.speakCoach(safetyText, 1); // Priority 1 interrupts!
          return;
        }

        const errType = payload.errorType; // 'depth' | 'knees' | 'posture' | 'hips'
        let phraseList = COACH_DICTIONARY.formCorrection.squatPosture;

        if (errType === 'depth') {
          phraseList = this.state.currentExercise === 'pushup'
            ? COACH_DICTIONARY.formCorrection.pushupDepth
            : COACH_DICTIONARY.formCorrection.squatDepth;
        } else if (errType === 'knees') {
          phraseList = COACH_DICTIONARY.formCorrection.squatKnees;
        } else if (errType === 'hips') {
          phraseList = this.state.currentExercise === 'plank'
            ? COACH_DICTIONARY.formCorrection.plankHips
            : COACH_DICTIONARY.formCorrection.pushupHips;
        }

        const msg = coachMemory.pick(phraseList);
        this.speakCoach(msg, 1);
        break;
      }

      case 'SET_COMPLETED': {
        const text = coachMemory.pick(COACH_DICTIONARY.setCompleted);
        this.speakCoach(text, 2);
        break;
      }

      case 'REST_ENDING': {
        const text = coachMemory.pick(COACH_DICTIONARY.restEnding);
        this.speakCoach(text, 2);
        break;
      }

      case 'WORKOUT_FINISHED': {
        const text = coachMemory.pick(COACH_DICTIONARY.workoutFinished);
        this.speakCoach(text, 1);
        break;
      }

      // User Voice Queries (STT Context Answers)
      case 'USER_SAYS_TIRED': {
        const remaining = Math.max(0, this.state.targetReps - this.state.currentRep);
        // Safety guard: If form errors are high, prioritize health!
        if (this.state.formErrors >= 2) {
          const text = coachMemory.pick(COACH_DICTIONARY.userResponses.tiredSafety);
          this.speakCoach(text, 1);
        } else {
          const text = coachMemory.pick(COACH_DICTIONARY.userResponses.tired).replace('{remaining}', `${remaining}`);
          this.speakCoach(text, 1);
        }
        break;
      }

      case 'USER_ASKS_REPS': {
        const remaining = Math.max(0, this.state.targetReps - this.state.currentRep);
        const text = coachMemory.pick(COACH_DICTIONARY.userResponses.repsRemaining)
          .replace('{remaining}', `${remaining}`)
          .replace('{current}', `${this.state.currentRep}`)
          .replace('{target}', `${this.state.targetReps}`);
        this.speakCoach(text, 1);
        break;
      }

      case 'USER_ASKS_NEXT_EXERCISE': {
        const text = coachMemory.pick(COACH_DICTIONARY.userResponses.nextExercise)
          .replace('{nextExercise}', this.state.nextExerciseNameAr || "تمرين السكوات");
        this.speakCoach(text, 1);
        break;
      }

      case 'USER_ASKS_STATUS': {
        const mins = Math.floor(this.state.workoutTime / 60);
        const text = coachMemory.pick(COACH_DICTIONARY.userResponses.status)
          .replace('{completedSets}', `${this.state.currentSet - 1}`)
          .replace('{reps}', `${this.state.currentRep}`)
          .replace('{minutes}', `${mins}`);
        this.speakCoach(text, 1);
        break;
      }

      case 'USER_ASKS_HARDER': {
        const text = coachMemory.pick(COACH_DICTIONARY.userResponses.makeHarder);
        this.speakCoach(text, 1);
        break;
      }

      case 'USER_SAYS_READY': {
        const text = coachMemory.pick(COACH_DICTIONARY.userResponses.ready);
        this.speakCoach(text, 1);
        break;
      }

      default:
        break;
    }
  }

  speakCoach(text, priority = 3) {
    this.currentMessage = text;
    this.onCoachMessage(text);
    speechQueue.speak(
      text,
      priority,
      () => this.onCoachMessage(text),
      () => {}
    );
  }

  getNumberWord(num) {
    const arabicWords = [
      "", "واحد", "اتنين", "تلاتة", "أربعة", "خمسة",
      "ستة", "سبعة", "تمانية", "تسعة", "عشرة",
      "حداشر", "اتناشر", "تلاتاشر", "أربعتاشر", "خمستاشر",
      "ستاشر", "سبعتاشر", "تمنتاشر", "تسعتاشر", "عشرين",
      "واحد وعشرين", "اتنين وعشرين", "تلاتة وعشرين", "أربعة وعشرين", "خمسة وعشرين"
    ];
    return arabicWords[num] || `${num}`;
  }

  destroy() {
    speechQueue.stop();
  }
}
