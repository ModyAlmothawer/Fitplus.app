// Speech-to-Text (STT) Voice Recognition for FitPulse Coach
// Implements Section 8: Egyptian Arabic Voice Command Recognition

export class VoiceRecognitionService {
  constructor(onIntentDetected = () => {}, onTranscript = () => {}) {
    this.recognition = null;
    this.isListening = false;
    this.enabled = true;
    this.onIntentDetected = onIntentDetected;
    this.onTranscript = onTranscript;
    this.restartTimeout = null;

    this.initRecognition();
  }

  isSupported() {
    return (
      typeof window !== 'undefined' &&
      ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)
    );
  }

  initRecognition() {
    if (!this.isSupported()) return;

    try {
      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = false;
      this.recognition.lang = 'ar-EG'; // Egyptian Arabic dialect
      this.recognition.maxAlternatives = 1;

      this.recognition.onresult = (event) => {
        const lastResultIndex = event.results.length - 1;
        const text = event.results[lastResultIndex][0]?.transcript?.trim();
        if (text) {
          this.onTranscript(text);
          this.analyzeIntent(text);
        }
      };

      this.recognition.onerror = (event) => {
        // Silent error recovery
        if (event.error !== 'no-speech') {
          console.warn("Speech recognition notice:", event.error);
        }
      };

      this.recognition.onend = () => {
        this.isListening = false;
        // Automatically restart if still intended to be listening during active workout
        if (this.enabled) {
          clearTimeout(this.restartTimeout);
          this.restartTimeout = setTimeout(() => {
            if (this.enabled) {
              this.start();
            }
          }, 300);
        }
      };
    } catch (e) {
      console.warn("Speech recognition init error:", e);
    }
  }

  start() {
    if (!this.recognition || this.isListening) return;
    try {
      this.enabled = true;
      this.recognition.start();
      this.isListening = true;
    } catch (e) {
      this.isListening = false;
    }
  }

  stop() {
    this.enabled = false;
    clearTimeout(this.restartTimeout);
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (e) {}
    }
    this.isListening = false;
  }

  /**
   * Natural Language Intent parsing for Egyptian workout dialogue
   */
  analyzeIntent(text) {
    const clean = text.toLowerCase();

    // 1. User says tired / can't continue
    if (
      clean.includes("تعبت") ||
      clean.includes("مش قادر") ||
      clean.includes("هموت") ||
      clean.includes("كفاية") ||
      clean.includes("هلكت") ||
      clean.includes("نفسي اتقطع")
    ) {
      this.onIntentDetected('USER_SAYS_TIRED', text);
      return;
    }

    // 2. User asks how many reps left
    if (
      clean.includes("كام فاضل") ||
      clean.includes("فاضل كام") ||
      clean.includes("كام واحدة") ||
      clean.includes("فاضلي") ||
      clean.includes("كام عدة") ||
      clean.includes("باقي كام")
    ) {
      this.onIntentDetected('USER_ASKS_REPS', text);
      return;
    }

    // 3. User asks what's next
    if (
      clean.includes("التمرين اللي بعده") ||
      clean.includes("التمرين الجاي") ||
      clean.includes("ايه اللي بعده") ||
      clean.includes("ايه الجاي") ||
      clean.includes("هنعمل ايه بعد")
    ) {
      this.onIntentDetected('USER_ASKS_NEXT_EXERCISE', text);
      return;
    }

    // 4. User asks for current status / reps completed
    if (
      clean.includes("عملت كام") ||
      clean.includes("عديت كام") ||
      clean.includes("وصلت لكام") ||
      clean.includes("الحالة")
    ) {
      this.onIntentDetected('USER_ASKS_STATUS', text);
      return;
    }

    // 5. User wants it harder
    if (
      clean.includes("اصعب") ||
      clean.includes("أصعب") ||
      clean.includes("سهل") ||
      clean.includes("مش حاسس")
    ) {
      this.onIntentDetected('USER_ASKS_HARDER', text);
      return;
    }

    // 6. User is ready
    if (
      clean.includes("جاهز") ||
      clean.includes("مستعد") ||
      clean.includes("يلا") ||
      clean.includes("ابدأ")
    ) {
      this.onIntentDetected('USER_SAYS_READY', text);
      return;
    }

    // Default general interaction fallback
    this.onIntentDetected('USER_GENERAL_TALK', text);
  }
}
