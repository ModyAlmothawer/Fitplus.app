// FitPulse Coach Floating Interactive HUD Component
// Displays Coach speech bubble, microphone voice detection, and quick question chips

import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2, Sparkles, MessageSquare } from 'lucide-react';

export default function CoachOverlay({
  coachMessage,
  isListening,
  onToggleMic,
  onTriggerUserIntent,
  isSpeaking = false
}) {
  const [displayedText, setDisplayedText] = useState("");
  const [isBubbleVisible, setIsBubbleVisible] = useState(false);

  useEffect(() => {
    if (coachMessage) {
      setDisplayedText(coachMessage);
      setIsBubbleVisible(true);
      // Auto-dim bubble after 7 seconds if no new message
      const timer = setTimeout(() => {
        setIsBubbleVisible(false);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [coachMessage]);

  const quickQuestions = [
    { label: "أنا تعبت 🥵", intent: "USER_SAYS_TIRED" },
    { label: "فاضل كام؟ 🔢", intent: "USER_ASKS_REPS" },
    { label: "إيه اللي بعده؟ ⏩", intent: "USER_ASKS_NEXT_EXERCISE" },
    { label: "أنا جاهز 💪", intent: "USER_SAYS_READY" }
  ];

  return (
    <div className="w-full flex flex-col items-center px-4 pointer-events-auto">
      {/* 1. Animated Coach Speech Bubble */}
      {isBubbleVisible && displayedText && (
        <div className="relative mb-2 max-w-sm w-full bg-dark-900/95 border border-emerald-500/50 rounded-2xl p-3 shadow-glow-green backdrop-blur-md animate-fade-in">
          <div className="flex items-start gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-neon-green text-dark-950 flex items-center justify-center shrink-0 font-black shadow-md mt-0.5">
              🏋️
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-0.5">
                <span className="text-[11px] font-extrabold text-neon-green">الكوتش</span>
                {isSpeaking && (
                  <span className="flex gap-1 items-center">
                    <span className="w-1.5 h-1.5 rounded-full bg-neon-green animate-ping" />
                    <span className="text-[9px] text-slate-400">بيتكلم...</span>
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm font-bold text-white leading-relaxed select-none">
                "{displayedText}"
              </p>
            </div>
          </div>
          {/* Bubble tail */}
          <div className="absolute -bottom-1.5 right-6 w-3 h-3 bg-dark-900 border-r border-b border-emerald-500/50 rotate-45" />
        </div>
      )}

      {/* 2. Microphone & Quick Interaction Bar */}
      <div className="flex items-center gap-2 overflow-x-auto max-w-full pb-1 no-scrollbar">
        {/* Mic Toggle Button */}
        <button
          onClick={onToggleMic}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full backdrop-blur-md text-[11px] font-bold border transition-all ${
            isListening
              ? 'bg-emerald-500/20 border-emerald-500/60 text-neon-green shadow-glow-green'
              : 'bg-dark-900/80 border-slate-700/60 text-slate-400'
          }`}
          title={isListening ? "إيقاف الاستماع الصوتي" : "تفعيل الاستماع الصوتي"}
        >
          {isListening ? (
            <>
              <span className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
              <Mic size={14} className="text-neon-green" />
              <span>الكوتش سامعك</span>
            </>
          ) : (
            <>
              <MicOff size={14} />
              <span>تحدث مع الكوتش</span>
            </>
          )}
        </button>

        {/* Quick Question Chips (voice or touch) */}
        {quickQuestions.map((q, idx) => (
          <button
            key={idx}
            onClick={() => onTriggerUserIntent(q.intent)}
            className="whitespace-nowrap px-2.5 py-1 rounded-full bg-dark-900/80 hover:bg-dark-800 border border-slate-700/60 text-[10px] font-bold text-slate-300 hover:text-white active:scale-95 transition-all shadow"
          >
            {q.label}
          </button>
        ))}
      </div>
    </div>
  );
}
