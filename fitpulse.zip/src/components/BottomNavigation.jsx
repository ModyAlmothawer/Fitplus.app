// FitPulse Bottom Navigation Bar for Mobile with Desktop Adaptive Sidebar
// Implements Sections 5 & 47

import React from 'react';
import { Home, Calendar, Play, TrendingUp, Settings } from 'lucide-react';

export default function BottomNavigation({ currentTab, onSelectTab, isWorkoutActive = false }) {
  const navItems = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'plan', label: 'الخطة', icon: Calendar },
    { id: 'workout', label: 'التمرين', icon: Play, isAction: true },
    { id: 'progress', label: 'التقدم', icon: TrendingUp },
    { id: 'settings', label: 'الإعدادات', icon: Settings }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-dark-950/90 backdrop-blur-xl border-t border-slate-800/80 px-2 py-1.5 pb-safe max-w-lg mx-auto sm:rounded-t-3xl">
      <div className="flex items-center justify-around">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          if (item.isAction) {
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className="relative -top-3.5 flex flex-col items-center group focus:outline-none"
                aria-label={item.label}
              >
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-transform duration-200 group-hover:scale-105 active:scale-95 ${
                  isActive || isWorkoutActive
                    ? 'bg-gradient-to-tr from-emerald-500 via-neon-green to-lime-400 text-dark-950 shadow-glow-green animate-pulse-slow'
                    : 'bg-gradient-to-tr from-emerald-600 to-neon-green text-dark-950 shadow-glow-green'
                }`}>
                  <Icon size={26} className="fill-current translate-x-0.5" />
                </div>
                <span className={`text-[11px] font-extrabold mt-0.5 ${isActive ? 'text-neon-green' : 'text-slate-300'}`}>
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 min-w-[56px] min-h-[48px] rounded-xl transition-colors ${
                isActive
                  ? 'text-neon-green'
                  : 'text-slate-400 hover:text-slate-200 active:bg-dark-900'
              }`}
            >
              <Icon size={21} className={isActive ? 'stroke-[2.5]' : 'stroke-2'} />
              <span className={`text-[11px] mt-1 font-medium ${isActive ? 'font-bold text-white' : ''}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
