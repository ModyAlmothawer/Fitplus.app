// XP Progress Bar & Level Indicator
// Implements Section 33

import React from 'react';
import { Zap } from 'lucide-react';
import { calculateLevel } from '../services/xp';

export default function XPBar({ totalXp = 0, compact = false }) {
  const { level, currentLevelXp, neededXp, progressPercentage } = calculateLevel(totalXp);

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-neon-green text-xs font-bold">
          <Zap size={13} className="fill-neon-green" />
          <span>مستوى {level}</span>
        </div>
        <div className="w-20 h-2 bg-dark-800 rounded-full overflow-hidden border border-slate-700/50">
          <div
            className="h-full bg-neon-green rounded-full transition-all duration-500"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="w-full bg-dark-900/90 border border-slate-800 rounded-2xl p-4 backdrop-blur-md">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-600 to-neon-green flex items-center justify-center text-dark-950 font-black text-sm shadow-glow-green">
            {level}
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">المستوى الحالي</span>
            <span className="text-sm font-bold text-white">المستوى {level}</span>
          </div>
        </div>

        <div className="text-left font-mono">
          <span className="text-sm font-extrabold text-neon-green">{currentLevelXp}</span>
          <span className="text-xs text-slate-400"> / {neededXp} XP</span>
        </div>
      </div>

      <div className="h-2.5 w-full bg-dark-800 rounded-full overflow-hidden p-0.5 border border-slate-700/50">
        <div
          className="h-full bg-gradient-to-r from-emerald-500 via-neon-green to-teal-400 rounded-full transition-all duration-700 shadow-glow-green"
          style={{ width: `${progressPercentage}%` }}
        />
      </div>
    </div>
  );
}
