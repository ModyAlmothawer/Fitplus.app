// FitPulse Top Application Header

import React from 'react';
import { Volume2, VolumeX, Flame } from 'lucide-react';
import XPBar from './XPBar';

export default function Header({ profile, settings, onToggleVoice }) {
  return (
    <header className="sticky top-0 z-20 w-full bg-dark-950/80 backdrop-blur-lg border-b border-slate-800/80 px-4 py-3">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
        {/* Logo and Brand */}
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-neon-green flex items-center justify-center text-dark-950 font-black shadow-glow-green">
            <Flame size={22} className="fill-dark-950" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-1 font-mono">
              FitPulse
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-neon-green font-semibold">AI</span>
            </h1>
            <p className="text-[10px] text-slate-400 font-medium">مدرب اللياقة الذكي</p>
          </div>
        </div>

        {/* Level & Controls */}
        <div className="flex items-center gap-2.5">
          <XPBar totalXp={profile?.xp || 0} compact={true} />

          {/* Voice Sound Toggle */}
          <button
            onClick={onToggleVoice}
            title={settings?.voice ? "كتم الصوت" : "تفعيل الصوت"}
            aria-label="تبديل الصوت"
            className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-all ${
              settings?.voice
                ? 'bg-emerald-500/15 border-emerald-500/30 text-neon-green'
                : 'bg-dark-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {settings?.voice ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>
        </div>
      </div>
    </header>
  );
}
