// Canvas Overlay for Drawing 33 MediaPipe Pose Landmarks & Biomechanical Skeleton
// Features smooth velocity-filtered rendering, confidence fading, and prominent active joints

import React, { useEffect, useRef } from 'react';

// MediaPipe 33 Landmark Connections (Standard Pose Topology)
const POSE_CONNECTIONS = [
  // Head
  [0, 1], [1, 2], [2, 3], [3, 7], [0, 4], [4, 5], [5, 6], [6, 8], [9, 10],
  // Torso
  [11, 12], [11, 23], [12, 24], [23, 24],
  // Left Arm
  [11, 13], [13, 15], [15, 17], [15, 19], [15, 21], [17, 19],
  // Right Arm
  [12, 14], [14, 16], [16, 18], [16, 20], [16, 22], [18, 20],
  // Left Leg
  [23, 25], [25, 27], [27, 29], [27, 31], [29, 31],
  // Right Leg
  [24, 26], [26, 28], [28, 30], [28, 32], [30, 32]
];

export default function SkeletonOverlay({
  landmarks,
  exerciseConfig,
  formStatus = 'good',
  isReady = false
}) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    // Match internal canvas resolution to displayed dimensions
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.clearRect(0, 0, width, height);

    if (!landmarks || landmarks.length === 0) return;

    // Color logic
    let strokeRgb = '56, 189, 248'; // sky blue neutral
    let dotColor = '#38bdf8';

    if (isReady) {
      if (formStatus === 'good') {
        strokeRgb = '34, 197, 94'; // neon green
        dotColor = '#22c55e';
      } else if (formStatus === 'warning') {
        strokeRgb = '239, 68, 68'; // alert red
        dotColor = '#ef4444';
      } else {
        strokeRgb = '245, 158, 11'; // amber info
        dotColor = '#f59e0b';
      }
    } else {
      strokeRgb = '148, 163, 184';
      dotColor = '#94a3b8';
    }

    const activeLandmarkSet = new Set(exerciseConfig?.activeLandmarks || []);

    // 1. Draw Skeleton Lines with smooth opacity and anti-aliasing
    ctx.lineWidth = 3.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    for (const [startIdx, endIdx] of POSE_CONNECTIONS) {
      const p1 = landmarks[startIdx];
      const p2 = landmarks[endIdx];

      if (
        p1 && p2 &&
        p1.opacity !== 0 && p2.opacity !== 0 &&
        (p1.visibility === undefined || p1.visibility > 0.3) &&
        (p2.visibility === undefined || p2.visibility > 0.3)
      ) {
        // Mirrored coordinate calculation: X is flipped
        const x1 = (1 - p1.x) * width;
        const y1 = p1.y * height;
        const x2 = (1 - p2.x) * width;
        const y2 = p2.y * height;

        const lineOpacity = Math.min(p1.opacity || 1.0, p2.opacity || 1.0) * (isReady ? 0.85 : 0.4);
        ctx.strokeStyle = `rgba(${strokeRgb}, ${lineOpacity})`;

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
    }

    // 2. Draw 33 Landmarks with glowing active joints
    landmarks.forEach((p, idx) => {
      if (!p || p.opacity === 0 || (p.visibility !== undefined && p.visibility < 0.25)) return;

      const x = (1 - p.x) * width;
      const y = p.y * height;
      const isActive = activeLandmarkSet.has(idx);
      const pointOpacity = p.opacity || 1.0;

      ctx.save();
      ctx.globalAlpha = pointOpacity;

      if (isActive && isReady) {
        // Concentric glowing halo for active joints (Section 3 & 15)
        ctx.shadowColor = dotColor;
        ctx.shadowBlur = 16;

        // Outer pulsing ring
        ctx.beginPath();
        ctx.arc(x, y, 10, 0, 2 * Math.PI);
        ctx.fillStyle = `rgba(${strokeRgb}, 0.25)`;
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = dotColor;
        ctx.stroke();

        // Inner solid core
        ctx.beginPath();
        ctx.arc(x, y, 5.5, 0, 2 * Math.PI);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
      } else {
        // Normal joint
        const radius = 3.5;
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, 2 * Math.PI);
        ctx.fillStyle = isActive ? dotColor : '#ffffff';
        ctx.fill();
      }

      ctx.restore();
    });

  }, [landmarks, exerciseConfig, formStatus, isReady]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-10"
    />
  );
}
