// Canvas Overlay for Drawing 33 MediaPipe Pose Landmarks & Biomechanical Skeleton
// Implements Section 15

import React, { useEffect, useRef } from 'react';

// MediaPipe 33 Landmark Connections (Standard Pose Topology)
const POSE_CONNECTIONS = [
  // Head
  [0, 1], [1, 2], [2, 3], [3, 7], [0, 4], [4, 5], [5, 6], [6, 8], [9, 10],
  // Torso
  [11, 12], [11, 23], [12, 24], [23, 24],
  // Left Arm
  [11, 13], [13, 15], [15, 17], [15, 19], [15, 21], [17, 19],
  // Right Arm
  [12, 14], [14, 16], [16, 18], [16, 20], [16, 22], [18, 20],
  // Left Leg
  [23, 25], [25, 27], [27, 29], [27, 31], [29, 31],
  // Right Leg
  [24, 26], [26, 28], [28, 30], [28, 32], [30, 32]
];

export default function SkeletonOverlay({ landmarks, exerciseConfig, formStatus = 'good', isReady = false }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    // Match internal canvas resolution to displayed dimensions
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.clearRect(0, 0, width, height);

    if (!landmarks || landmarks.length === 0) return;

    // Color logic according to Section 15:
    // good: green (#22c55e), bad/warning: red (#ef4444), neutral: accent (#38bdf8 or #64748b)
    let strokeColor = '#38bdf8';
    let dotColor = '#38bdf8';

    if (isReady) {
      if (formStatus === 'good') {
        strokeColor = 'rgba(34, 197, 94, 0.85)';
        dotColor = '#22c55e';
      } else if (formStatus === 'warning') {
        strokeColor = 'rgba(239, 68, 68, 0.85)';
        dotColor = '#ef4444';
      } else {
        strokeColor = 'rgba(245, 158, 11, 0.85)';
        dotColor = '#f59e0b';
      }
    } else {
      strokeColor = 'rgba(148, 163, 184, 0.4)';
      dotColor = 'rgba(148, 163, 184, 0.6)';
    }

    const activeLandmarkSet = new Set(exerciseConfig?.activeLandmarks || []);

    // 1. Draw Skeleton Lines
    ctx.lineWidth = 3.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = strokeColor;

    for (const [startIdx, endIdx] of POSE_CONNECTIONS) {
      const p1 = landmarks[startIdx];
      const p2 = landmarks[endIdx];

      if (
        p1 && p2 &&
        (p1.visibility === undefined || p1.visibility > 0.4) &&
        (p2.visibility === undefined || p2.visibility > 0.4)
      ) {
        // Mirrored coordinate calculation: X is flipped
        const x1 = (1 - p1.x) * width;
        const y1 = p1.y * height;
        const x2 = (1 - p2.x) * width;
        const y2 = p2.y * height;

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
    }

    // 2. Draw 33 Glowing Landmark Dots
    landmarks.forEach((p, idx) => {
      if (!p || (p.visibility !== undefined && p.visibility < 0.4)) return;

      const x = (1 - p.x) * width;
      const y = p.y * height;
      const isActive = activeLandmarkSet.has(idx);

      // Active joints are larger with a pulsing neon halo
      const radius = isActive ? 7 : 4;

      ctx.save();
      if (isActive && isReady) {
        ctx.shadowColor = dotColor;
        ctx.shadowBlur = 14;
      }

      ctx.beginPath();
      ctx.arc(x, y, radius, 0, 2 * Math.PI);
      ctx.fillStyle = isActive ? dotColor : '#ffffff';
      ctx.fill();

      // Outer border on active joints
      if (isActive) {
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();
      }
      ctx.restore();
    });

  }, [landmarks, exerciseConfig, formStatus, isReady]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-10"
    />
  );
}
