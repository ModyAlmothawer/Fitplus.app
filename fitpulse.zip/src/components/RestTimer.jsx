// Rest Timer Overlay with animated countdown & skip button
// Implements Section 22

import React, { useEffect, useState } from 'react';
import { FastForward, CheckCircle2 } from 'lucide-react';
import { speechService } from '../services/speech';

export default function RestTimer({ initialSeconds = 30, onComplete, onSkip, currentSet, totalSets }) {
  const [timeLeft, setTimeLeft] = useState(initialSeconds);

  useEffect(() => {
    if (timeLeft <= 0) {
      speechService.speakRestOver();
      onComplete();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, onComplete]);

  const progress = Math.max(0, (timeLeft / initialSeconds) * 100);

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-dark-950/85 backdrop-blur-md p-6 animate-fade-in">
      <div className="w-full max-w-sm bg-dark-900 border border-slate-700/70 rounded-3xl p-6 text-center shadow-2xl flex flex-col items-center">
        {/* Celebration Header */}
        <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-neon-green mb-3">
          <CheckCircle2 size={36} />
        </div>

        <h3 className="text-2xl font-extrabold text-white mb-1">
          أحسنت! 🔥
        </h3>
        <p className="text-sm text-slate-300 mb-6 font-medium">
          المجموعة {currentSet} من {totalSets} خلصت بنجاح
        </p>

        {/* Circular Countdown Display */}
        <div className="relative w-36 h-36 flex items-center justify-center mb-6">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="44"
              className="text-slate-800"
              strokeWidth="7"
              stroke="currentColor"
              fill="transparent"
            />
            <circle
              cx="50"
              cy="50"
              r="44"
              className="text-neon-green transition-all duration-1000 ease-linear"
              strokeWidth="7"
              strokeDasharray={276.4}
              strokeDashoffset={276.4 - (276.4 * progress) / 100}
              strokeLinecap="round"
              stroke="currentColor"
              fill="transparent"
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-4xl font-black text-white font-mono">{timeLeft}</span>
            <span className="text-xs font-semibold text-slate-400 mt-0.5">ثانية راحة</span>
          </div>
        </div>

        {/* Skip Rest CTA */}
        <button
          onClick={onSkip}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-neon-green text-dark-950 font-black text-base flex items-center justify-center gap-2 hover:opacity-95 active:scale-95 transition-all shadow-glow-green"
        >
          <FastForward size={20} />
          <span>تخطي الراحة والبدء</span>
        </button>
      </div>
    </div>
  );
}
