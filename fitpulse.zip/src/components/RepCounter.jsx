// Large Visual Rep Counter for Workout Screen
// Implements Section 21

import React from 'react';

export default function RepCounter({ reps, currentSet, totalSets, targetReps, exerciseType = 'repetition' }) {
  const isIsometric = exerciseType === 'isometric';
  const progressPercent = Math.min(100, Math.round((reps / Math.max(1, targetReps)) * 100));

  return (
    <div className="flex flex-col items-center justify-center p-3">
      {/* Set Badge */}
      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-dark-900/80 backdrop-blur-md border border-slate-700/60 text-xs font-semibold text-slate-300 mb-1">
        <span>المجموعة</span>
        <span className="text-neon-green font-bold">{currentSet}</span>
        <span>/</span>
        <span>{totalSets}</span>
      </div>

      {/* Giant Rep Display */}
      <div className="relative flex flex-col items-center my-0.5">
        <div className="text-7xl sm:text-8xl font-black tracking-tight text-white glow-text-green font-mono leading-none select-none transition-transform duration-150 transform active:scale-105">
          {reps}
        </div>
        <div className="text-base sm:text-lg font-bold text-slate-300 mt-1">
          {isIsometric ? "ثانية ثبات" : "تكرار"}
        </div>
      </div>

      {/* Target & Micro Progress Bar */}
      <div className="w-full max-w-[200px] mt-1.5">
        <div className="flex justify-between items-center text-xs font-medium text-slate-400 mb-1 px-1">
          <span>الهدف</span>
          <span className="text-slate-200 font-bold">{targetReps} {isIsometric ? "ث" : "تكرار"}</span>
        </div>
        <div className="h-1.5 w-full bg-dark-800 rounded-full overflow-hidden border border-slate-700/40">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-neon-green rounded-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
}
