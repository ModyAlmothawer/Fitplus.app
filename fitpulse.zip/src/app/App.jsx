// Main Application Root Component for FitPulse
// Implements Screens Navigation, State Management, and LocalStorage Synchronization

import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import BottomNavigation from '../components/BottomNavigation';
import Home from '../screens/Home';
import WeeklyPlan from '../screens/WeeklyPlan';
import Workout from '../screens/Workout';
import Summary from '../screens/Summary';
import Progress from '../screens/Progress';
import Settings from '../screens/Settings';

import { loadData, saveData, resetData } from '../storage/storage';
import { updateStreak, calculateLevel, checkNewBadges, estimateCalories, XP_CONFIG } from '../services/xp';
import { speechService } from '../services/speech';

export default function App() {
  const [appData, setAppData] = useState(null);
  const [currentTab, setCurrentTab] = useState('home'); // 'home' | 'plan' | 'workout' | 'summary' | 'progress' | 'settings'

  // Active workout execution context
  const [activeWorkoutExerciseId, setActiveWorkoutExerciseId] = useState('squat');
  const [activeWorkoutPlanItem, setActiveWorkoutPlanItem] = useState(null);
  const [lastSessionSummary, setLastSessionSummary] = useState(null);
  const [newlyUnlockedBadges, setNewlyUnlockedBadges] = useState([]);

  // Load persisted state on mount
  useEffect(() => {
    const data = loadData();
    setAppData(data);
    if (data?.settings?.voice !== undefined) {
      speechService.setEnabled(data.settings.voice);
    }
  }, []);

  // Sync state to localStorage whenever appData updates
  const updateAppData = (updater) => {
    setAppData(prev => {
      const next = typeof updater === 'function' ? updater(prev) : { ...prev, ...updater };
      saveData(next);
      return next;
    });
  };

  const handleToggleSound = () => {
    if (!appData) return;
    const nextVal = !appData.settings.voice;
    speechService.setEnabled(nextVal);
    updateAppData(prev => ({
      ...prev,
      settings: { ...prev.settings, voice: nextVal }
    }));
  };

  const handleStartWorkout = (exerciseId = 'squat', planItem = null) => {
    setActiveWorkoutExerciseId(exerciseId);
    setActiveWorkoutPlanItem(planItem);
    setCurrentTab('workout');
  };

  const handleFinishWorkout = (sessionResults) => {
    if (!appData) return;

    const { reps, sets, duration, formScore, exerciseId, exerciseNameAr } = sessionResults;
    const calories = estimateCalories(exerciseId, reps, duration);

    // XP calculation
    const earnedXp = (reps * XP_CONFIG.PER_REP) + (sets * XP_CONFIG.PER_SET) + XP_CONFIG.PER_WORKOUT;
    const newTotalXp = (appData.profile.xp || 0) + earnedXp;
    const levelInfo = calculateLevel(newTotalXp);

    // Streak update
    const streakResult = updateStreak(appData.profile.streak || 0, appData.profile.lastWorkoutDate);

    // Construct workout log entry
    const newWorkoutEntry = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      exerciseId,
      exerciseNameAr,
      reps,
      sets,
      duration,
      calories,
      formScore,
      xpEarned: earnedXp
    };

    const updatedWorkouts = [newWorkoutEntry, ...(appData.workouts || [])];

    const updatedProfile = {
      ...appData.profile,
      xp: newTotalXp,
      level: levelInfo.level,
      streak: streakResult.streak,
      bestStreak: Math.max(streakResult.streak, appData.profile.bestStreak || 0),
      totalWorkouts: (appData.profile.totalWorkouts || 0) + 1,
      totalReps: (appData.profile.totalReps || 0) + reps,
      lastWorkoutDate: streakResult.todayStr
    };

    // Check newly unlocked badges
    const { unlocked, newlyUnlocked } = checkNewBadges(
      updatedProfile,
      updatedWorkouts,
      appData.badges || [],
      appData.weeklyPlan
    );

    updatedProfile.badges = unlocked;

    updateAppData({
      profile: updatedProfile,
      workouts: updatedWorkouts,
      badges: unlocked
    });

    setLastSessionSummary(sessionResults);
    setNewlyUnlockedBadges(newlyUnlocked);
    setCurrentTab('summary');
  };

  const handleCancelWorkout = () => {
    setCurrentTab('home');
  };

  const handleResetData = () => {
    const initial = resetData();
    setAppData(initial);
    setCurrentTab('home');
  };

  if (!appData) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center text-white">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-full border-4 border-emerald-500/20 border-t-neon-green animate-spin" />
          <span className="text-sm font-bold text-slate-300">جاري تشغيل FitPulse...</span>
        </div>
      </div>
    );
  }

  // Active workout fullscreen camera bypasses normal navigation
  if (currentTab === 'workout') {
    const nextExerciseNameAr = activeWorkoutExerciseId === 'squat' ? 'تمرين الضغط' : 'سكوات';
    return (
      <Workout
        activeExerciseId={activeWorkoutExerciseId}
        planDayExercise={activeWorkoutPlanItem}
        nextExerciseNameAr={nextExerciseNameAr}
        settings={appData.settings || {}}
        onToggleSound={handleToggleSound}
        onFinishWorkout={handleFinishWorkout}
        onCancelWorkout={handleCancelWorkout}
      />
    );
  }

  return (
    <div className="min-h-screen bg-dark-950 text-white selection:bg-emerald-500 selection:text-dark-950 flex flex-col justify-between">
      {/* Top Application Header */}
      <Header
        profile={appData.profile}
        settings={appData.settings}
        onToggleVoice={handleToggleSound}
      />

      {/* Screen Body */}
      <main className="flex-1 w-full">
        {currentTab === 'home' && (
          <Home
            profile={appData.profile}
            weeklyPlan={appData.weeklyPlan}
            onStartWorkout={handleStartWorkout}
            onOpenPlan={() => setCurrentTab('plan')}
            onQuickExercise={handleStartWorkout}
          />
        )}

        {currentTab === 'plan' && (
          <WeeklyPlan
            weeklyPlan={appData.weeklyPlan}
            onUpdatePlan={(updatedPlan) => updateAppData({ weeklyPlan: updatedPlan })}
            onStartExercise={handleStartWorkout}
          />
        )}

        {currentTab === 'summary' && (
          <Summary
            sessionData={lastSessionSummary}
            profile={appData.profile}
            newBadges={newlyUnlockedBadges}
            onReturnHome={() => setCurrentTab('home')}
          />
        )}

        {currentTab === 'progress' && (
          <Progress
            profile={appData.profile}
            workouts={appData.workouts}
            weeklyPlan={appData.weeklyPlan}
          />
        )}

        {currentTab === 'settings' && (
          <Settings
            settings={appData.settings}
            onUpdateSettings={(updated) => updateAppData({ settings: updated })}
            onResetAllData={handleResetData}
          />
        )}
      </main>

      {/* Bottom Sticky Mobile Navigation */}
      {currentTab !== 'summary' && (
        <BottomNavigation
          currentTab={currentTab}
          onSelectTab={(tabId) => {
            if (tabId === 'workout') {
              handleStartWorkout('squat');
            } else {
              setCurrentTab(tabId);
            }
          }}
          isWorkoutActive={false}
        />
      )}
    </div>
  );
}
