// Workout Summary Screen with Metrics & Confetti
// Implements Sections 36, 37, 38

import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Flame, Clock, Award, Activity, Zap, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { estimateCalories } from '../services/xp';

export default function Summary({ sessionData, profile, newBadges = [], onReturnHome }) {
  useEffect(() => {
    // Tasteful confetti burst on mount
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#22c55e', '#10b981', '#f97316', '#38bdf8']
      });
    } catch (e) {
      // Ignore if unavailable
    }
  }, []);

  const totalReps = sessionData?.reps || 0;
  const durationSec = sessionData?.duration || 60;
  const sets = sessionData?.sets || 1;
  const formScore = sessionData?.formScore || 85;
  const calories = estimateCalories(sessionData?.exerciseId || 'squat', totalReps, durationSec);

  // Form score category (Section 38: ممتاز / جيد / يحتاج تحسين)
  let formLabel = "ممتاز";
  let formColor = "text-neon-green";
  if (formScore < 70) {
    formLabel = "يحتاج تحسين";
    formColor = "text-amber-400";
  } else if (formScore < 85) {
    formLabel = "جيد";
    formColor = "text-teal-400";
  }

  // XP calculation
  const xpEarned = (totalReps * 1) + (sets * 10) + 50;

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-dark-950 text-white flex flex-col justify-between p-4 sm:p-6 pb-24 max-w-lg mx-auto">
      <div>
        {/* Header Badge */}
        <div className="flex flex-col items-center text-center mt-4 mb-6">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-emerald-600 via-neon-green to-teal-400 flex items-center justify-center text-dark-950 mb-3 shadow-glow-green animate-bounce-subtle">
            <Trophy size={42} className="stroke-[2.5]" />
          </div>
          <h2 className="text-3xl font-black tracking-tight text-white mb-1">
            خلصت التمرين! 🔥
          </h2>
          <p className="text-sm text-slate-300 font-medium">
            إنجاز بطل! كل تكرار صنع فارقاً في لياقتك اليوم
          </p>
        </div>

        {/* Primary XP Banner */}
        <div className="w-full bg-gradient-to-r from-emerald-950/80 via-dark-900 to-emerald-950/80 border border-emerald-500/40 rounded-3xl p-4 mb-5 flex items-center justify-between shadow-glow-green">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-neon-green flex items-center justify-center">
              <Zap size={22} className="fill-neon-green" />
            </div>
            <div>
              <span className="text-xs text-slate-400 block font-medium">نقاط الخبرة المكتسبة</span>
              <span className="text-xl font-black text-neon-green font-mono">+{xpEarned} XP</span>
            </div>
          </div>
          <div className="text-left font-mono">
            <span className="text-xs text-slate-400 block font-medium">المستوى</span>
            <span className="text-base font-extrabold text-white">مستوى {profile?.level || 1}</span>
          </div>
        </div>

        {/* 4 Core Metrics Grid */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          {/* Total Reps */}
          <div className="bg-dark-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col">
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="text-xs font-semibold">إجمالي التكرارات</span>
              <Flame size={16} className="text-neon-green" />
            </div>
            <span className="text-3xl font-black text-white font-mono">{totalReps}</span>
            <span className="text-[11px] text-slate-400 mt-1 font-medium">{sets} مجموعات</span>
          </div>

          {/* Duration */}
          <div className="bg-dark-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col">
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="text-xs font-semibold">مدة التمرين</span>
              <Clock size={16} className="text-sky-400" />
            </div>
            <span className="text-3xl font-black text-white font-mono">{formatDuration(durationSec)}</span>
            <span className="text-[11px] text-slate-400 mt-1 font-medium">دقيقة : ثانية</span>
          </div>

          {/* Form Score */}
          <div className="bg-dark-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col">
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="text-xs font-semibold">جودة الأداء</span>
              <Activity size={16} className="text-emerald-400" />
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-black text-white font-mono">{formScore}%</span>
              <span className={`text-xs font-bold ${formColor}`}>{formLabel}</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-1 font-medium">دقة الحركة والزوايا</span>
          </div>

          {/* Estimated Calories */}
          <div className="bg-dark-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col">
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="text-xs font-semibold">السعرات المقدرة</span>
              <Flame size={16} className="text-accent-orange" />
            </div>
            <span className="text-3xl font-black text-accent-orange font-mono">{calories}</span>
            <span className="text-[10px] text-slate-400 mt-1 font-medium">سعرة حرارية (تقديري)</span>
          </div>
        </div>

        {/* Newly Unlocked Badges (Section 36) */}
        {newBadges && newBadges.length > 0 && (
          <div className="bg-gradient-to-tr from-dark-900 to-dark-850 border border-amber-500/40 rounded-2xl p-4 mb-5">
            <div className="flex items-center gap-2 mb-2 text-amber-400 font-bold text-sm">
              <Award size={18} />
              <span>وسام جديد تم فتحه! 🎉</span>
            </div>
            <div className="space-y-2">
              {newBadges.map((badge, idx) => (
                <div key={idx} className="flex items-center gap-3 bg-dark-800/80 p-2.5 rounded-xl border border-amber-500/20">
                  <span className="text-2xl">{badge.icon}</span>
                  <div>
                    <h4 className="text-sm font-bold text-white">{badge.title}</h4>
                    <p className="text-xs text-slate-300">{badge.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Main Return Home CTA */}
      <button
        onClick={onReturnHome}
        className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-neon-green text-dark-950 font-black text-base shadow-glow-green flex items-center justify-center gap-2 hover:opacity-95 active:scale-95 transition-all mt-4"
      >
        <span>العودة للصفحة الرئيسية</span>
        <ArrowLeft size={20} />
      </button>
    </div>
  );
}
