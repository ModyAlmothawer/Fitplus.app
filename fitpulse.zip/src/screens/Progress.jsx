// Progress & Statistics Screen
// Implements Sections 34 & 39

import React from 'react';
import { TrendingUp, Award, Flame, Dumbbell, Zap, Trophy, ShieldCheck, Lock } from 'lucide-react';
import { BADGES_DEFINITION } from '../services/xp';

export default function Progress({ profile, workouts = [], weeklyPlan }) {
  const hasWorkouts = workouts && workouts.length > 0;

  // Calculate day-by-day reps for the last 7 days from actual recorded workouts
  const dayNamesAr = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const dailyReps = [0, 0, 0, 0, 0, 0, 0];

  workouts.forEach(w => {
    if (w.date) {
      const d = new Date(w.date);
      const dayIdx = d.getDay();
      dailyReps[dayIdx] += (w.reps || 0);
    }
  });

  const maxRepsInDay = Math.max(1, ...dailyReps);
  const unlockedBadges = new Set(profile?.badges || []);

  return (
    <div className="min-h-screen bg-dark-950 text-white p-4 sm:p-6 pb-28 max-w-lg mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-white">التقدم والإحصائيات</h2>
          <p className="text-xs text-slate-400 font-medium">أرقامك الحقيقية المسجلة من جلسات تمرينك</p>
        </div>
        <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-neon-green flex items-center justify-center">
          <TrendingUp size={20} />
        </div>
      </div>

      {/* 1. Weekly Reps Bar Chart (Section 39) */}
      <div className="w-full bg-dark-900/90 border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h3 className="text-sm font-extrabold text-white mb-1">تكرارات الأسبوع</h3>
        <p className="text-[11px] text-slate-400 font-medium mb-4">توزيع التكرارات المنجزة خلال أيام الأسبوع</p>

        {!hasWorkouts ? (
          <div className="p-8 rounded-2xl bg-dark-800/40 border border-slate-800 text-center flex flex-col items-center">
            <Dumbbell size={32} className="text-slate-600 mb-2" />
            <h4 className="text-sm font-bold text-white mb-1">لسه مفيش بيانات</h4>
            <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
              ابدأ أول تمرين عشان يظهر تقدمك ورسومك البيانية هنا.
            </p>
          </div>
        ) : (
          <div className="flex items-end justify-between gap-2 h-36 pt-6 pb-2">
            {dailyReps.map((reps, idx) => {
              const heightPercent = Math.max(8, Math.round((reps / maxRepsInDay) * 100));
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                  <span className="text-[10px] font-mono text-slate-400 font-bold">{reps > 0 ? reps : ''}</span>
                  <div className="w-full max-w-[28px] bg-dark-800 rounded-t-lg overflow-hidden h-full flex items-end">
                    <div
                      className={`w-full rounded-t-lg transition-all duration-700 ${
                        reps > 0
                          ? 'bg-gradient-to-t from-emerald-600 to-neon-green shadow-glow-green'
                          : 'bg-slate-700/30'
                      }`}
                      style={{ height: `${heightPercent}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-semibold text-slate-400">{dayNamesAr[idx]}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 2. Lifetime Statistics Cards Grid */}
      <div className="grid grid-cols-2 gap-3">
        {/* Total Workouts */}
        <div className="bg-dark-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold">إجمالي التمارين</span>
            <Trophy size={16} className="text-emerald-400" />
          </div>
          <span className="text-3xl font-black text-white font-mono">{profile?.totalWorkouts || 0}</span>
          <span className="text-[10px] text-slate-400 mt-1">جلسة تدريب مكتملة</span>
        </div>

        {/* Total Reps */}
        <div className="bg-dark-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold">إجمالي التكرارات</span>
            <Dumbbell size={16} className="text-neon-green" />
          </div>
          <span className="text-3xl font-black text-white font-mono">{profile?.totalReps || 0}</span>
          <span className="text-[10px] text-slate-400 mt-1">تكرار حقيقي تم رصده</span>
        </div>

        {/* Best Streak */}
        <div className="bg-dark-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold">أفضل سلسلة</span>
            <Flame size={16} className="text-accent-orange" />
          </div>
          <span className="text-3xl font-black text-white font-mono">{profile?.bestStreak || 0}</span>
          <span className="text-[10px] text-slate-400 mt-1">أيام متتالية دون انقطاع</span>
        </div>

        {/* Total XP */}
        <div className="bg-dark-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold">إجمالي النقاط</span>
            <Zap size={16} className="text-teal-400" />
          </div>
          <span className="text-3xl font-black text-neon-green font-mono">{profile?.xp || 0}</span>
          <span className="text-[10px] text-slate-400 mt-1">نقطة خبرة متراكمة</span>
        </div>
      </div>

      {/* 3. Achievements & Badges List (Section 34) */}
      <div className="w-full bg-dark-900/90 border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Award size={20} className="text-amber-400" />
            <h3 className="text-base font-extrabold text-white">أوسمة الإنجاز</h3>
          </div>
          <span className="text-xs font-mono text-neon-green font-bold">
            {unlockedBadges.size} / {BADGES_DEFINITION.length}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {BADGES_DEFINITION.map(b => {
            const isUnlocked = unlockedBadges.has(b.id);
            return (
              <div
                key={b.id}
                className={`p-3 rounded-2xl border flex items-center gap-3 transition-all ${
                  isUnlocked
                    ? 'bg-dark-800/90 border-emerald-500/40 text-white'
                    : 'bg-dark-850/40 border-slate-800/60 text-slate-500 opacity-60'
                }`}
              >
                <div className="text-3xl shrink-0">{b.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold truncate">{b.title}</h4>
                    {isUnlocked ? (
                      <ShieldCheck size={14} className="text-neon-green shrink-0" />
                    ) : (
                      <Lock size={13} className="text-slate-500 shrink-0" />
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 truncate mt-0.5">{b.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
