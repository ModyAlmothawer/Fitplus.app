// Application Settings & Device Configuration
// Implements Sections 40 & 41

import React, { useState } from 'react';
import {
  Settings as SettingsIcon, Volume2, Bell, Globe, Trash2,
  HelpCircle, Info, ShieldAlert, CheckCircle2, ChevronRight
} from 'lucide-react';
import { notificationService } from '../services/notifications';

export default function Settings({
  settings,
  onUpdateSettings,
  onResetAllData
}) {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [notifStatusMessage, setNotifStatusMessage] = useState(null);

  const handleToggleVoice = () => {
    onUpdateSettings({
      ...settings,
      voice: !settings.voice
    });
  };

  const handleToggleNotifications = async () => {
    if (!settings.notifications) {
      if (!notificationService.isSupported()) {
        setNotifStatusMessage("التذكيرات غير مدعومة في هذا المتصفح.");
        return;
      }
      const granted = await notificationService.requestPermission();
      if (granted) {
        onUpdateSettings({ ...settings, notifications: true });
        setNotifStatusMessage("تم تفعيل الإشعارات بنجاح! سنرسل لك تذكيرات خفيفة بالتمارين.");
        notificationService.sendReminder("أهلاً بيك في تذكيرات FitPulse 🔥", "سنساعدك على الالتزام بسلسلة تمارينك اليومية.");
      } else {
        setNotifStatusMessage("تم رفض إذن الإشعارات من المتصفح.");
      }
    } else {
      onUpdateSettings({ ...settings, notifications: false });
      setNotifStatusMessage("تم إيقاف التذكيرات اليومية.");
    }
  };

  return (
    <div className="min-h-screen bg-dark-950 text-white p-4 sm:p-6 pb-28 max-w-lg mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-white">الإعدادات</h2>
          <p className="text-xs text-slate-400 font-medium">تخصيص التطبيق والخيارات الصوتية والتنبيهات</p>
        </div>
        <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-neon-green flex items-center justify-center">
          <SettingsIcon size={20} />
        </div>
      </div>

      {/* 1. Voice & Audio Settings */}
      <div className="bg-dark-900/90 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-4">
        <h3 className="text-xs font-bold text-neon-green uppercase tracking-wider">الصوت والتوجيه</h3>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-neon-green flex items-center justify-center shrink-0">
              <Volume2 size={18} />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">العد الصوتي بالذكاء الاصطناعي</h4>
              <p className="text-xs text-slate-400">نطق أرقام التكرارات وتشجيع إتمام المجموعات باللغة العربية</p>
            </div>
          </div>

          <button
            onClick={handleToggleVoice}
            className={`w-12 h-6 rounded-full transition-colors relative p-0.5 focus:outline-none ${
              settings?.voice ? 'bg-neon-green' : 'bg-dark-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-dark-950 shadow-md transform transition-transform ${
                settings?.voice ? 'translate-x-0' : '-translate-x-6'
              }`}
            />
          </button>
        </div>
      </div>

      {/* 2. Notifications & Reminders (Section 41) */}
      <div className="bg-dark-900/90 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-4">
        <h3 className="text-xs font-bold text-neon-green uppercase tracking-wider">الإشعارات والتذكيرات</h3>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
              <Bell size={18} />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">فعّل التذكير اليومي</h4>
              <p className="text-xs text-slate-400">تذكير خفيف يحثك على الاستمرار وبناء Streak يومي</p>
            </div>
          </div>

          <button
            onClick={handleToggleNotifications}
            className={`w-12 h-6 rounded-full transition-colors relative p-0.5 focus:outline-none ${
              settings?.notifications ? 'bg-neon-green' : 'bg-dark-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-dark-950 shadow-md transform transition-transform ${
                settings?.notifications ? 'translate-x-0' : '-translate-x-6'
              }`}
            />
          </button>
        </div>

        {notifStatusMessage && (
          <div className="text-xs font-medium text-amber-300 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20">
            {notifStatusMessage}
          </div>
        )}
      </div>

      {/* 3. Camera Troubleshooting Guide (Section 42) */}
      <div className="bg-dark-900/90 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-3">
        <div className="flex items-center gap-2 text-white font-bold text-sm">
          <HelpCircle size={18} className="text-sky-400" />
          <span>دليل استكشاف مشاكل الكاميرا</span>
        </div>

        <ul className="text-xs text-slate-300 space-y-2 leading-relaxed">
          <li className="flex items-start gap-2">
            <span className="text-neon-green font-bold">•</span>
            <span>ضع الهاتف على سطح ثابت أو مسند على بعد 2 إلى 3 أمتار من مكان وقوفك.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-neon-green font-bold">•</span>
            <span>تأكد من ظهور الرأس والكتفين والركبتين وأطراف القدمين بوضوح في الإطار.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-neon-green font-bold">•</span>
            <span>تجنب وجود أضواء ساطعة خلفك (مثل النوافذ المفتوحة) لأنها تعتم الجسم.</span>
          </li>
        </ul>
      </div>

      {/* 4. About FitPulse */}
      <div className="bg-dark-900/90 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-3">
        <div className="flex items-center gap-2 text-white font-bold text-sm">
          <Info size={18} className="text-emerald-400" />
          <span>عن تطبيق FitPulse</span>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed font-medium">
          FitPulse هو مدرب ذكي فائق الخصوصية يعمل بنموذج MediaPipe Pose Landmarker لمعالجة إحداثيات الحركة وحساب التكرارات محلياً بالكامل داخل المتصفح بدون أي رفع لبيانات الفيديو.
        </p>
      </div>

      {/* 5. Danger Zone: Reset Data */}
      <div className="bg-red-950/20 border border-red-500/30 rounded-3xl p-5 shadow-lg space-y-3">
        <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
          <ShieldAlert size={18} />
          <span>إدارة البيانات والمزامنة</span>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          يمكنك إعادة ضبط جميع البيانات وسجل التمارين والنقاط والأوسمة وإعادة التطبيق لحالته الأولية.
        </p>
        <button
          onClick={() => setShowResetConfirm(true)}
          className="w-full py-3 rounded-2xl bg-red-500/15 border border-red-500/40 text-red-400 font-bold text-xs flex items-center justify-center gap-2 hover:bg-red-500/25 active:scale-98 transition-all"
        >
          <Trash2 size={15} />
          <span>إعادة ضبط البيانات</span>
        </button>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-dark-950/85 backdrop-blur-md p-4">
          <div className="w-full max-w-sm bg-dark-900 border border-red-500/40 rounded-3xl p-6 text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mx-auto mb-3">
              <Trash2 size={24} />
            </div>
            <h4 className="text-lg font-bold text-white mb-2">هل أنت متأكد من حذف البيانات؟</h4>
            <p className="text-xs text-slate-300 mb-6 leading-relaxed">
              هذا الإجراء سيحذف كافة التمارين المسجلة، نقاط الخبرة (XP)، والأوسمة وسيعيد التطبيق كأنه جديد. لا يمكن التراجع.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  onResetAllData();
                  setShowResetConfirm(false);
                }}
                className="flex-1 py-3.5 rounded-xl bg-red-600 text-white font-bold text-xs hover:bg-red-500 transition-colors"
              >
                نعم، احذف كل شيء
              </button>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-3.5 rounded-xl bg-dark-800 text-slate-300 font-bold text-xs hover:bg-dark-700"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
