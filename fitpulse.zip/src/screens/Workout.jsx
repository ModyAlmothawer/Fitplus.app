// Workout Camera Screen with FitPulse Coach, MediaPipe Pose Tracking, and Interactive STT
// Implements Sections 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 15, 16

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Play, Pause, Volume2, VolumeX, AlertTriangle,
  CheckCircle2, Flame, ArrowRight, ShieldAlert, Sparkles, SwitchCamera
} from 'lucide-react';
import { PoseEngine } from '../engine/poseEngine';
import SkeletonOverlay from '../components/SkeletonOverlay';
import RepCounter from '../components/RepCounter';
import RestTimer from '../components/RestTimer';
import CoachOverlay from '../components/CoachOverlay';
import { EXERCISES } from '../exercises/exerciseConfig';
import { CoachEngine } from '../coach/coachEngine';
import { VoiceRecognitionService } from '../coach/speechRecognition';
import { speechQueue } from '../coach/speechQueue';

export default function Workout({
  activeExerciseId = 'squat',
  planDayExercise = null,
  nextExerciseNameAr = 'تمرين الضغط',
  onFinishWorkout,
  onCancelWorkout,
  settings = {},
  onToggleSound
}) {
  const videoRef = useRef(null);
  const engineRef = useRef(null);
  const coachEngineRef = useRef(null);
  const voiceServiceRef = useRef(null);

  // Exercise config
  const exerciseConfig = EXERCISES[activeExerciseId] || EXERCISES.squat;
  const targetReps = planDayExercise?.reps || exerciseConfig.defaultReps || 12;
  const totalSets = planDayExercise?.sets || exerciseConfig.defaultSets || 3;

  // Workout state
  const [currentSet, setCurrentSet] = useState(1);
  const [reps, setReps] = useState(0);
  const [totalCompletedReps, setTotalCompletedReps] = useState(0);
  const [isResting, setIsResting] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [setupDismissed, setSetupDismissed] = useState(false);

  // Countdown flow: null | 3 | 2 | 1 | 'GO'
  const [countdown, setCountdown] = useState(null);

  // Vision & Tracking state
  const [landmarks, setLandmarks] = useState(null);
  const [isReady, setIsReady] = useState(false);
  const [visibilityMessage, setVisibilityMessage] = useState("جاري تحميل النموذج الذكي...");
  const [formFeedback, setFormFeedback] = useState(null);
  const [formStatus, setFormStatus] = useState('neutral');
  const [cameraFacing, setCameraFacing] = useState('user');
  const [cameraError, setCameraError] = useState(null);
  const [isLoadingModel, setIsLoadingModel] = useState(true);

  // Coach state
  const [coachMessage, setCoachMessage] = useState("");
  const [isMicListening, setIsMicListening] = useState(false);

  // Exit dialog
  const [showExitConfirm, setShowExitConfirm] = useState(false);

  // Timer
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Initialize Speech Queue settings
  useEffect(() => {
    speechQueue.setSettings({
      enabled: settings.voice !== false && settings.coachVoice !== false,
      volume: settings.coachVolume !== undefined ? settings.coachVolume : 1.0
    });
  }, [settings]);

  // Workout Timer
  useEffect(() => {
    if (isPaused || isResting || !setupDismissed || countdown !== null) return;
    const interval = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isPaused, isResting, setupDismissed, countdown]);

  // Handle countdown flow (3 -> 2 -> 1 -> GO)
  const startCountdown = () => {
    setSetupDismissed(true);
    setCountdown(3);

    if (coachEngineRef.current) {
      coachEngineRef.current.triggerEvent('COUNTDOWN');
    }

    let count = 3;
    const interval = setInterval(() => {
      count--;
      if (count > 0) {
        setCountdown(count);
      } else if (count === 0) {
        setCountdown('GO');
      } else {
        clearInterval(interval);
        setCountdown(null);
        if (coachEngineRef.current) {
          coachEngineRef.current.triggerEvent('WORKOUT_STARTED');
        }
      }
    }, 1000);
  };

  // Handle a detected rep from PoseEngine
  const handleRepDetected = useCallback((repCount, exerciseType, quality) => {
    if (isResting || isPaused || countdown !== null) return;

    setReps(repCount);
    setTotalCompletedReps(prev => prev + 1);

    if (coachEngineRef.current) {
      coachEngineRef.current.updateState({
        currentRep: repCount,
        workoutTime: elapsedSeconds
      });
      coachEngineRef.current.triggerEvent('REP_COMPLETED', { rep: repCount, quality });
    }

    // Check if target reps achieved for this set
    if (repCount >= targetReps) {
      handleSetCompleted(currentSet);
    }
  }, [isResting, isPaused, countdown, targetReps, currentSet, elapsedSeconds]);

  const handleSetCompleted = (finishedSet) => {
    if (coachEngineRef.current) {
      coachEngineRef.current.triggerEvent('SET_COMPLETED', { set: finishedSet });
    }

    if (finishedSet >= totalSets) {
      // Completed all sets for this exercise!
      finishWorkoutSession(totalCompletedReps + 1);
    } else {
      // Transition to rest timer
      setIsResting(true);
    }
  };

  const handleRestFinished = () => {
    setIsResting(false);
    setCurrentSet(prev => {
      const nextSet = prev + 1;
      if (coachEngineRef.current) {
        coachEngineRef.current.updateState({
          currentSet: nextSet,
          currentRep: 0
        });
      }
      return nextSet;
    });
    setReps(0);
    if (engineRef.current) {
      engineRef.current.reps = 0;
      engineRef.current.repState = (activeExerciseId === 'curl') ? 'DOWN' : 'UP';
    }
  };

  const finishWorkoutSession = (finalRepsCount = null) => {
    const finalReps = finalRepsCount !== null ? finalRepsCount : totalCompletedReps;
    const formScore = engineRef.current ? engineRef.current.getFormScore() : 88;
    const duration = Math.max(15, elapsedSeconds);

    if (coachEngineRef.current) {
      coachEngineRef.current.triggerEvent('WORKOUT_FINISHED');
    }

    if (engineRef.current) {
      engineRef.current.stop();
    }
    if (voiceServiceRef.current) {
      voiceServiceRef.current.stop();
    }

    onFinishWorkout({
      exerciseId: activeExerciseId,
      exerciseNameAr: exerciseConfig.nameAr,
      reps: finalReps,
      sets: currentSet,
      totalSets: totalSets,
      duration: duration,
      formScore: formScore
    });
  };

  // Initialize Coach Engine and Speech Recognition
  useEffect(() => {
    const coach = new CoachEngine({
      exerciseId: activeExerciseId,
      exerciseNameAr: exerciseConfig.nameAr,
      nextExerciseNameAr: nextExerciseNameAr,
      targetReps: targetReps,
      totalSets: totalSets,
      motivationLevel: settings.motivationLevel || 'hype',
      onCoachMessage: (msg) => {
        setCoachMessage(msg);
      }
    });

    coachEngineRef.current = coach;

    // Speech-to-Text Voice Recognition
    const voiceService = new VoiceRecognitionService(
      (intentType, transcript) => {
        coach.triggerEvent(intentType, { transcript });
      },
      (text) => {}
    );

    voiceServiceRef.current = voiceService;
    if (settings.micEnabled !== false && voiceService.isSupported()) {
      voiceService.start();
      setIsMicListening(true);
    }

    return () => {
      coach.destroy();
      voiceService.stop();
    };
  }, [activeExerciseId, exerciseConfig.nameAr, nextExerciseNameAr, targetReps, totalSets, settings.motivationLevel, settings.micEnabled]);

  // Initialize MediaPipe and Camera
  useEffect(() => {
    let mounted = true;

    async function init() {
      try {
        setIsLoadingModel(true);
        setCameraError(null);

        const engine = new PoseEngine({
          exerciseId: activeExerciseId,
          onLandmarks: (lms) => {
            if (mounted) setLandmarks(lms);
          },
          onRep: (count, type, quality) => {
            if (mounted) handleRepDetected(count, type, quality);
          },
          onVisibility: (vis) => {
            if (mounted) {
              setIsReady(vis.isReady);
              setVisibilityMessage(vis.messageAr);
            }
          },
          onFeedback: (fb) => {
            if (mounted) {
              setFormFeedback(fb.messageAr);
              setFormStatus(fb.status);
              if (fb.status === 'warning' && coachEngineRef.current) {
                coachEngineRef.current.triggerEvent('BAD_FORM', { errorType: fb.type });
              }
            }
          },
          onError: (errInfo) => {
            if (mounted) {
              if (errInfo.type === 'denied') {
                setCameraError("الكاميرا مرفوضة. يرجى السماح للتطبيق باستخدام الكاميرا من إعدادات المتصفح.");
              } else if (errInfo.type === 'not_found') {
                setCameraError("لم يتم العثور على كاميرا في هذا الجهاز.");
              } else {
                setCameraError("حدث خطأ أثناء تشغيل الكاميرا أو نموذج التتبع.");
              }
            }
          }
        });

        engineRef.current = engine;

        await engine.initModel();
        if (mounted) setIsLoadingModel(false);

        if (videoRef.current) {
          await engine.startCamera(videoRef.current, cameraFacing);
        }
      } catch (err) {
        console.error("Initialization error:", err);
        if (mounted) {
          setIsLoadingModel(false);
          if (!cameraError) {
            setCameraError("تعذر تشغيل الكاميرا أو الذكاء الاصطناعي. تأكد من منح الأذونات اللازمة.");
          }
        }
      }
    }

    init();

    return () => {
      mounted = false;
      if (engineRef.current) {
        engineRef.current.stop();
      }
    };
  }, [activeExerciseId, cameraFacing, handleRepDetected]);

  // Flip camera
  const toggleCameraFacing = () => {
    const nextFacing = cameraFacing === 'user' ? 'environment' : 'user';
    setCameraFacing(nextFacing);
  };

  const handleToggleMic = () => {
    if (!voiceServiceRef.current) return;
    if (isMicListening) {
      voiceServiceRef.current.stop();
      setIsMicListening(false);
    } else {
      voiceServiceRef.current.start();
      setIsMicListening(true);
    }
  };

  const handleTriggerUserIntent = (intentName) => {
    if (coachEngineRef.current) {
      coachEngineRef.current.triggerEvent(intentName);
    }
  };

  return (
    <div className="relative w-full h-[100dvh] bg-black overflow-hidden flex flex-col justify-between">
      {/* 1. Camera Video Feed with Canvas Skeleton Overlay */}
      <div className="absolute inset-0 w-full h-full overflow-hidden bg-dark-950 flex items-center justify-center">
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className={`w-full h-full object-cover ${cameraFacing === 'user' ? 'camera-mirror' : ''}`}
        />

        {/* Dynamic Skeleton Canvas */}
        <SkeletonOverlay
          landmarks={landmarks}
          exerciseConfig={exerciseConfig}
          formStatus={formStatus}
          isReady={isReady}
        />

        {/* Subtle Dark Gradient Overlay for high UI contrast */}
        <div className="absolute inset-0 bg-gradient-to-b from-dark-950/85 via-transparent to-dark-950/90 pointer-events-none" />
      </div>

      {/* 2. Top Header Overlay */}
      <div className="relative z-20 w-full px-4 pt-4 pb-2 flex items-center justify-between">
        {/* Back / Exit Button */}
        <button
          onClick={() => setShowExitConfirm(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-dark-900/80 backdrop-blur-md border border-slate-700/60 text-slate-200 text-xs font-bold hover:bg-dark-800 active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>خروج</span>
        </button>

        {/* Exercise Badge */}
        <div className="flex flex-col items-center">
          <span className="text-sm font-extrabold text-white flex items-center gap-1.5 drop-shadow">
            <Flame size={16} className="text-neon-green fill-neon-green" />
            {exerciseConfig.nameAr}
          </span>
          <span className="text-[10px] text-slate-300 font-mono">
            {Math.floor(elapsedSeconds / 60)}:{(elapsedSeconds % 60).toString().padStart(2, '0')}
          </span>
        </div>

        {/* Right Tools (Sound & Flip Camera) */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleCameraFacing}
            className="w-8 h-8 rounded-full bg-dark-900/80 backdrop-blur-md border border-slate-700/60 text-slate-200 flex items-center justify-center hover:text-neon-green active:scale-95"
            title="تبديل الكاميرا"
          >
            <SwitchCamera size={16} />
          </button>
          <button
            onClick={onToggleSound}
            className="w-8 h-8 rounded-full bg-dark-900/80 backdrop-blur-md border border-slate-700/60 text-slate-200 flex items-center justify-center hover:text-neon-green active:scale-95"
            title="تبديل الصوت"
          >
            {settings.voice ? <Volume2 size={16} className="text-neon-green" /> : <VolumeX size={16} />}
          </button>
        </div>
      </div>

      {/* 3. Middle Real-Time Status & Guidance Pill */}
      <div className="relative z-20 flex flex-col items-center px-4 pointer-events-none space-y-1.5">
        {/* Visibility / Readiness Pill (Section 12: ● جاهز in green, otherwise warning) */}
        <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full backdrop-blur-md text-xs font-black shadow-lg transition-all duration-300 ${
          isReady
            ? 'bg-emerald-500/20 border border-emerald-500/60 text-neon-green'
            : 'bg-amber-500/20 border border-amber-500/60 text-amber-300 animate-pulse'
        }`}>
          <span className={`w-2.5 h-2.5 rounded-full ${isReady ? 'bg-neon-green shadow-glow-green' : 'bg-amber-400'}`} />
          <span>{isReady ? "جاهز" : visibilityMessage}</span>
        </div>

        {/* Form Feedback Banner (Section 11 & 20) */}
        {formFeedback && isReady && (
          <div className={`px-3 py-1 rounded-xl text-xs font-bold transition-all backdrop-blur-md ${
            formStatus === 'warning'
              ? 'bg-red-500/30 border border-red-500/50 text-red-200'
              : formStatus === 'info'
              ? 'bg-amber-500/25 border border-amber-500/40 text-amber-200'
              : 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-200'
          }`}>
            {formFeedback}
          </div>
        )}
      </div>

      {/* 4. FitPulse Coach Interactive Overlay */}
      <div className="relative z-30 w-full mb-1">
        <CoachOverlay
          coachMessage={coachMessage}
          isListening={isMicListening}
          onToggleMic={handleToggleMic}
          onTriggerUserIntent={handleTriggerUserIntent}
        />
      </div>

      {/* 5. Bottom Controls & Giant Rep Counter */}
      <div className="relative z-20 w-full px-4 pb-6 pt-1 flex flex-col items-center">
        {/* Giant Rep Display */}
        <RepCounter
          reps={reps}
          currentSet={currentSet}
          totalSets={totalSets}
          targetReps={targetReps}
          exerciseType={exerciseConfig.type}
        />

        {/* Primary Controls Row */}
        <div className="w-full max-w-sm flex items-center justify-between gap-3 mt-3">
          <button
            onClick={() => finishWorkoutSession()}
            className="flex-1 py-3 px-4 rounded-2xl bg-dark-900/90 border border-slate-700/80 text-slate-300 font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-dark-800 active:scale-95 transition-all"
          >
            <span>إنهاء التمرين</span>
          </button>

          <button
            onClick={() => {
              setIsPaused(p => !p);
            }}
            className={`py-3 px-6 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95 ${
              isPaused
                ? 'bg-neon-green text-dark-950 shadow-glow-green'
                : 'bg-dark-900/90 border border-emerald-500/40 text-neon-green'
            }`}
          >
            {isPaused ? <Play size={18} className="fill-current" /> : <Pause size={18} />}
            <span>{isPaused ? "استئناف" : "إيقاف مؤقت"}</span>
          </button>
        </div>
      </div>

      {/* 6. Rest Timer Overlay between sets */}
      {isResting && (
        <RestTimer
          initialSeconds={30}
          currentSet={currentSet}
          totalSets={totalSets}
          onComplete={handleRestFinished}
          onSkip={handleRestFinished}
        />
      )}

      {/* 7. Animated 3-2-1-GO Sequence (Section 13) */}
      {countdown !== null && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-dark-950/80 backdrop-blur-md animate-fade-in">
          <div className="flex flex-col items-center">
            <span className="text-8xl sm:text-9xl font-black text-white glow-text-green font-mono animate-bounce">
              {countdown}
            </span>
            <span className="text-base font-extrabold text-neon-green mt-4">
              {countdown === 'GO' ? "انطلق يا وحش! 🔥" : "استعد للبدء"}
            </span>
          </div>
        </div>
      )}

      {/* 8. Setup Guide Modal */}
      {!setupDismissed && !cameraError && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-dark-950/90 backdrop-blur-md p-6">
          <div className="w-full max-w-sm bg-dark-900 border border-slate-700 rounded-3xl p-6 text-center shadow-2xl flex flex-col items-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-neon-green flex items-center justify-center text-dark-950 mb-4 shadow-glow-green">
              <Sparkles size={32} />
            </div>

            <h3 className="text-2xl font-extrabold text-white mb-2">
              جهّز مكانك مع الكوتش
            </h3>

            <p className="text-sm text-slate-300 leading-relaxed mb-6 font-medium">
              حط الموبايل على بعد 2–3 متر وخلي جسمك كله ظاهر في الكاميرا، والكوتش هيركز معاك في كل حركة!
            </p>

            <div className="w-full p-3.5 rounded-2xl bg-dark-800/80 border border-slate-700/60 text-xs text-slate-300 text-right space-y-2 mb-6">
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-neon-green shrink-0" />
                <span>إضاءة أمامية جيدة بدون توهج خلفي</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-neon-green shrink-0" />
                <span>ظهور الكتفين والركبتين بوضوح تام</span>
              </div>
            </div>

            <button
              onClick={startCountdown}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-neon-green text-dark-950 font-black text-base shadow-glow-green hover:opacity-95 active:scale-95 transition-all"
            >
              أنا جاهز، ابدأ الكاميرا
            </button>
          </div>
        </div>
      )}

      {/* 9. Camera Error Modal */}
      {cameraError && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-dark-950/95 backdrop-blur-md p-6 text-center">
          <div className="w-full max-w-sm bg-dark-900 border border-red-500/40 rounded-3xl p-6 flex flex-col items-center">
            <div className="w-14 h-14 rounded-2xl bg-red-500/20 text-red-400 flex items-center justify-center mb-4">
              <AlertTriangle size={32} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">الكاميرا غير متاحة</h3>
            <p className="text-sm text-slate-300 mb-6 leading-relaxed">
              {cameraError}
            </p>
            <div className="flex flex-col w-full gap-2.5">
              <button
                onClick={() => window.location.reload()}
                className="w-full py-3.5 rounded-2xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-500 transition-colors"
              >
                إعادة المحاولة
              </button>
              <button
                onClick={onCancelWorkout}
                className="w-full py-3.5 rounded-2xl bg-dark-800 text-slate-300 font-bold text-sm hover:bg-dark-700 transition-colors"
              >
                العودة للرئيسية
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 10. Confirm Exit Dialog */}
      {showExitConfirm && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-dark-950/85 backdrop-blur-md p-6">
          <div className="w-full max-w-sm bg-dark-900 border border-slate-700 rounded-3xl p-6 text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3">
              <ShieldAlert size={28} />
            </div>
            <h4 className="text-lg font-bold text-white mb-1">التمرين لسه شغال</h4>
            <p className="text-xs text-slate-300 mb-6">
              هل تريد الخروج؟ سيتم حفظ التكرارات التي أكملتها حتى الآن.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => finishWorkoutSession()}
                className="flex-1 py-3 rounded-xl bg-red-600 text-white font-bold text-xs hover:bg-red-500 transition-colors"
              >
                خروج وحفظ
              </button>
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-3 rounded-xl bg-dark-800 text-slate-200 font-bold text-xs hover:bg-dark-700 transition-colors"
              >
                متابعة التمرين
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
