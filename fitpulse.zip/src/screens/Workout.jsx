// Workout Camera Screen with MediaPipe Pose Landmarker, Skeleton & Form Feedback
// Implements Sections 9, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22, 23

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Play, Pause, RotateCcw, Volume2, VolumeX, AlertTriangle,
  CheckCircle2, Flame, ArrowRight, ShieldAlert, Sparkles, SwitchCamera
} from 'lucide-react';
import { PoseEngine } from '../engine/poseEngine';
import SkeletonOverlay from '../components/SkeletonOverlay';
import RepCounter from '../components/RepCounter';
import RestTimer from '../components/RestTimer';
import { EXERCISES } from '../exercises/exerciseConfig';
import { speechService } from '../services/speech';

export default function Workout({
  activeExerciseId = 'squat',
  planDayExercise = null,
  onFinishWorkout,
  onCancelWorkout,
  soundEnabled = true,
  onToggleSound
}) {
  const videoRef = useRef(null);
  const engineRef = useRef(null);

  // Exercise config
  const exerciseConfig = EXERCISES[activeExerciseId] || EXERCISES.squat;
  const targetReps = planDayExercise?.reps || exerciseConfig.defaultReps || 12;
  const totalSets = planDayExercise?.sets || exerciseConfig.defaultSets || 3;

  // Workout state
  const [currentSet, setCurrentSet] = useState(1);
  const [reps, setReps] = useState(0);
  const [totalCompletedReps, setTotalCompletedReps] = useState(0);
  const [isResting, setIsResting] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [setupDismissed, setSetupDismissed] = useState(false);

  // Vision & Tracking state
  const [landmarks, setLandmarks] = useState(null);
  const [isReady, setIsReady] = useState(false);
  const [visibilityMessage, setVisibilityMessage] = useState("جاري تحميل النموذج الذكي...");
  const [formFeedback, setFormFeedback] = useState(null);
  const [formStatus, setFormStatus] = useState('neutral');
  const [currentAngle, setCurrentAngle] = useState(0);
  const [cameraFacing, setCameraFacing] = useState('user');
  const [cameraError, setCameraError] = useState(null);
  const [isLoadingModel, setIsLoadingModel] = useState(true);

  // Exit dialog
  const [showExitConfirm, setShowExitConfirm] = useState(false);

  // Timer
  const [startTime] = useState(Date.now());
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Timer interval
  useEffect(() => {
    if (isPaused || isResting || !setupDismissed) return;
    const interval = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isPaused, isResting, setupDismissed]);

  // Handle a detected rep from PoseEngine
  const handleRepDetected = useCallback((repCount, exerciseType) => {
    if (isResting || isPaused) return;

    setReps(repCount);
    setTotalCompletedReps(prev => prev + 1);

    // Voice announcement for valid rep
    speechService.speakRep(repCount);

    // Check if target reps achieved for this set
    if (repCount >= targetReps) {
      handleSetCompleted(currentSet);
    }
  }, [isResting, isPaused, targetReps, currentSet]);

  const handleSetCompleted = (finishedSet) => {
    speechService.speakSetComplete();

    if (finishedSet >= totalSets) {
      // Completed all sets for this exercise!
      finishWorkoutSession(totalCompletedReps + 1);
    } else {
      // Transition to rest timer
      setIsResting(true);
    }
  };

  const handleRestFinished = () => {
    setIsResting(false);
    setCurrentSet(prev => prev + 1);
    setReps(0);
    if (engineRef.current) {
      engineRef.current.reps = 0;
      engineRef.current.repState = (activeExerciseId === 'curl') ? 'DOWN' : 'UP';
    }
  };

  const finishWorkoutSession = (finalRepsCount = null) => {
    const finalReps = finalRepsCount !== null ? finalRepsCount : totalCompletedReps;
    const formScore = engineRef.current ? engineRef.current.getFormScore() : 88;
    const duration = Math.max(15, elapsedSeconds);

    if (engineRef.current) {
      engineRef.current.stop();
    }

    onFinishWorkout({
      exerciseId: activeExerciseId,
      exerciseNameAr: exerciseConfig.nameAr,
      reps: finalReps,
      sets: currentSet,
      totalSets: totalSets,
      duration: duration,
      formScore: formScore
    });
  };

  // Initialize MediaPipe and Camera
  useEffect(() => {
    let mounted = true;

    async function init() {
      try {
        setIsLoadingModel(true);
        setCameraError(null);

        const engine = new PoseEngine({
          exerciseId: activeExerciseId,
          onLandmarks: (lms) => {
            if (mounted) setLandmarks(lms);
          },
          onRep: (count, type) => {
            if (mounted) handleRepDetected(count, type);
          },
          onVisibility: (vis) => {
            if (mounted) {
              setIsReady(vis.isReady);
              setVisibilityMessage(vis.messageAr);
            }
          },
          onFeedback: (fb) => {
            if (mounted) {
              setFormFeedback(fb.messageAr);
              setFormStatus(fb.status);
            }
          },
          onAngleUpdate: (ang) => {
            if (mounted) setCurrentAngle(ang);
          },
          onError: (errInfo) => {
            if (mounted) {
              if (errInfo.type === 'denied') {
                setCameraError("الكاميرا مرفوضة. يرجى السماح للتطبيق باستخدام الكاميرا من إعدادات المتصفح.");
              } else if (errInfo.type === 'not_found') {
                setCameraError("لم يتم العثور على كاميرا في هذا الجهاز.");
              } else {
                setCameraError("حدث خطأ أثناء تشغيل الكاميرا أو نموذج التتبع.");
              }
            }
          }
        });

        engineRef.current = engine;

        await engine.initModel();
        if (mounted) setIsLoadingModel(false);

        if (videoRef.current) {
          await engine.startCamera(videoRef.current, cameraFacing);
        }
      } catch (err) {
        console.error("Initialization error:", err);
        if (mounted) {
          setIsLoadingModel(false);
          if (!cameraError) {
            setCameraError("تعذر تشغيل الكاميرا أو الذكاء الاصطناعي. تأكد من منح الأذونات اللازمة.");
          }
        }
      }
    }

    init();

    return () => {
      mounted = false;
      if (engineRef.current) {
        engineRef.current.stop();
      }
    };
  }, [activeExerciseId, cameraFacing, handleRepDetected]);

  // Flip camera between front and back
  const toggleCameraFacing = () => {
    const nextFacing = cameraFacing === 'user' ? 'environment' : 'user';
    setCameraFacing(nextFacing);
  };

  return (
    <div className="relative w-full h-[100dvh] bg-black overflow-hidden flex flex-col justify-between">
      {/* 1. Camera Video Feed with Canvas Skeleton */}
      <div className="absolute inset-0 w-full h-full overflow-hidden bg-dark-950 flex items-center justify-center">
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className={`w-full h-full object-cover ${cameraFacing === 'user' ? 'camera-mirror' : ''}`}
        />

        {/* Skeleton canvas overlay */}
        <SkeletonOverlay
          landmarks={landmarks}
          exerciseConfig={exerciseConfig}
          formStatus={formStatus}
          isReady={isReady}
        />

        {/* Subtle Dark Gradient Overlay for UI legibility */}
        <div className="absolute inset-0 bg-gradient-to-b from-dark-950/80 via-transparent to-dark-950/90 pointer-events-none" />
      </div>

      {/* 2. Top Header Overlay */}
      <div className="relative z-20 w-full px-4 pt-4 pb-2 flex items-center justify-between">
        {/* Back / Exit Button */}
        <button
          onClick={() => setShowExitConfirm(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-dark-900/80 backdrop-blur-md border border-slate-700/60 text-slate-200 text-xs font-bold hover:bg-dark-800 active:scale-95 transition-all"
        >
          <ArrowRight size={16} />
          <span>خروج</span>
        </button>

        {/* Exercise Badge */}
        <div className="flex flex-col items-center">
          <span className="text-sm font-extrabold text-white flex items-center gap-1.5 drop-shadow">
            <Flame size={16} className="text-neon-green fill-neon-green" />
            {exerciseConfig.nameAr}
          </span>
          <span className="text-[10px] text-slate-300 font-mono">
            {Math.floor(elapsedSeconds / 60)}:{(elapsedSeconds % 60).toString().padStart(2, '0')}
          </span>
        </div>

        {/* Right Tools (Sound & Flip Camera) */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleCameraFacing}
            className="w-8 h-8 rounded-full bg-dark-900/80 backdrop-blur-md border border-slate-700/60 text-slate-200 flex items-center justify-center hover:text-neon-green active:scale-95"
            title="تبديل الكاميرا"
          >
            <SwitchCamera size={16} />
          </button>
          <button
            onClick={onToggleSound}
            className="w-8 h-8 rounded-full bg-dark-900/80 backdrop-blur-md border border-slate-700/60 text-slate-200 flex items-center justify-center hover:text-neon-green active:scale-95"
            title="تبديل الصوت"
          >
            {soundEnabled ? <Volume2 size={16} className="text-neon-green" /> : <VolumeX size={16} />}
          </button>
        </div>
      </div>

      {/* 3. Middle Real-Time Status & Guidance Pill */}
      <div className="relative z-20 flex flex-col items-center px-4 pointer-events-none">
        {/* Visibility / Readiness Pill (Section 12: ● جاهز in green, otherwise warning) */}
        <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full backdrop-blur-md text-xs font-black shadow-lg transition-all duration-300 ${
          isReady
            ? 'bg-emerald-500/20 border border-emerald-500/60 text-neon-green'
            : 'bg-amber-500/20 border border-amber-500/60 text-amber-300 animate-pulse'
        }`}>
          <span className={`w-2.5 h-2.5 rounded-full ${isReady ? 'bg-neon-green shadow-glow-green' : 'bg-amber-400'}`} />
          <span>{isReady ? "جاهز" : visibilityMessage}</span>
        </div>

        {/* Form Feedback Banner (Section 20: انزل أكتر, خلي ضهرك مستقيم, etc.) */}
        {formFeedback && isReady && (
          <div className={`mt-2 px-3 py-1 rounded-xl text-xs font-bold transition-all backdrop-blur-md ${
            formStatus === 'warning'
              ? 'bg-red-500/30 border border-red-500/50 text-red-200'
              : formStatus === 'info'
              ? 'bg-amber-500/25 border border-amber-500/40 text-amber-200'
              : 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-200'
          }`}>
            {formFeedback}
          </div>
        )}
      </div>

      {/* 4. Bottom Controls & Giant Rep Counter */}
      <div className="relative z-20 w-full px-4 pb-6 pt-2 flex flex-col items-center">
        {/* Giant Rep Display */}
        <RepCounter
          reps={reps}
          currentSet={currentSet}
          totalSets={totalSets}
          targetReps={targetReps}
          exerciseType={exerciseConfig.type}
        />

        {/* Primary Controls Row */}
        <div className="w-full max-w-sm flex items-center justify-between gap-3 mt-4">
          <button
            onClick={() => finishWorkoutSession()}
            className="flex-1 py-3 px-4 rounded-2xl bg-dark-900/90 border border-slate-700/80 text-slate-300 font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-dark-800 active:scale-95 transition-all"
          >
            <span>إنهاء التمرين</span>
          </button>

          <button
            onClick={() => {
              setIsPaused(p => !p);
            }}
            className={`py-3 px-6 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95 ${
              isPaused
                ? 'bg-neon-green text-dark-950 shadow-glow-green'
                : 'bg-dark-900/90 border border-emerald-500/40 text-neon-green'
            }`}
          >
            {isPaused ? <Play size={18} className="fill-current" /> : <Pause size={18} />}
            <span>{isPaused ? "استئناف" : "إيقاف مؤقت"}</span>
          </button>
        </div>
      </div>

      {/* 5. Rest Timer Overlay between sets */}
      {isResting && (
        <RestTimer
          initialSeconds={30}
          currentSet={currentSet}
          totalSets={totalSets}
          onComplete={handleRestFinished}
          onSkip={handleRestFinished}
        />
      )}

      {/* 6. Setup Guide Modal (Section 11: جهّز مكانك, حط الموبايل على بعد 2-3 متر) */}
      {!setupDismissed && !cameraError && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-dark-950/90 backdrop-blur-md p-6">
          <div className="w-full max-w-sm bg-dark-900 border border-slate-700 rounded-3xl p-6 text-center shadow-2xl flex flex-col items-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-neon-green flex items-center justify-center text-dark-950 mb-4 shadow-glow-green">
              <Sparkles size={32} />
            </div>

            <h3 className="text-2xl font-extrabold text-white mb-2">
              جهّز مكانك
            </h3>

            <p className="text-sm text-slate-300 leading-relaxed mb-6 font-medium">
              حط الموبايل على بعد 2–3 متر وخلي جسمك كله ظاهر في الكاميرا، من الرأس حتى القدمين.
            </p>

            <div className="w-full p-3.5 rounded-2xl bg-dark-800/80 border border-slate-700/60 text-xs text-slate-300 text-right space-y-2 mb-6">
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-neon-green shrink-0" />
                <span>إضاءة أمامية جيدة بدون توهج خلفي</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 size={16} className="text-neon-green shrink-0" />
                <span>ظهور الكتفين والركبتين بوضوح تام</span>
              </div>
            </div>

            <button
              onClick={() => setSetupDismissed(true)}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-neon-green text-dark-950 font-black text-base shadow-glow-green hover:opacity-95 active:scale-95 transition-all"
            >
              أنا جاهز، ابدأ الكاميرا
            </button>
          </div>
        </div>
      )}

      {/* 7. Camera Error Modal (Section 10 & 42) */}
      {cameraError && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-dark-950/95 backdrop-blur-md p-6 text-center">
          <div className="w-full max-w-sm bg-dark-900 border border-red-500/40 rounded-3xl p-6 flex flex-col items-center">
            <div className="w-14 h-14 rounded-2xl bg-red-500/20 text-red-400 flex items-center justify-center mb-4">
              <AlertTriangle size={32} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">الكاميرا غير متاحة</h3>
            <p className="text-sm text-slate-300 mb-6 leading-relaxed">
              {cameraError}
            </p>
            <div className="flex flex-col w-full gap-2.5">
              <button
                onClick={() => window.location.reload()}
                className="w-full py-3.5 rounded-2xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-500 transition-colors"
              >
                إعادة المحاولة
              </button>
              <button
                onClick={onCancelWorkout}
                className="w-full py-3.5 rounded-2xl bg-dark-800 text-slate-300 font-bold text-sm hover:bg-dark-700 transition-colors"
              >
                العودة للرئيسية
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. Confirm Exit Dialog (Section 47: التمرين لسه شغال هل تريد الخروج؟) */}
      {showExitConfirm && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-dark-950/85 backdrop-blur-md p-6">
          <div className="w-full max-w-sm bg-dark-900 border border-slate-700 rounded-3xl p-6 text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3">
              <ShieldAlert size={28} />
            </div>
            <h4 className="text-lg font-bold text-white mb-1">التمرين لسه شغال</h4>
            <p className="text-xs text-slate-300 mb-6">
              هل تريد الخروج؟ سيتم حفظ التكرارات التي أكملتها حتى الآن.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => finishWorkoutSession()}
                className="flex-1 py-3 rounded-xl bg-red-600 text-white font-bold text-xs hover:bg-red-500 transition-colors"
              >
                خروج وحفظ
              </button>
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-3 rounded-xl bg-dark-800 text-slate-200 font-bold text-xs hover:bg-dark-700 transition-colors"
              >
                متابعة التمرين
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
