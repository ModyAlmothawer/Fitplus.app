// FitPulse Home Dashboard Screen
// Implements Sections 7 & 46

import React from 'react';
import { Flame, Play, Moon, Sparkles, CheckCircle2, ChevronLeft, Zap, Dumbbell } from 'lucide-react';
import CircularProgress from '../components/CircularProgress';
import XPBar from '../components/XPBar';
import { getDailyQuote } from '../data/quotes';
import { EXERCISES } from '../exercises/exerciseConfig';

export default function Home({
  profile,
  weeklyPlan,
  onStartWorkout,
  onOpenPlan,
  onQuickExercise
}) {
  const quote = getDailyQuote();

  // Determine current day of week (Arabic key in weekly plan)
  const daysMap = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const todayKey = daysMap[new Date().getDay()];
  const todayPlan = weeklyPlan?.[todayKey] || { isRest: false, exercises: [] };

  // Calculate completed days in current week
  const planDays = Object.values(weeklyPlan || {});
  const completedDaysCount = planDays.filter(d => d.completed || d.isRest).length;

  const streak = profile?.streak || 0;
  const isFirstLaunch = (!profile?.totalWorkouts || profile.totalWorkouts === 0);

  return (
    <div className="min-h-screen bg-dark-950 text-white p-4 sm:p-6 pb-28 max-w-lg mx-auto space-y-4">
      {/* 1. Welcome / Intro Banner (Section 46: Empty State First Launch) */}
      {isFirstLaunch && (
        <div className="w-full bg-gradient-to-r from-emerald-950/70 via-dark-900 to-dark-900 border border-emerald-500/40 rounded-3xl p-5 shadow-glow-green">
          <div className="flex items-center gap-2 text-neon-green font-bold text-xs mb-1">
            <Sparkles size={16} />
            <span>البداية الذكية</span>
          </div>
          <h2 className="text-xl font-black text-white mb-1">
            أهلاً بيك في FitPulse 🔥
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed font-medium">
            ابدأ أول تمرين اليوم، واستمتع بالعد التلقائي والتصحيح الفوري لحركتك بالكاميرا وابني أول Streak ليك!
          </p>
        </div>
      )}

      {/* 2. XP & Level Card */}
      <XPBar totalXp={profile?.xp || 0} compact={false} />

      {/* 3. Streak & Weekly Ring Row (Sections 7 & 35) */}
      <div className="grid grid-cols-2 gap-3">
        {/* Streak Card */}
        <div className="bg-dark-900/90 border border-slate-800 rounded-3xl p-4 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold">حماس الاستمرار</span>
            <Flame size={20} className={streak > 0 ? "text-accent-orange fill-accent-orange" : "text-slate-600"} />
          </div>

          <div className="my-2">
            <div className="text-4xl font-black text-white font-mono flex items-baseline gap-1">
              <span>{streak}</span>
              <span className="text-xs text-slate-400 font-normal">أيام</span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium mt-1 leading-snug">
              {streak > 0 ? "أيام متتالية مستمرة 🔥" : "ابدأ أول تمرين اليوم"}
            </p>
          </div>

          <div className="text-[10px] text-emerald-400 font-bold">
            أفضل إنجاز: {profile?.bestStreak || streak} أيام
          </div>
        </div>

        {/* Weekly Completed Ring Card */}
        <div className="bg-dark-900/90 border border-slate-800 rounded-3xl p-4 flex flex-col items-center justify-between shadow-lg">
          <span className="text-xs font-semibold text-slate-400 self-start">إنجاز الأسبوع</span>
          <div className="my-1">
            <CircularProgress completed={completedDaysCount} total={7} size={88} strokeWidth={8} />
          </div>
          <span className="text-[11px] text-slate-400 font-medium">
            {completedDaysCount} / 7 أيام مكتملة
          </span>
        </div>
      </div>

      {/* 4. Today's Planned Workout Card (Section 7) */}
      <div className="w-full bg-dark-900/90 border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-neon-green flex items-center justify-center">
              <Dumbbell size={18} />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">تمرين اليوم</h3>
              <p className="text-[11px] text-slate-400 font-medium">
                {todayPlan.isRest ? "راحة مستحقة لاستشفاء العضلات" : `${todayPlan.exercises?.length || 0} تمارين مجدولة`}
              </p>
            </div>
          </div>

          <button
            onClick={onOpenPlan}
            className="text-xs font-bold text-neon-green flex items-center gap-1 hover:underline"
          >
            <span>الجدول</span>
            <ChevronLeft size={16} />
          </button>
        </div>

        {/* Content of Today */}
        {todayPlan.isRest ? (
          <div className="p-4 rounded-2xl bg-dark-800/60 border border-slate-700/50 flex items-center gap-3 text-slate-300">
            <Moon size={24} className="text-amber-400 shrink-0" />
            <div>
              <p className="text-sm font-bold text-white">اليوم راحة 😴</p>
              <p className="text-xs text-slate-400 mt-0.5">استغل اليوم لتغذية جسمك والنوم الجيد للعودة بطاقة أقوى.</p>
            </div>
          </div>
        ) : todayPlan.exercises && todayPlan.exercises.length > 0 ? (
          <div className="space-y-2 mb-4">
            {todayPlan.exercises.map((item, idx) => {
              const cfg = EXERCISES[item.id] || EXERCISES.squat;
              return (
                <div
                  key={idx}
                  onClick={() => onQuickExercise(item.id, item)}
                  className="flex items-center justify-between p-3 rounded-2xl bg-dark-800/70 border border-slate-800 hover:border-emerald-500/40 cursor-pointer active:scale-98 transition-all"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-dark-700 text-xs font-bold text-slate-300 flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <div>
                      <span className="text-sm font-bold text-white block">{item.nameAr || cfg.nameAr}</span>
                      <span className="text-xs text-slate-400">{cfg.type === 'isometric' ? `${item.reps} ثانية ثبات` : `${item.sets} مجموعات × ${item.reps} تكرار`}</span>
                    </div>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-neon-green flex items-center justify-center">
                    <Play size={14} className="fill-current translate-x-0.5" />
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-dark-800/40 border border-slate-800 text-center text-xs text-slate-400 mb-3">
            لم تضف تمارين بعد لهذا اليوم. يمكنك إضافة تمارين من تبويب "الخطة" أو البدء بتمرين سكوات حر.
          </div>
        )}

        {/* Main Big CTA Button (Section 7: ابدأ التمرين) */}
        <button
          onClick={() => {
            const firstEx = todayPlan.exercises?.[0];
            onStartWorkout(firstEx?.id || 'squat', firstEx);
          }}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-neon-green to-teal-400 text-dark-950 font-black text-lg shadow-glow-green flex items-center justify-center gap-2.5 hover:opacity-95 active:scale-95 transition-all"
        >
          <Play size={22} className="fill-current translate-x-0.5" />
          <span>ابدأ التمرين الآن</span>
        </button>
      </div>

      {/* 5. Daily Motivation Quote (Section 7: 30 Arabic motivational quotes) */}
      <div className="w-full bg-dark-900/60 border border-slate-800/80 rounded-3xl p-4 flex items-start gap-3">
        <div className="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
          <Sparkles size={18} />
        </div>
        <div>
          <span className="text-[11px] font-bold text-amber-400 block mb-1">إلهام اليوم</span>
          <p className="text-sm font-semibold text-slate-200 leading-relaxed italic">
            "{quote}"
          </p>
        </div>
      </div>
    </div>
  );
}
