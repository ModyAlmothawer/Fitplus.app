// Weekly Workout Planner (7-day plan)
// Implements Section 8

import React, { useState } from 'react';
import { Calendar, Plus, Moon, Check, Trash2, Edit2, Play, RefreshCw, X, Dumbbell } from 'lucide-react';
import { EXERCISES, EXERCISE_LIST } from '../exercises/exerciseConfig';

const DAYS_ORDER = [
  { key: 'saturday', nameAr: 'السبت' },
  { key: 'sunday', nameAr: 'الأحد' },
  { key: 'monday', nameAr: 'الإثنين' },
  { key: 'tuesday', nameAr: 'الثلاثاء' },
  { key: 'wednesday', nameAr: 'الأربعاء' },
  { key: 'thursday', nameAr: 'الخميس' },
  { key: 'friday', nameAr: 'الجمعة' }
];

export default function WeeklyPlan({ weeklyPlan, onUpdatePlan, onStartExercise }) {
  const [selectedDayKey, setSelectedDayKey] = useState('saturday');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingIndex, setEditingIndex] = useState(null);

  // Modal form state
  const [formExerciseId, setFormExerciseId] = useState('squat');
  const [formSets, setFormSets] = useState(3);
  const [formReps, setFormReps] = useState(12);

  const currentDay = weeklyPlan?.[selectedDayKey] || { isRest: false, completed: false, exercises: [] };

  const handleToggleRest = () => {
    const updated = {
      ...weeklyPlan,
      [selectedDayKey]: {
        ...currentDay,
        isRest: !currentDay.isRest
      }
    };
    onUpdatePlan(updated);
  };

  const handleToggleCompleted = () => {
    const updated = {
      ...weeklyPlan,
      [selectedDayKey]: {
        ...currentDay,
        completed: !currentDay.completed
      }
    };
    onUpdatePlan(updated);
  };

  const openAddModal = () => {
    setEditingIndex(null);
    setFormExerciseId('squat');
    setFormSets(3);
    setFormReps(12);
    setModalOpen(true);
  };

  const openEditModal = (idx) => {
    const ex = currentDay.exercises[idx];
    setEditingIndex(idx);
    setFormExerciseId(ex.id);
    setFormSets(ex.sets);
    setFormReps(ex.reps);
    setModalOpen(true);
  };

  const handleDeleteExercise = (idx) => {
    const newExs = [...currentDay.exercises];
    newExs.splice(idx, 1);
    const updated = {
      ...weeklyPlan,
      [selectedDayKey]: {
        ...currentDay,
        exercises: newExs
      }
    };
    onUpdatePlan(updated);
  };

  const handleSaveExercise = (e) => {
    e.preventDefault();
    const cfg = EXERCISES[formExerciseId];
    const item = {
      id: formExerciseId,
      nameAr: cfg.nameAr,
      sets: Number(formSets),
      reps: Number(formReps)
    };

    const newExs = [...(currentDay.exercises || [])];
    if (editingIndex !== null) {
      newExs[editingIndex] = item;
    } else {
      newExs.push(item);
    }

    const updated = {
      ...weeklyPlan,
      [selectedDayKey]: {
        ...currentDay,
        isRest: false,
        exercises: newExs
      }
    };

    onUpdatePlan(updated);
    setModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-dark-950 text-white p-4 sm:p-6 pb-28 max-w-lg mx-auto space-y-4">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-white">الخطة الأسبوعية</h2>
          <p className="text-xs text-slate-400 font-medium">جدول تدريب منظم يضمن استمرارك وراحتك</p>
        </div>
        <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-neon-green flex items-center justify-center">
          <Calendar size={20} />
        </div>
      </div>

      {/* 7-Day Horizontal Selector */}
      <div className="flex gap-2 overflow-x-auto pb-1 pt-1 no-scrollbar">
        {DAYS_ORDER.map(d => {
          const isSelected = selectedDayKey === d.key;
          const dayData = weeklyPlan?.[d.key] || {};
          const isRest = dayData.isRest;
          const isDone = dayData.completed;

          return (
            <button
              key={d.key}
              onClick={() => setSelectedDayKey(d.key)}
              className={`flex flex-col items-center justify-center min-w-[54px] py-2.5 px-1.5 rounded-2xl border transition-all ${
                isSelected
                  ? 'bg-gradient-to-b from-emerald-500/20 to-dark-900 border-neon-green shadow-glow-green text-neon-green'
                  : 'bg-dark-900/80 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <span className="text-[11px] font-bold">{d.nameAr}</span>
              <div className="mt-1.5 flex items-center gap-1">
                {isRest ? (
                  <span className="w-2 h-2 rounded-full bg-amber-400" title="يوم راحة" />
                ) : isDone ? (
                  <span className="w-2 h-2 rounded-full bg-neon-green" title="مكتمل" />
                ) : (
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Day Header Card */}
      <div className="bg-dark-900/90 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <span className="text-xs text-slate-400 font-medium">{currentDay.name ? `${currentDay.name} • اليوم المختار` : "اليوم المحدد"}</span>
            <h3 className="text-xl font-extrabold text-white">
              {DAYS_ORDER.find(d => d.key === selectedDayKey)?.nameAr}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {/* Toggle Rest Day */}
            <button
              onClick={handleToggleRest}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all ${
                currentDay.isRest
                  ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                  : 'bg-dark-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Moon size={14} />
              <span>{currentDay.isRest ? "يوم راحة" : "تحديد كراحة"}</span>
            </button>

            {/* Toggle Complete */}
            <button
              onClick={handleToggleCompleted}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all ${
                currentDay.completed
                  ? 'bg-emerald-500/20 border-emerald-500/50 text-neon-green'
                  : 'bg-dark-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Check size={14} />
              <span>{currentDay.completed ? "مكتمل" : "إتمام"}</span>
            </button>
          </div>
        </div>

        {/* Exercises List or Rest State */}
        {currentDay.isRest ? (
          <div className="p-6 rounded-2xl bg-dark-800/40 border border-slate-800/80 text-center flex flex-col items-center">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/15 text-amber-400 flex items-center justify-center mb-2">
              <Moon size={24} />
            </div>
            <h4 className="text-base font-bold text-white mb-1">اليوم مخصص للراحة والتعافي 😴</h4>
            <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
              عضلاتك تبنى أثناء فترات النوم والراحة. إذا كنت تريد التمرن، يمكنك إلغاء وضع الراحة وإضافة تمارين.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {currentDay.exercises && currentDay.exercises.length > 0 ? (
              currentDay.exercises.map((item, idx) => {
                const cfg = EXERCISES[item.id] || EXERCISES.squat;
                return (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-dark-800/80 border border-slate-800 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-neon-green flex items-center justify-center shrink-0">
                        <Dumbbell size={20} />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{item.nameAr || cfg.nameAr}</h4>
                        <span className="text-xs text-slate-400 font-mono">
                          {cfg.type === 'isometric' ? `${item.reps} ثانية ثبات` : `${item.sets} مجموعات × ${item.reps} تكرار`}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onStartExercise(item.id, item)}
                        className="w-8 h-8 rounded-lg bg-emerald-500/20 text-neon-green flex items-center justify-center hover:bg-emerald-500/30 active:scale-95"
                        title="بدء التمرين"
                      >
                        <Play size={15} className="fill-current translate-x-0.5" />
                      </button>
                      <button
                        onClick={() => openEditModal(idx)}
                        className="w-8 h-8 rounded-lg bg-dark-700 text-slate-300 flex items-center justify-center hover:text-white active:scale-95"
                        title="تعديل"
                      >
                        <Edit2 size={14} />
                      </button>
                      <button
                        onClick={() => handleDeleteExercise(idx)}
                        className="w-8 h-8 rounded-lg bg-red-500/10 text-red-400 flex items-center justify-center hover:bg-red-500/20 active:scale-95"
                        title="حذف"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-6 rounded-2xl bg-dark-800/30 border border-dashed border-slate-800 text-center text-xs text-slate-400">
                لم تضف تمارين بعد لهذا اليوم. اضغط على الزر أدناه لإضافة تمارينك المفضلة.
              </div>
            )}

            {/* Add Exercise Button */}
            <button
              onClick={openAddModal}
              className="w-full py-3.5 rounded-2xl bg-dark-800 border border-slate-700/80 text-neon-green font-bold text-xs flex items-center justify-center gap-2 hover:bg-dark-750 active:scale-98 transition-all"
            >
              <Plus size={16} />
              <span>إضافة تمرين لهذا اليوم</span>
            </button>
          </div>
        )}
      </div>

      {/* Add / Edit Exercise Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-dark-950/80 backdrop-blur-md p-4">
          <div className="w-full max-w-sm bg-dark-900 border border-slate-700 rounded-3xl p-6 shadow-2xl animate-fade-in">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800">
              <h3 className="text-lg font-bold text-white">
                {editingIndex !== null ? "تعديل التمرين" : "إضافة تمرين جديد"}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="w-8 h-8 rounded-full bg-dark-800 text-slate-400 flex items-center justify-center hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSaveExercise} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">اختر نوع التمرين</label>
                <select
                  value={formExerciseId}
                  onChange={(e) => setFormExerciseId(e.target.value)}
                  className="w-full bg-dark-800 border border-slate-700 rounded-xl p-3 text-sm text-white font-medium focus:outline-none focus:border-neon-green"
                >
                  {EXERCISE_LIST.map(ex => (
                    <option key={ex.id} value={ex.id}>
                      {ex.nameAr}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">المجموعات (Sets)</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={formSets}
                    onChange={(e) => setFormSets(e.target.value)}
                    className="w-full bg-dark-800 border border-slate-700 rounded-xl p-3 text-sm text-white font-mono focus:outline-none focus:border-neon-green"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    {EXERCISES[formExerciseId]?.type === 'isometric' ? "الثواني (Sec)" : "التكرارات (Reps)"}
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={formReps}
                    onChange={(e) => setFormReps(e.target.value)}
                    className="w-full bg-dark-800 border border-slate-700 rounded-xl p-3 text-sm text-white font-mono focus:outline-none focus:border-neon-green"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3.5 rounded-xl bg-neon-green text-dark-950 font-black text-sm hover:opacity-95 active:scale-95 transition-all shadow-glow-green"
                >
                  حفظ
                </button>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex-1 py-3.5 rounded-xl bg-dark-800 text-slate-300 font-bold text-sm hover:bg-dark-700"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
