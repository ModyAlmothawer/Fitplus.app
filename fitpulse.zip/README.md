# FitPulse | فيت بلس 🏋️‍♂️🔥
> تطبيق اللياقة البدنية والتحفيز الذكي باللغة العربية المدعوم بالذكاء الاصطناعي ورصد الحركة عبر الكاميرا
> Production-Ready Arabic RTL AI Fitness Coach & Gym Workout Tracker

---

## 🌟 نبذة عن المشروع (Overview)

**FitPulse** هو تطبيق متطور ومصمم بأسلوب Mobile-First لدعم الرياضيين وممارسي التمارين الرياضية في المنزل والجيم. يجمع التطبيق بين:
1. **الرصد الفوري لحركات الجسم (Real-Time Pose Tracking)** باستخدام MediaPipe Pose Landmarker لمعالجة 33 نقطة مفصلية بالجسم محلياً داخل المتصفح.
2. **العد الآلي للتكرارات (Automatic Rep Counting)** بآلية State Machine مع معالجة التعرج وحساب الزوايا الحركية (Moving Average Smoothing).
3. **التصحيح الحي للأداء (Live Form Feedback)** بنصائح وإرشادات باللغة العربية (مثل: "انزل أكتر"، "خلي ضهرك مستقيم"، "خلي ركبتك في اتجاه رجلك").
4. **نظام مجموعات ووقت راحة (Sets & Rest Timers)** مع مؤقت تنازلي وتشجيع عند إتمام كل مجموعة.
5. **عدّ صوتي باللغة العربية (Arabic Voice Counting)** ينطق أرقام التكرارات (واحد، اتنين، تلاتة...) وتشجيعات الأداء عبر Web Speech API.
6. **مخطط أسبوعي متكامل (7-Day Weekly Workout Planner)** لجدولة التمارين وأيام الراحة.
7. **نظام تحفيز كامل (Gamification)**: نقاط خبرة (XP)، مستويات تصاعدية (Levels)، سلسلة أيام متتالية (Streaks)، وأوسمة إنجاز حقيقية (Badges).
8. **سجل وتتبع التقدم (Progress & Analytics)** مع رسم بياني لتوزيع التكرارات الأسبوعية وإحصائيات شاملة.
9. **حفظ محلي فائق الخصوصية (100% Client-Side Privacy)** باستخدام LocalStorage بدون رفع صور أو فيديوهات لأي خادم خارجي.

---

## 🚀 المميزات الرئيسية (Features)

- **التمارين المدعومة:**
  - **Squat (سكوات):** فحص زاوية الركبة (Down < 100°, Up > 160°)، فحص ميل الجذع، وعدم انهيار الركبتين للداخل.
  - **Push-up (تمرين الضغط):** تتبع زاوية الكوع مع فحص استقامة الظهر ومنع هبوط الحوض.
  - **Bicep Curl (بايسبس كيرل):** ثني الذراع ومدّه بمدى حركي كامل.
  - **Shoulder Press (ضغط الأكتاف):** الدفع العمودي فوق الرأس.
  - **Lunge (طعنات الساقين):** قياس زاوية الركبة الأمامية والهبوط المتوازن.
  - **Jumping Jack (قفز جاك):** مزامنة فتح وضم اليدين والقدمين.
  - **Plank (بلانك):** تمرين ثبات متري يحسب الثواني فقط طالما الجسم مستقيم (> 160°).
- **واجهة مستخدم احترافية بالكامل باللغة العربية (RTL):**
  - ألوان النيون الرياضية (Neon Green #22C55E، Energetic Orange #F97316، Dark Slate #07090E).
  - خطوط عربية واضحة ومريحة للعين (Cairo و Tajawal).
  - أزرار لمسية مريحة لا تقل عن 48 بكسل.
  - شريط تنقل سفلي ذكي مع إبراز زر التمرين.
- **تنبيهات وتذكيرات يومية (Daily Notifications):** تدعم متصفحات الهاتف والكمبيوتر للحفاظ على الـ Streak.
- **30 حكمة رياضية تحفيزية:** تتغير يومياً لتجديد النشاط والهمة.

---

## 🛠 حزمة التقنيات (Tech Stack)

- **Frontend Core:** React 18, Vite 6
- **Styling:** Tailwind CSS, PostCSS, Custom Glow & Animations
- **AI & Vision:** `@mediapipe/tasks-vision` (MediaPipe Pose Landmarker Lite - GPU/CPU Fallback)
- **Icons:** `lucide-react`
- **Audio & Voice:** Web Speech API (`SpeechSynthesis`) with Arabic voice engine
- **Effects:** `canvas-confetti`
- **Storage:** Versioned LocalStorage (`fitpulse_data`)
- **Android Integration:** Android Compose + Hardware-Accelerated WebView hosting local assets with automatic camera permission handling

---

## 📦 متطلبات التشغيل (Requirements)

- **Node.js:** v18.0.0 أو أحدث (يوصى بـ v20 أو v22)
- **NPM:** v9.0.0 أو أحدث
- **كاميرا جهاز:** كاميرا أمامية أو خلفية
- **اتصال HTTPS:** تتطلب متصفحات الويب (Chrome, Safari, Edge, Firefox) اتصالاً آمناً (HTTPS أو localhost) لتفعيل ميزة `getUserMedia` والوصول للكاميرا.

---

## 💻 التثبيت والتشغيل المحلي (Installation & Local Development)

1. **استنساخ المستودع (Clone Repository):**
   ```bash
   git clone https://github.com/your-username/fitpulse.git
   cd fitpulse
   ```

2. **تثبيت الحزم (Install Dependencies):**
   ```bash
   npm install
   ```

3. **تشغيل بيئة التطوير (Start Dev Server):**
   ```bash
   npm run dev
   ```
   افتح الرابط في المتصفح (افتراضياً: `http://localhost:5173`).

---

## 🏗 بناء المشروع للإنتاج (Production Build)

لبناء ملفات الإنتاج المجمعة والمحسنة:

```bash
npm run build
```

ستجد الملفات المجمعة داخل مجلد `dist/`.

يمكنك معاينة البناء التجريبي محلياً عبر:
```bash
npm run preview
```

---

## 🌐 النشر على الإنترنت (Deployment)

تم تهيئة المشروع بمسارات نسبية آمنة (`base: './'`) ليعمل على أي منصة استضافة دون مشاكل:

### 1. Vercel
- قم بربط مستودع GitHub بحسابك على [Vercel](https://vercel.com).
- الإعدادات الافتراضية كافية (`Build Command: npm run build`, `Output Directory: dist`).
- سيوفر Vercel نطاق HTTPS تلقائي يضمن عمل الكاميرا فوراً.

### 2. Netlify
- اسحب مجلد `dist` بعد تشغيل `npm run build` أو اربط مستودع GitHub.
- قم بتفعيل HTTPS من إعدادات النطاق.

### 3. GitHub Pages
- شغّل أمر البناء `npm run build`.
- انشر مجلد `dist` على فرع `gh-pages`.

---

## 📱 تشغيل تطبيق أندرويد (Android App)

يحتوي المشروع على بيئة أندرويد متكاملة ومجهزة لتشغيل FitPulse كتطبيق محلي مخصص:
- تجميع تطبيق أندرويد:
  ```bash
  gradle :app:assembleDebug
  ```
- تشغيل الفحوصات والاختبارات:
  ```bash
  gradle :app:testDebugUnitTest
  ```

---

## 🔒 الخصوصية والأمان (Privacy & Safety)

- جميع عمليات معالجة صور الكاميرا تتم على جهازك محلياً عبر الـ WebAssembly والـ WebGL.
- لا يتم تسجيل أو إرسال أو تخزين أي لقطات أو فيديو خارج هاتفك.
- تقديرات السعرات الحرارية مبنية على نماذج حركية استرشادية لتعزيز الحماس والنشاط وليست قياسات طبية متخصصة.

---

## 📄 الترخيص (License)
هذا المشروع متاح للاستخدام الحر المفتوح.
صنع بشغف لتمكين مجتمع اللياقة البدنية العربي! 🔥
